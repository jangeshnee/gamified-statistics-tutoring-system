<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Problem;

class ProblemController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth:admin');
    }
  
// Display the list of problem for management
	public function list_view(){
        $problem = Problem::all();
        return view('problem/problem_list',['problem'=>$problem]); // course_list.blade.php
    }

        public function displayAllProblems(){
        $problem = Problem::all();
        return view('problem/problem_all_list',['problem'=>$problem]); // course_list.blade.php
    }

// Display the create course view

	public function create_view(){
        return view('problem/create'); // create_course.blade.php
    }

// Display the edit course view

    public function edit_view($id){
        $course = Problem::find($id);
        return view('problem/edit',['problem' => $problem]); // edit_course.blade.php
    }





}
