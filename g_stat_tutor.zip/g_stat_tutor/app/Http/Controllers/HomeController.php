<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

   

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('student/dashboard');
    }


     public function sample($id)
    {
         $prob_id = $id;

        $problems = DB::table('problems')->where('id', $prob_id)->get();
        $problem_task = DB::table('problem_tasks_and_ans')->where('problem_id', $prob_id)->get();
        $problem_step_guide = DB::table('problem_step_by_step_guide')->where('problem_id', $prob_id)->get();
        
        return view('student/0_problem_solving',['problems'=>$problems,'problem_task'=>$problem_task,'problem_step_guide'=>$problem_step_guide]);
    }

    

}
