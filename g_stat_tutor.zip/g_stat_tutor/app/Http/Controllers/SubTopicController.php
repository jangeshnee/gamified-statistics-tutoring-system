<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\SubTopic;

class SubTopicController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');
    }
    // Display the list of topic view
	public function list_view(){
        $subtopic = SubTopic::all();
        return view('subtopic/subtopic_list',['subtopic'=>$subtopic]); // subtopic_list.blade.php
    }
// Display the create topic view

	public function create_view(){
        return view('subtopic/create_subtopic'); // create_topic.blade.php
    }

// Display the edit topic view

    public function edit_view($id){
        $subtopic = SubTopic::find($id);
        return view('subtopic/edit_subtopic',['subtopic' => $subtopic]); // edit_topic.blade.php
    }
// Display the topic selected
    public function read_view($id){
       $subtopic = Topic::find($id);
        return view('subtopic/read_subtopic',['subtopic' => $subtopic]); // edit_topic.blade.php
    }

// Save topic
    public function save(Request $request){
        $this->validate($request,[
            'title' => 'required',
            'description' => 'required'
            ]);
            
            $subtopic = new SubTopic;
            $subtopic->title = $request->input('title');
            $subtopic->description = $request->input('description');
            $subtopic->topic_id = $request->input('topic_id');
            $subtopic->save();
          return redirect('/subtopic_list')->with('info','topic Saved Successfully');
    }

// Update topic
    public function update(Request $request, $id){
        $this->validate($request,[
            'title' => 'required',
            'description' => 'required'
            ]);
            $data = array(
                'title' => $request->input('title'),
                'description' => $request->input('description'),
                'topic_id' => $request->input('topic_id')
                );
            SubTopic::where('id',$id)->update($data);
            
          return redirect('/subtopic_list')->with('info','topic Updated Successfully');
    }

// Delete topic

    public function delete($id){
        SubTopic::where('id',$id)->delete();
        return redirect('/subtopic_list')->with('info','topic Deleted Successfully');
    }

}
