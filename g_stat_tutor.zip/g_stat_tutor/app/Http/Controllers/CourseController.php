<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

use App\Http\Requests;
use App\Course;

class CourseController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth:admin');
    }
  
// Display the list of course view
	public function list_view(){
        //$course = Course::all();
        $course = DB::table('courses')->get();
        return view('course/course_list',['course'=>$course]); // course_list.blade.php
    }
// Display the create course view

	public function create_view(){
        return view('course/create_course'); // create_course.blade.php
    }

// Display the edit course view

    public function edit_view($id){
        $course = Course::find($id);
        return view('course/edit_course',['course' => $course]); // edit_course.blade.php
    }
// Display the course selected
    public function read_view($id){
        $course = Course::find($id);
        return view('course/read_course',['course' => $course]); // edit_course.blade.php
    }

// Save Course
    public function save(Request $request){
        $this->validate($request,[
            'name' => 'required',
            'description' => 'required'
            ]);
            
            $course = new Course;
            $course->name = $request->input('name');
            $course->description = $request->input('description');
            $course->save();
          return redirect('course/list')->with('info','Course Saved Successfully');
    }

// Update Course
    public function update(Request $request, $id){
        $this->validate($request,[
            'name' => 'required',
            'description' => 'required'
            ]);
            $data = array(
                'name' => $request->input('name'),
                'description' => $request->input('description')
                );
            Course::where('id',$id)->update($data);
            
          return redirect('course/list')->with('info','Course Updated Successfully');
    }

// Delete Course

    public function delete($id){
        Course::where('id',$id)->delete();
        return redirect('course/list')->with('info','Course Deleted Successfully');
    }

}
