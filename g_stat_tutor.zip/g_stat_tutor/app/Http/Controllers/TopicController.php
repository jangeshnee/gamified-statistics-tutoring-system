<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Requests;
use App\Topic;


class TopicController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth:admin');
    }
// Display the list of topic view
	public function list_view($id){
        //$topic = Topic::all();
        $course_id = $id;
        $topic = DB::table('topics')->where('course_id', $course_id)->get();
        //$topic = DB::select('select * from topics where id = :id', ['id' => 1]);
        return view('topic/topic_list',['topic'=>$topic]); // topic_list.blade.php
    }
// Display the create topic view

	public function create_view(){
     
        return view('topic/create_topic'); // create_topic.blade.php
    }

// Display the edit topic view

    public function edit_view($id){
        $topic = Topic::find($id);
        return view('topic/edit_topic',['topic' => $topic]); // edit_topic.blade.php
    }
// Display the topic selected
    public function read_view($id){
        $topic = Topic::find($id);
        return view('topic/read_topic',['topic' => $topic]); // edit_topic.blade.php
    }

// Save topic
    public function save(Request $request){
        $this->validate($request,[
            'title' => 'required',
            'description' => 'required'
            ]);
            
            $topic = new Topic;
            $topic->title = $request->input('title');
            $topic->description = $request->input('description');
            $topic->course_id = $request->input('course_id');
            $topic->save();
          return redirect('/topic/list')->with('info','topic Saved Successfully');
    }

// Update topic
    public function update(Request $request, $id){
        $this->validate($request,[
            'title' => 'required',
            'description' => 'required'
            ]);
            $data = array(
                'title' => $request->input('title'),
                'description' => $request->input('description'),
                'course_id' => $request->input('course_id')
                );
            Topic::where('id',$id)->update($data);
            
          return redirect('/topic/list')->with('info','topic Updated Successfully');
    }

// Delete topic

    public function delete($id){
        Topic::where('id',$id)->delete();
        return redirect('/topic/list')->with('info','topic Deleted Successfully');
    }

}
