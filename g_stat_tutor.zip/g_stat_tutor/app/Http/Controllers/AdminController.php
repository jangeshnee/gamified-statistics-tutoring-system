<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Topic;
use App\SubTopic;
class AdminController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth:admin');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('admin');
    }

    public function displayUsers(){
        $users = User::all();
        return view('admin/user_list',['users'=>$users]);
    }

    public function displayCourseStructure(){
        $topic = Topic::all();
        $subtopic = SubTopic::all();
        return view('admin/course_structure',['topic'=>$topic,'subtopic'=>$subtopic]);
    }

    public function displaychat(){
        ;
        return view('sample');
    }
}
