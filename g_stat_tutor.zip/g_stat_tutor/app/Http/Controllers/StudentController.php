<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Hash;
use Auth;
use App\Topic;
use App\Problem;
use App\SubTopic;
use App\User;

class StudentController extends Controller
{


    public function __construct(){
        $this->middleware('auth');
    }

    public function displayHome(){
        $topic = Topic::all();
        $subtopic = SubTopic::all();
        return view('student/homepage',['topic'=>$topic,'subtopic'=>$subtopic]);
    }

    public function displayProblemList($user_id,$topic_id){
        //Display list of problem per topic
        //select * from problems where topic_id = $topic_id
        $topic_name = DB::table('topics')->where('id', $topic_id)->get();
        $problemsbytopic = DB::table('problems')->where('topic_id', $topic_id)->get(); 
        $probsolvedbystud =  DB::table('stud_fin_prob_log')->where('student_id', $user_id)->get();
        return view('student/topic_problem_list',['problemsbytopic'=>$problemsbytopic,'topic_name'=>$topic_name,'topic_id'=>$topic_id,'probsolvedbystud'=>$probsolvedbystud]);
    }

    public function displayProfile($id){

        //select sum(points earned) where student_id = $id 

        $user_id = $id;
        $problems = DB::table('problems')->get();
        //inner join with problems
        $stud_problem_solved = DB::table('student_problem_solved_and_badges')->join('problems', 'student_problem_solved_and_badges.problem_id', '=', 'problems.id')->where('student_problem_solved_and_badges.student_id', $user_id)->get(); // select * from student_problem_solved where student_id = user_id
        $stud_points = DB::table('student_points')->where('student_id', $user_id)->get(); //select * from student_points where student_id = user_id
        
        $studfinProblem = DB::table('stud_fin_prob_log')
        ->join('problems', 'stud_fin_prob_log.problem_id', '=', 'problems.id')
        ->where('stud_fin_prob_log.student_id', $user_id)->get();

        //select * from stud_problem_performance_log where student_id = $id
        $studProbPerf = DB::table('stud_problem_performance_log')
        ->select(DB::raw('problems.title,count(attempt) as attempt,max(total_points) as total_points,max(badge) as badge'))
        ->join('problems', 'stud_problem_performance_log.problem_id', '=', 'problems.id')
        ->where('student_id', $user_id)
        ->groupBy('problem_id')
        ->get();

        //select badges from stud_fin_topic join topics on on s.topic_id= topic.id where studid = 
        $studBadges = DB::table('stud_fin_topic')
         ->select(DB::raw('badge'))
         ->join('topics','stud_fin_topic.topic_id','=','topics.id')
         ->where('student_id', $user_id)
         ->get();

        return view('student/view_profile',['studfinProblem'=>$studfinProblem,'studProbPerf'=>$studProbPerf,'problems'=>$problems,'studBadges'=>$studBadges]);
    }

    public function updateAvatar($avatarname,$id){
        DB::table('users')
            ->where('id', $id)
            ->update(['avatar'=> $avatarname]);
            $url = "/users/view_profile/".$id;
        return redirect($url);
    }

    public function displayProblemTutorial($student_id,$topic_id,$problem_id){
        //to get the problem details
        $problem = DB::table('problems')->where('id', $problem_id)->get(); 
        //to get the total # of steps 
        $steps = DB::table('topic_steps')->where('topic_id', $topic_id)->get(); 
        //to get all the questions needed for each problem
        $questions = DB::table('questions')->where('topic_id', $topic_id)->orderBy('step_order')->get(); 
        //to determine the # of attempt of student per problem
        $prob_perf_log = DB::table('stud_problem_performance_log')->whereStudent_idAndProblem_id($student_id,$problem_id)->get();
        //to get the topic title
        $topics = DB::table('topics')->where('id', $topic_id)->get(); 
        return view('student/problem_solving_tutorial',['topics'=>$topics,'problem'=>$problem,'steps'=>$steps,'questions'=>$questions,'prob_perf_log'=> $prob_perf_log]);
    }

    public function savePerformance($user_id,$p_perf,$q_perf){
        //  save/user_id/question_perf/problem_perf

        $pDetail = explode("-", $p_perf);

        //STUD_PROBLEM_PERFORMANCE_LOG
        $student_id = $user_id;
        $problem_id = $pDetail[0];
        $attempt = $pDetail[1];
        $data =$pDetail[2];
        $date = date('Y-m-d H:i:s'); //DateTime
        $total_points = $pDetail[3];
        $max_points = $pDetail[4];
        $badge = $pDetail[5];

        DB::table('stud_problem_performance_log')->insert(
        ['student_id' => $student_id, 
         'problem_id' => $problem_id,
         'attempt'=>$attempt,
         'data'=>$data,
         'date'=>$date,
         'total_points'=>$total_points,
         'max_points'=>$max_points,
         'badge'=>$badge]
        );

        //Loop this according to $question
        //STUD_QUESTION_PERFORMANCE_LOG

        $question = array();
        $question = explode("*", $q_perf); 

        $totalFault = 0;

        for($i=0;$i<count($question);$i++){
            $qDetail = explode("-", $question[$i]);

            //$student_id = 0;
            $problem_code = $qDetail[0];
            $question_id = $qDetail[1];
            $q_attempt = $qDetail[2];
            $fault = $qDetail[3];
            $help_log = $qDetail[4];
            $points = $qDetail[5];

            $totalFault = $totalFault + $fault;

        DB::table('stud_questions_performance_log')->insert(
        ['student_id' => $student_id,
         'problem_code' => $problem_code,
         'question_id'=>$question_id,
         'attempt'=>$q_attempt,
         'fault'=>$fault,
         'help_log'=>$help_log,
         'points'=>$points]
        );
        }  

        //STUD_FIN_PROBLEM
        //check if the problem is solved or not

        $finProblem = DB::table('stud_fin_prob_log')->whereStudent_idAndProblem_id($student_id,$problem_id)->get();

        if(count($finProblem)<=0){
            DB::table('stud_fin_prob_log')->insert(
                ['student_id' => $student_id, 
                 'problem_id' => $problem_id]);
        }else{ //do not save

        }

        //starbadge file name
        if($badge==1){
            $sbadge = "p-star-1.png";
        }else if($badge==2){
            $sbadge = "p-star-2.png";
        }else if($badge==3){
            $sbadge = "p-star-3.png";
        }

        $topic = DB::table('problems')
        ->select(DB::raw('topic_id'))
        ->where('id', $problem_id)->get(); 

        $topicId = 0;

        foreach ($topic as $topics) {
            $topicId = $topics->topic_id;
           // echo $topicId;
        }

     


        //---Check for skill badge
        //$problemsByTopic = select id from problems where topic_id = $topic;
        $problemsByTopic = DB::table('problems')
        ->select(DB::raw('id'))
        ->where('topic_id', $topicId)->get(); 
        //$studFinProblems = select problem_id from stud_fin_prob_log where student_id = $student_id
        
        //all problems solved by student
        $studFinProblems = DB::table('stud_fin_prob_log')
        ->select(DB::raw('problem_id'))
        ->where('student_id',$student_id )->get(); 
        
        $cntProblemSolved = 0;
        $cntAllProblems = 0;
        $probByTopic = array();
        $studFinProb = array();

        foreach ($problemsByTopic as $problemsByTopic){
            $cntAllProblems++;
            //echo $problemsByTopic->id;
            array_push($probByTopic, $problemsByTopic->id);
        }

        foreach ($studFinProblems as $studFinProblems) {
             array_push($studFinProb,$studFinProblems->problem_id);
        }

        for($i=0;$i<count($probByTopic);$i++){
           for($j=0;$j<count($studFinProb);$j++){
            if($probByTopic[$i]==$studFinProb[$j]){
                $cntProblemSolved++;
               // echo $probByTopic[$i]."-".$studFinProb[$j]."<br>";
            }
           } 
        }

        $skillBadge = 0;
        $topicComplete = 0;
        if($cntAllProblems==$cntProblemSolved){
           // echo "Skill Badge";

            // check skill badge duplication
            $skillBadgebyStudent = DB::table('stud_fin_topic')->whereStudent_idAndTopic_id($student_id,$topicId)->get();
            
            if(count($skillBadgebyStudent)==0){
                  $skillBadge = 1;

            DB::table('stud_fin_topic')->insert(
                ['student_id' => $student_id, 
                 'topic_id' => $topicId]);
            }else{
                $skillBadge = 0;
            }

            $topicComplete = 1;
        }else{
            //echo "No skill badge";
            $skillBadge = 0;
            $topicComplete = 0;
        }

        //check if all the problems are finished
        //select all problems and compare to $studFinProblems
        $allProblemsList = DB::table('problems')->select()->get();


        // echo count($studFinProb);
        // echo "<br>";
        // echo count($allProblemsList);

        if(count($studFinProb)==count($allProblemsList)){
            return view('student/course_completion');
        }
        else{
          return view('student/problem_completion',['topicComplete'=>$topicComplete,'skillBadge'=>$skillBadge,'topic'=>$topic,'problem_id'=>$problem_id,'total_points'=>$total_points,'max_points'=>$max_points,'totalFault'=>$totalFault,'sbadge'=>$sbadge]);  
        }

       
        
    }

    function displayCalculator(){
       return view('student/calculator'); 
    }

    public function displayLesson(){
         $topics = Topic::all();
        return view('student/lesson_list',['topics'=>$topics]);
    }

    public function displayLessonTopic($student_id,$topicId,$problem_id){

        //-----include problem_id
        //open the lesson for a topic
        //log of accessing the topic
        //insert into stud_lesson_access_log
         $date = date('Y-m-d H:i:s'); //DateTime
         DB::table('stud_lesson_access_log')->insert(
                ['student_id' => $student_id, 
                 'topic_id' => $topicId,
                 'problem_id'=>$problem_id,
                  'date'=>$date]);

        $singletopic = DB::table('topics')->where('id', $topicId)->get();

        return view('student/lesson_page',['singletopic'=>$singletopic]);
    }

    public function displayTopicLesson($student_id,$topicName,$problem_id){
        $date = date('Y-m-d H:i:s'); //DateTime
         DB::table('stud_lesson_access_log')->insert(
                ['student_id' => $student_id, 
                 'topic_name' => $topicName,
                 'problem_id'=>$problem_id,
                  'date'=>$date]);

        $url = "lesson/".$topicName;
        return view($url);

    }

    public function displayLeaderboard()
    {
        //$profile = User::find($id);
        // select * from student_points, group by student_id,date sum(points_earned) order by sum points
        // where date equals today
        // $leaderboard = DB::table('student_points')
        //                 ->select(DB::raw('sum(points_earned) as points_earned, fname,lname'))
        //                 ->join('users', 'student_points.student_id', '=', 'users.id')
        //                 ->take(10)
        //                 ->orderBy('points_earned','desc')
        //                 ->groupBy('student_id')
        //                 ->get();

         $allStudPerf = DB::table('stud_problem_performance_log')
        ->select(DB::raw('student_id,fname,lname,max(attempt) as attempt,max(total_points) as points_earned'))
        ->join('users', 'stud_problem_performance_log.student_id', '=', 'users.id')
        ->groupBy('student_id','problem_id')
        ->get();

        //select student_id,fname,lname,

        // foreach ($allStudPerf as $sta) {
        //     echo print_r($sta);
        //     echo "<br>";
        // }



        $userList = DB::table('stud_problem_performance_log')
        ->select(DB::raw('student_id,fname,lname'))
        ->join('users', 'stud_problem_performance_log.student_id', '=', 'users.id')
        ->groupBy('student_id')->get();

       // echo "<br>";
        //print_r($userList);

        $user_fname = array();
        $user_lname = array();
        $user_total_points = array();
        $user_attempt = array();
        foreach ($userList as $userList) {
            $sum = 0;
            $sum_attempt = 0;
            foreach ($allStudPerf as $st) {
                if($userList->student_id==$st->student_id){
                    $sum = $sum + $st->points_earned;
                    $sum_attempt = $sum_attempt + $st->attempt;
                }
                }

            //echo "User ID:".$userList->fname." total-->".$sum."<br>";
          //  echo "U_ID:".$st->student_id."<br>";
            array_push($user_fname,$userList->fname);
            array_push($user_lname,$userList->lname);
            array_push($user_total_points,$sum);
            array_push($user_attempt,$sum_attempt);
            
        }
        
       
        DB::table('all_stud_performance')->truncate();
        for($i=0;$i<count($user_fname);$i++){
        DB::table('all_stud_performance')->insert(
                ['fname' => $user_fname[$i], 
                 'lname' => $user_lname[$i],
                 'total_attempt'=>$user_attempt[$i],
                 'total_points'=>$user_total_points[$i]]);
        }

        $allStudPerfList = DB::table('all_stud_performance')
        ->orderBy('total_points', 'desc','total_attempt','asc')
        ->get();

        // foreach ($allStudPerfList as $spa) {
        //     print_r($spa);
        //     echo "<br>";
        // }

        
        return view('student/leaderboard',['allStudPerfList'=>$allStudPerfList]);
    }


    public function displayAccountSettings(){
        //$profile = User::find($id);
        return view('student/account_settings');
    }

    public function updateAccountInfo(Request $request, $id){
        $this->validate($request,[
            'fname' => 'required',
            'lname' => 'required',
            'age' => 'required',
            'gender' => 'required',
            'email' => 'required'
            ]);

            $data = array(
                'fname' => $request->input('fname'),
                'lname' => $request->input('lname'),
                'age' => $request->input('age'),
                'gender' => $request->input('gender'),
                'email' => $request->input('email')
                );
            User::where('id',$id)->update($data);
            
          return redirect('/users/settings')->with('info','Profile Updated Successfully');
    }

    public function updatePassword(Request $request){

        // hash the input current password
        //verify the correctness of inputed current password if equal
        // check if new password field and current password field is equal
        // hash the new password field and save 

        if (!(Hash::check($request->get('current-password'), Auth::user()->password))) {
            // The passwords matches
            return redirect()->back()->with("error","Your current password does not matches with the password you provided. Please try again.");
        }
 
        if(strcmp($request->get('current-password'), $request->get('new-password')) == 0){
            //Current password and new password are same
            return redirect()->back()->with("error","New Password cannot be same as your current password. Please choose a different password.");
        }
 
        // $validatedData = $request->validate([
        //     'current-password' => 'required',
        //     'new-password' => 'required|string|min:6|confirmed',
        // ]);
 
        //Change Password
        $user = Auth::user();
        $user->password = bcrypt($request->get('new-password'));
        $user->save();
 
        return redirect()->back()->with("success","Password changed successfully !");

    }





//------TEMP METHODS


        public function resumetoLatestProblem($id){
        //select max(id) 
        
        $stud_id = $id;
        // select max(id) from _ where student_id = _ 
        $MaxId = DB::table('student_problem_solved_and_badges')
                        ->select(DB::raw('max(id) as maxid'))
                        ->where('student_id', $stud_id)
                        ->get();
        //get the $currentProblem->problem_id with maximum id then add one 
         $currentProblem= "";
         $maximum_id = 0;
         foreach ($MaxId as $Max_Id) {
              $maximum_id = $Max_Id->maxid;
         }

         
         $nextproblem = $maximum_id+1;
         // go to users/problemsolving/{user_id}/{prob_id}
         $resume_url = "/users/problemsolving/".$stud_id."/".$nextproblem;
         return redirect($resume_url);
    }

    public function displayProgressLevel($id){
        $user_id = $id;
        $subtopic = SubTopic::all();
        //$problems = DB::table('problems')->get();
        $problems = Problem::all();
        $stud_problem_solved = DB::table('student_problem_solved_and_badges')->where('student_id', $user_id)->get();
        return view('student/level_progression',['subtopic' => $subtopic,'problems'=> $problems,'stud_problem_solved'=>$stud_problem_solved,'user_id'=>$user_id]);
    }

    public function displayProblem($user_id,$id){
        $prob_id = $id;

        $problems = DB::table('problems')->where('id', $prob_id)->get();
        $problem_task = DB::table('problem_tasks_and_ans')->where('problem_id', $prob_id)->get();
        $problem_step_guide = DB::table('problem_step_by_step_guide')->where('problem_id', $prob_id)->get();

        $stud_problem_solved = DB::table('student_problem_solved_and_badges')->whereStudent_idAndProblem_id($user_id,$prob_id)->get();
        //if problem is unlocked

        $counter = count($stud_problem_solved);
        
        return view('student/problem_solving',['problems'=>$problems,'problem_task'=>$problem_task,'problem_step_guide'=>$problem_step_guide,'user_id'=>$user_id]);
    }

    

    public function continueToNextProblem($id){

    }

    public function displayDashboard()
    {
        return view('student/dashboard');
    }
   
     public function displayEditProfile($id)
    {
        $profile = User::find($id);
        return view('student/edit_profile',['profile' => $profile]);
    }

    public function displaySubTopicProgress(){
        return view('student/subtopic_progression');
    }

    public function updateSubTopicProgress(){
        return view('student/subtopic_progression');
    }

    public function changePassword(){
        echo "Hello";
    }

}
