<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StudentUserLog extends Model
{
    //
}
