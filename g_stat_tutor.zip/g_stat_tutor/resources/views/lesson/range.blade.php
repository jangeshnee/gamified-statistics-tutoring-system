<!DOCTYPE html>
<html>
<head>
<title>Lesson: Range</title>

<link href="{{ asset('css/app.css') }}" rel="stylesheet"> 
<link href="{{ asset('css/mystyle.css') }}" rel="stylesheet">

<style>
body{
	background: #3e4a5a;
}

</style>
</head>

<body>

<div class="row">
	<div class="col-md-6">
	<div style="padding:10px;margin:15px">	
				<h1 class="lesson-title">Range</h1>
		
		<p class="lesson-def"><b>Definition: </b>The <b>range</b> is the difference between the largest and smallest values of a data distribution.</p>

		<div class="lesson-def">
		<p>Example: Find the range of this data set: <b>{6, 8, 11, 10, 8, 7, 13}</b></p> 
		<p class="lesson-step">Steps:</p> 

		<p class="lesson-step">Find the largest value in the data set.</p> 
		<p>6, 8, 11, 10, 8, 7, <b>13</b></p>
		<p> The largest value in the data set is 13.<p>
		<p class="lesson-step">Find the smallest value in the data set. </p>
		<p><b>6</b>, 8, 11, 10, 8, 7, 13</p> 
		<p> The smallest value in the data set is 6.
		<p class="lesson-step">Determine the range by finding the difference of smallest and largest value:</p> 
		<p> 13 - 6 = 7</p>
		<p><b><i>The range of the data set is 7.</i></b></p>
		</div>
		
		
	</div>
	</div>
</div>

</body>
</html>
