<!DOCTYPE html>
<html>
<head>
<title>Lesson: Mean</title>

<link href="{{ asset('css/app.css') }}" rel="stylesheet"> 
<link href="{{ asset('css/mystyle.css') }}" rel="stylesheet">

<style>
body{
	background: #3e4a5a;
}

</style>
</head>

<body>

<div class="row">
	<div class="col-md-6">
	<div style="padding:10px;margin:15px">
		<h1 class="lesson-title">Mean</h1>
		<div class="lesson-def">
			<p><b>Definition: </b>The <b>mean</b> is the most <b>common measure</b> of average.</p>
		</div>

		<div class="lesson-def">
		To find the mean of a group of numbers, add all of the values in the data set and then divide by the number of values in the data set.	
		</div>

		<div class="lesson-def">
		<p>Example: Find the mean of this data set: <b>{6, 9, 7, 5, 4, 9, 9}</b></p>
		<p class="lesson-step">Steps:</p>
		<p class="lesson-step">Add all of the values in the data set:</p>
		<p>6 + 9 + 7 + 5 + 4 + 9 + 9 = 49</p>
		<p class="lesson-step">Divide the sum by the number of values in the data set:</p>
		<p> Sum is 49 and number of values is 7.</p>
		<p>49 / 7 = 7</p>
		<p><b><i>The mean is 7.</i></b></p>
		</div>

		<div class="lesson-def">
		<p>The <b>mean</b> can also be a <b>decimal</b>. Look at the next example:</p>
		<p>Example: Find the mean of the data set <b>{9,8,9,8,8}</b></p>
		<p class="lesson-step">Steps:</p>
		<p class="lesson-step">Add all of the values in the data set:</p>
		<p>9 + 8 + 9 + 8 + 8 = 42</p>
		<p class="lesson-step">Divide the sum by the number of values in the data set:</p>
		<p> Sum is 42 and number of values is 5.</p>
		<p>42 / 5 = 8.4</p>
		<p><b><i>The mean is 8.4.</i></b></p>
		<p><i>Notice that the mean score is not an actual value in the data set.</i></p>
		</div>

		


	</div>
	</div>
</div>

</body>
</html>
