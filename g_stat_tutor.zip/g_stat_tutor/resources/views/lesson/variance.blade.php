<!DOCTYPE html>
<html>
<head>
<title>Lesson: Variance</title>

<link href="{{ asset('css/app.css') }}" rel="stylesheet"> 
<link href="{{ asset('css/mystyle.css') }}" rel="stylesheet">

<style>
body{
	background: #3e4a5a;
}

</style>
</head>

<body>

<div class="row">
	<div class="col-md-6">
	<div style="padding:10px;margin:15px">	
				<h1 class="lesson-title">Variance</h1>
		
		<p class="lesson-def"><b>Definition: </b>The <b>variance</b> measures how far a data set is spread out.</p>
		

		<div class="lesson-def">
		<p>Example: Find the variance of this data set: <b>{25,20,22,25,25}</b></p> 
		<p class="lesson-step">Steps:</p> 
		<p class="lesson-step">Find the mean of the data set.</p> 
		<p>Add all the values in the data set:</p>
		<p>25 + 20 + 22 + 25 + 25 = 117</p>
		<p>Divide the sum by the number of values in the data set:</p>
		117 / 5 = 23.40

		<p> <i>The mean is 23.40</i></p>
		<p class="lesson-step">Find the sum of squared difference of mean to each data.</p> 

		<p>Subtracting the mean to each data:</p> 
		<p>25 - 23.40 = 1.60</p>
		<p>20 - 23.40 = -3.40</p>
		<p>22 - 23.40 = -1.40</p>
		<p>25 - 23.40 = 1.60</p>
		<p>25 - 23.40 = 1.60</p>

		<p>Squaring each of the difference:</p> 
		<p>1.60 x 1.60 = 2.56</p> </p> 
		<p>-3.40 x -3.40 = 11.56</p> 
		<p>-1.40 x -1.40 = 1.96</p> 
		<p>1.60 x 1.60 = 2.56</p> 
		<p>1.60 x 1.60 = 2.56</p> 

		<p> Finally, adding the squared values:</p> 
		<p> 2.56 + 11.56 + 1.96 + 2.56 + 2.56 = 21.20. </p> 
		<p><i>The sum of squared difference of mean to each data is 21.20</i></p>

		<p class="lesson-step">Determine the variance by dividing the sum of squared difference of mean to each data point by the total number of values in the data set.</p> 

		<p>21.20 / 5 =	4.24 </p>
		
		<p><b><i>The variance of the data set is 4.24</i></b></p>
		</div>
		
		
	</div>
	</div>
</div>

</body>
</html>
