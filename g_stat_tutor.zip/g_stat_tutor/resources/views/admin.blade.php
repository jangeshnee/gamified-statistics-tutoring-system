@extends('layouts.app1')

@section('content')
<div class="container">

  <br> <br><br><br><br><br><br>
    <div class="row">
        <div class="col-md-10 col-md-offset-2">
           <div class="row">
                <div class="col-md-4">
                  <a href="{{url('admin/course_structure')}}"><img src="{{ url ('icons/002-library.png')}}" width="50%" height="50%"></a><br>
                  <h4>Course Topic Structure</h4>
                </div>
                 <div class="col-md-4">
                   <a href="{{url('problem/list/all')}}"><img src="{{ url ('icons/003-chat.png')}}" width="50%" height="50%"></a><br>
                   <h4>Problems and Script</h4> 
                </div>
                 <div class="col-md-4">
                   <a href="{{url('admin/userslist')}}"><img src="{{ url ('icons/004-hierarchical-structure.png')}}" width="50%" height="50%" ></a><br>
                   <h4>User List and Logs</h4>
                </div>
            </div>
        </div>

    </div>


  
</div>
@endsection
