@extends('layouts.app')
@section('content')
<div class="container">
		<div class="row">
		<legend>View Course</legend>
		<p class="lead"> {{$course->name}} </p>
		<p> {{$course->description}} </p>
	</div>
	</div>

 @endsection