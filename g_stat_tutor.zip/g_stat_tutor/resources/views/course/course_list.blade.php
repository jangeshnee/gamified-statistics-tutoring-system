@extends('layouts.app1')
@section('content')
    <div class="container">
        <div class="row">
             <div class="col-md-10 col-md-offset-1">
                <ol class="breadcrumb"> 
                    <li><a href='{{url("/admin")}}'>Dashboard</a></li> 
                    <li><a href='{{url("/course/list")}}'>Course Management</a></li> 
                </ol>
             </div>
        </div>        

        <div class="row">
             <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                    <div class="panel-heading">COURSE MANAGEMENT</div>
                    <div class="panel-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif
                        <a href='/course/create' class="btn btn-primary">NEW COURSE</a> <br>
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr> 
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Description</th>
                                        <th>Actions</th>
                                       
                                    </tr>
                                </thead>
                                <tbody>
                                    @if(count($course) > 0)
                                        @foreach($course->all() as $course)

                                            <tr> 
                                                
                                                <td>{{ $course->id }}</td>
                                                <td>{{ $course->name }}</td>
                                                <td>{{ $course->description }}</td>
                                                <td>
                                                    <a href='{{ url("topic/list/{$course->id}") }}' class="btn btn-success">Manage Topics</a>
                                                    <a href='{{ url("course/edit/{$course->id}") }}' class="btn btn-warning">Update</a>
                                                    <a href='{{ url("course/delete/{$course->id}") }}' class="btn btn-danger">Delete</a>
                                                </td>
                                            </tr>
                                @endforeach
                                    @endif
                                </tbody>
                            </table>


                    </div>
                </div>
            </div>
        </div>   

    </div>
    
    @endsection


