@extends('layouts.app1')
@section('content')
    <div class="container">
        <div class="row">
             <div class="col-md-10 col-md-offset-1">
                <ol class="breadcrumb"> 
                    <li><a href='{{url("/admin")}}'>Dashboard</a></li> 
                    <li><a href='{{url("/course/list")}}'>Course Syllabus</a></li> 
                </ol>
             </div>
        </div>        

        <div class="row">
             <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                    <div class="panel-heading">COURSE SYLLABUS</div>
                    <div class="panel-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif
                        <a href='/course/create' class="btn btn-primary">MANAGE COURSE</a> <br>
                          <br>  
                        @if(count($topic) > 0)
                        @foreach($topic->all() as $topic)
                            <li> <b>{{ $topic->title }} </b></li>

                           
                                @foreach($subtopic->all() as $subtopic)
                                    @if($subtopic->topic_id == $topic->id)
                                    <a> {{ $subtopic->title }} </a> <br>
                                    @endif
                                @endforeach
                          
                        @endforeach
                    @endif

                    </div>
                </div>
            </div>
        </div>   

    </div>
    
    @endsection


