@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
             <div class="col-md-10 col-md-offset-1">
                <ol class="breadcrumb"> 
                    <li><a href='{{url("/admin")}}'>Dashboard</a></li> 
                    <li><a href='{{url("/admin/userslist")}}'>User List and Logs</a></li>
           
                </ol>
             </div>
        </div>


    <div class="row">
        <div class="col-md-10 col-md-offset-1">

            <ul class="nav nav-tabs"> 
              <li class="active"><a href='{{url("admin/userslist#ulist")}}' data-toggle="tab">User List</a></li>
              <li><a href='{{url("admin/userslist#ulogs")}}' data-toggle="tab">User Logs</a></li> 
            </ul>

             <!-- Tab panes -->
            <div class="tab-content">
              <div class="tab-pane fade in active" id="ulist">
                      <table class="table table-striped table-hover">
                <thead>
                    <tr> 
                        <th>ID</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Age</th>
                        <th>Gender</th>
                       
                    </tr>
                </thead>
                <tbody>
                    @if(count($users) > 0)
                        @foreach($users->all() as $users)

                            <tr> 
                                
                                <td>{{ $users->id }}</td>
                                <td>{{ $users->fname }}</td>
                                <td>{{ $users->lname }}</td>
                                <td>{{ $users->email }}</td>
                                <td>{{ $users->age }}</td>
                                <td>{{ $users->gender }}</td>
                                <td>
                                    <a href="#" class="label label-primary">View</a>
                                    <a href="#" class="label label-success">Update</a>
                                    <a href="#" class="label label-danger">Delete</a>
                                </td>
                            </tr>
                @endforeach
                    @endif
                </tbody>
            </table>
              </div>

              <div class="tab-pane fade in active" id="ulogs">
                    <h4>User Logs</h4>
                    
              </div>
            </div>


        </div>
    </div>
</div>
@endsection