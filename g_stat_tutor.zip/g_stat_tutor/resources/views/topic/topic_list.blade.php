@extends('layouts.app1')
@section('content')
    <div class="container">
        <div class="row">
             <div class="col-md-10 col-md-offset-1">
                <ol class="breadcrumb"> 
                    <li><a href='{{url("/admin")}}'>Dashboard</a></li> 
                    <li><a href='{{url("/course/list")}}'>Course Management</a></li>
                    <li><a href='{{url("/topic/list")}}'>Topics Management</a></li> 
                </ol>
             </div>
        </div>        

        <div class="row">
             <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                    <div class="panel-heading">TOPICS MANAGEMENT</div>
                    <div class="panel-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif
                        <a href='/topic/create' class="btn btn-primary">NEW TOPIC</a> <br>
                            <table class="table table-striped table-hover">
                <thead>
                    <tr> 
                        <th>ID</th>
                        <th>Course</th>
                        <th>Pre-req</th>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Actions</th>
                       
                    </tr>
                </thead>
                <tbody>
                    @if(count($topic) > 0)
                        @foreach($topic->all() as $topic)

                            <tr> 
                                
                                <td>{{ $topic->id }}</td>
                                <td>{{ $topic->course_id }}</td>
                                <td>{{ $topic->prereq_topic_id }}</td>
                                <td>{{ $topic->title }}</td>
                                <td>{{ $topic->description }}</td>
                                <td>
                                    <a href='{{ url("subtopic/list") }}' class="btn btn-success">Manage Subtopics</a>
                                    <a href='{{ url("topic/edit/{$topic->id}") }}' class="btn btn-warning">Update</a>
                                    <a href='{{ url("topic/delete/{$topic->id}") }}' class="btn btn-danger">Delete</a>
                                </td>
                            </tr>
                @endforeach
                    @endif
                </tbody>
            </table>


                    </div>
                </div>
            </div>
        </div>   

    </div>
    
    @endsection


