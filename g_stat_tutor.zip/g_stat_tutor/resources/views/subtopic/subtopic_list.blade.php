@extends('layouts.app1')
@section('content')
    <div class="container">
        <div class="row">
             <div class="col-md-10 col-md-offset-1">
                <ol class="breadcrumb"> 
                    <li><a href='{{url("/admin")}}'>Dashboard</a></li> 
                    <li><a href='{{url("/course/list")}}'>Course Management</a></li>
                    <li><a href='{{url("/topic/list")}}'>Topics Management</a></li>
                    <li><a href='{{url("/subtopic/list")}}'>SubTopics Management</a></li> 
                </ol>
             </div>
        </div>        

        <div class="row">
             <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                    <div class="panel-heading">SUBTOPICS MANAGEMENT</div>
                    <div class="panel-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif
                        <a href='/subtopic/create' class="btn btn-primary">NEW SUBTOPIC</a> <br>
                            <table class="table table-striped table-hover">
                <thead>
                    <tr> 
                        <th>ID</th>
                        <th>Topic</th>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Actions</th>
                       
                    </tr>
                </thead>
                <tbody>
                    @if(count($subtopic) > 0)
                        @foreach($subtopic->all() as $subtopic)

                            <tr> 
                                
                                <td>{{ $subtopic->id }}</td>
                                 <td>{{$subtopic->topic_id }}</td>
                                <td>{{ $subtopic->title }}</td>
                                <td>{{ $subtopic->description }}</td>
                                <td>
                                    <a href='{{ url("problem/list") }}' class="btn btn-success">Manage Problems</a>
                                    <a href='{{ url("subtopic/edit/{$subtopic->id}") }}' class="btn btn-warning">Update</a>
                                    <a href='{{ url("subtopic/delete/{$subtopic->id}") }}' class="btn btn-danger">Delete</a>
                                </td>
                            </tr>
                @endforeach
                    @endif
                </tbody>
            </table>

                    </div>
                </div>
            </div>
        </div>   

    </div>
    
    @endsection


