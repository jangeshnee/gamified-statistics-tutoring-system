@extends('layouts.app1')

@section('content')
<?php $rank_counter = 1;?>


              <div class="row">
                  <div class="col-md-12"> 
                    <div class="orange-header w3-animate-opacity" style="padding:10px;animation-duration:3s;">
                      <div class="w3-center w3-animate-zoom" style="animation-duration:3s;">Leaderboard</div>
                    </div>
                  </div>
              </div>
              <div class="row">
                <div class="col-md-12">


                    <div>
                       
                           <div class="table-responsive" style="margin-left:30px;margin-right:30px;">
                              <table class="table leaderboard-table">
                                   <tr class="leaderboard-table">
                                    <td class="mytable-header">Rank #</td>
                                    <td class="mytable-header">First Name</td>
                                    <td class="mytable-header">Last Name</td>
                                    <td class="mytable-header">Attempts</td>
                                    <td class="mytable-header">Points</td>
                                  </tr>

                                  @foreach($allStudPerfList->all() as $allStudPerfList) 
                                  <tr class='leaderboard-table'>
                                        <td class='mytable-td-rank'>{{$rank_counter}}</td>
                                        <td class='mytable-td'>{{$allStudPerfList->fname}}</td>
                                        <td class='mytable-td'>{{$allStudPerfList->lname}}</td>
                                        <td class='mytable-td'>{{$allStudPerfList->total_attempt}}</td>
                                        <td class='mytable-td'>{{$allStudPerfList->total_points}}</td>
                                  </tr>
                                  <?php $rank_counter++; ?>
                                  @endforeach

                                  @if ($rank_counter < 10)

                                  @for ($i = 0; $i <= $rank_counter; $i++)
                                  <tr class='leaderboard-table'>
                                        <td class='mytable-td-rank'>{{$rank_counter+$i}}</td>
                                        <td class='mytable-td'></td>
                                        <td class='mytable-td'></td>
                                        <td class='mytable-td'></td>
                                         <td class='mytable-td'></td>
                                  </tr>
                                  @endfor
                                  
                                  
                                  @else
                                  @endif

                              
                              </table>
                          </div>
                    </div>
                          
                       
                </div>
              </div>  
               
              
@endsection


