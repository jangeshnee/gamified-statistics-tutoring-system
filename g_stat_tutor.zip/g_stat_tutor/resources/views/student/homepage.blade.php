@extends('layouts.app1')

@section('content')

<?php 
$topic_title = array();
$topic_id = array();
$topic_color = array();
$totaltopic = 0;
$user_id = Auth::user()->id;
?>

 @foreach($topic->all() as $topic)
 <?php 
array_push($topic_title, $topic->title);
array_push($topic_id, $topic->id);
array_push($topic_color, $topic->background_color);
$totaltopic++;
 ?>
 @endforeach



<?php
$m = 0;
$c = 0;
$topicCnt = $totaltopic;
$numrow = ceil($totaltopic/3);
for($i=0;$i<$numrow;$i++){

echo "<div class='row'>";
    if($topicCnt<3){
        $c = $topicCnt;
    }
    else{
        $c = 3;
        $topicCnt = $topicCnt - 3;
    }
    for($n=0;$n<$c;$n++){
        echo 
        "<div class='col-md-4'><a class='topic-link' href='/users/topicproblemlist/".$user_id."/".$topic_id[$m]."'><div class='topic-box w3-animate-zoom' style='animation-duration:5s;background:".$topic_color[$m].";'>"."Level:".$topic_id[$m]."<br><b>".$topic_title[$m]."</b></div></a></div>";
        
        $m++;
    }

echo "</div>";
}

?>



<!-- Start of Content  -->
<!-- href="/users/topicproblemlist/{topic_id}"  row = totaltopic/3 -->
          <!--   <div class="row">
                <div class="col-md-4"><a class="topic-link" href="#"><div class="light-orange-box">{{$topic_title[1]}}</div></a></div>
                <div class="col-md-4"><a class="topic-link" href="#"><div class="light-green-box">Median</div></a></div>
                <div class="col-md-4"><a class="topic-link" href="#"><div class="red-orange-box">Mean</div></a></div>
            </div>

            <div class="row">
                <div class="col-md-4"><a class="topic-link" href="#"><div class="light-blue-box">Range</div></a></div>
                <div class="col-md-4"><a class="topic-link" href="#"><div class="orange-box">Variance</div></a></div>
                <div class="col-md-4"><a class="topic-link" href="#"><div class="red-box">Standard Deviation</div></a></div>
            </div> -->
        

@endsection
