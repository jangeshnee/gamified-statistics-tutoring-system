<?php 
// get total number of problems, student_solved_problems
// solve total progress 
// conditions statements for badges

?>

@extends('layouts.app1')

@section('content')
<?php 
$total_points=0; 
$all_problems = 0; 
$solved_problems=0;
$progress_percent = 0;
$cnt = 0;
$avatar_filename = Auth::user()->avatar;
$user_gender = Auth::user()->gender;
$users_solved_problems_titles = array();
$users_solved_problems_badge = array();
$user_id = Auth::user()->id;

$cntSkillBadge=0;
$avatar_female = array();
//array_push();
$avatar_male = array();


?>

@foreach($problems->all() as $problems) <!-- Count All Problems -->
     <?php $all_problems++; ?>
@endforeach

@foreach($studProbPerf->all() as $studProbPerfs)
<?php $total_points = $total_points + $studProbPerfs->total_points?>
@endforeach

@foreach($studBadges->all() as $studBadges1)
<?php $cntSkillBadge++;?>
@endforeach


<?php $progress_percent = round(($solved_problems/$all_problems)*100); ?>
  
  <div class="row">
    <div class="col-md-12">
        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
        <div class="modal-content">
             <div class="modal-body ">
               <h1>Change Avatar</h1>
               <p>Select a predefined image that you would like to use for your avatar.</p>
                @if($user_gender=="Male")
                <div class="row">
                        <div class="col-md-3">
                          <?php $filename="default-male.png";?>
                          <a href="/users/updateavatar/{{$filename}}/{{$user_id}}">
                          <img src='{{ url("icons/avatar/default-male.png") }}' width="100%" height="100%">
                          </a>
                        </div>
                        <div class="col-md-3">
                          <?php $filename="boy-1.png";?>
                          <a href="/users/updateavatar/{{$filename}}/{{$user_id}}">
                           <img src='{{ url("icons/avatar/boy-1.png") }}' width="100%" height="100%">   
                          </a>
                        </div>
                        <div class="col-md-3">
                          <?php $filename="boy-2.png";?>
                          <a href="/users/updateavatar/{{$filename}}/{{$user_id}}">
                          <img src='{{ url("icons/avatar/boy-2.png") }}' width="100%" height="100%">
                          </a>
                        </div>
                        <div class="col-md-3">
                          <?php $filename="boy-3.png";?>
                          <a href="/users/updateavatar/{{$filename}}/{{$user_id}}">
                           <img src='{{ url("icons/avatar/boy-3.png") }}' width="100%" height="100%">   
                          </a>
                        </div>    
              </div>

              <div class="row">
                 <div class="col-md-3">
                          <?php $filename="boy-4.png";?>
                          <a href="/users/updateavatar/{{$filename}}/{{$user_id}}">
                           <img src='{{ url("icons/avatar/boy-4.png") }}' width="100%" height="100%">   
                          </a>
                        </div>
                        <div class="col-md-3">
                          <?php $filename="boy-5.png";?>
                          <a href="/users/updateavatar/{{$filename}}/{{$user_id}}">
                          <img src='{{ url("icons/avatar/boy-5.png") }}' width="100%" height="100%">
                          </a>
                        </div>
                        <div class="col-md-3">
                          <?php $filename="boy-6.png";?>
                          <a href="/users/updateavatar/{{$filename}}/{{$user_id}}">
                           <img src='{{ url("icons/avatar/boy-6.png") }}' width="100%" height="100%">   
                          </a>
                        </div>    
              
              </div>

                @else
                <div class="row">
                        <div class="col-md-3">
                          <?php $filename="default-female.png";?>
                          <a href="/users/updateavatar/{{$filename}}/{{$user_id}}">
                          <img src='{{ url("icons/avatar/default-female.png") }}' width="100%" height="100%">
                          </a>
                        </div>
                        <div class="col-md-3">
                          <?php $filename="girl-1.png";?>
                          <a href="/users/updateavatar/{{$filename}}/{{$user_id}}">
                           <img src='{{ url("icons/avatar/girl-1.png") }}' width="100%" height="100%">   
                          </a>
                        </div>
                        <div class="col-md-3">
                          <?php $filename="girl-2.png";?>
                          <a href="/users/updateavatar/{{$filename}}/{{$user_id}}">
                          <img src='{{ url("icons/avatar/girl-2.png") }}' width="100%" height="100%">
                          </a>
                        </div>
                        <div class="col-md-3">
                          <?php $filename="girl-3.png";?>
                          <a href="/users/updateavatar/{{$filename}}/{{$user_id}}">
                           <img src='{{ url("icons/avatar/girl-3.png") }}' width="100%" height="100%">   
                          </a>
                        </div>    
                </div>

                <div class="row">
                  <div class="col-md-3">
                          <?php $filename="girl-4.png";?>
                          <a href="/users/updateavatar/{{$filename}}/{{$user_id}}">
                          <img src='{{ url("icons/avatar/girl-4.png") }}' width="100%" height="100%">
                          </a>
                  </div>

                  <div class="col-md-3">
                          <?php $filename="girl-5.png";?>
                          <a href="/users/updateavatar/{{$filename}}/{{$user_id}}">
                          <img src='{{ url("icons/avatar/girl-5.png") }}' width="100%" height="100%">
                          </a>
                  </div>
                  <div class="col-md-3">
                          <?php $filename="girl-6.png";?>
                          <a href="/users/updateavatar/{{$filename}}/{{$user_id}}">
                          <img src='{{ url("icons/avatar/girl-6.png") }}' width="100%" height="100%">
                          </a>
                  </div>


                </div>

                @endif
            
            
              </div>
              <div class="modal-footer">
                
              </div>
      </div>
                                    <!-- /.modal-content -->
      </div>
                                <!-- /.modal-dialog -->
      </div>
    </div>

  </div>

  <div class="row">
        <div class="col-md-12">
           
            <div class="row">
              <div class="col-md-3">
                <div class="avatar-box">
                  @if($avatar_filename=="")
                    @if($user_gender=="Male")
                      <img src='{{ url("icons/avatar/default-male.png") }}' width="90%" height="90%">
                    @else
                      <img src='{{ url("icons/avatar/default-female.png") }}' width="90%" height="90%">
                    @endif
                  @else
                  <img src='{{ url("icons/avatar/{$avatar_filename}") }}' width="90%" height="90%">
                  @endif
               <center> <a href="#" style="color:#fff;text-decoration:none;" data-toggle="modal" data-target="#myModal">Change Avatar </a></center>
               
                </div>
                
              </div>

              <div class="col-md-6">
                <div class="profile-info-box">
                <h3>{{ Auth::user()->fname }} {{ Auth::user()->lname }}</h3>
                <p class="card-text">Age: <b>{{ Auth::user()->age }} </b></p>
                <p class="card-text">Gender: <b>{{ Auth::user()->gender }} </b></p>
              </div>
              </div>

              <div class="col-md-3">
                <div class="user-points-box">
                <h3>Points</h3>
                <!-- Solve Points -->
           

                <h2><?php echo $total_points;?></h2>
              </div>
              </div>

            </div>             
           </div>
        
     </div>

    <!-- % Progress Solving -->
    <div class="row">
      <div class="col-md-12">
        <div style="padding:10px;margin:15px">
            <ul id="myTab" class="nav nav-tabs"> 
              <li class="active"> <a href="#home" data-toggle="tab" style="background:#21d8de"> My Progress </a> </li>
              <li><a href="#badges" data-toggle="tab" style="background:#ffd55c">My Badges</a></li>
            </ul>
            <div id="myTabContent" class="tab-content">
              <div class="tab-pane fade in active" id="home" style="border-style:solid;border-width:5px;border-color:#21d8de"> 
               <div class="table-responsive" style="margin-left:30px;margin-right:30px;">
                  <br>
                              <table class="table">
                                   <tr>
                                    <td class="chart-header">#</td>
                                    <td class="chart-header">Problem Title</td>
                                    <td class="chart-header">Attempts</td>
                                    <td class="chart-header">Star</td>
                                    <td class="chart-header">Highest Score</td>
                                  </tr>

                                  <?php $cnt = 1 ?>
                                  @foreach($studProbPerf->all() as $studProbPerf)
                              
                                    <tr>
                                      <td>{{$cnt}}</td>
                                      <td> 
                                        {{$studProbPerf->title}}
                                      </td>
                                      <td class="chart-body" style="width:200px">
                                        {{$studProbPerf->attempt}}
                                      </td>
                                      
                                      <td class="chart-body" style="width:200px">
                                        
                                        @if($studProbPerf->badge==1)
                                        <img src='{{ url("icons/p-star-1.png") }}' width="50%" height="20%">
                                        @elseif($studProbPerf->badge==2)
                                        <img src='{{ url("icons/p-star-2.png") }}' width="50%" height="20%">
                                        @elseif($studProbPerf->badge==3)
                                        <img src='{{ url("icons/p-star-3.png") }}' width="50%" height="20%">
                                        @else
                                        @endif

                                      </td>
                                        
                                      <td class="chart-body" style="width:200px">{{$studProbPerf->total_points}}</td>
                                    </tr>
                                    <?php $cnt++;?>
                                @endforeach
                             
                              </table>
                          </div>
              </div> 
                <div class="tab-pane fade" id="badges" style="border-style:solid;border-width:5px;border-color:#ffd55c">
                  @if($cntSkillBadge==0)
                  <div class="row">
                    <div class="col-md-12">
                      <p>You did not have a skill badge yet</p>
                    </div>
                  </div>
                  @else


                  <div class="row">
                    @foreach($studBadges->all() as $studBadges)
                    <div class="col-md-2"> 
                      <div class="badge-box">
                      <img src='{{ url("icons/skill-badges/$studBadges->badge") }}' width="100%" height="100%">
                    </div>
                    </div>
                    @endforeach
                  </div> 
                  @endif
                </div>
            </div>
      </div>
      </div>
    </div>    


@endsection


