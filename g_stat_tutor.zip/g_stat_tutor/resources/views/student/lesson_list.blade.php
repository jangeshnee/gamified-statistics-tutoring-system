@extends('layouts.app1')

@section('content')


<?php $user_ID = Auth::user()->id;
$problem_id=0;
?>
<div class="row">
	<div class="col-md-8 col-md-offset-2"> 
	<div style="padding:30px;background:#ffd55c;margin:30px;color:#000;">	
		<h1>Lesson Pages List:</h1>
	<br>
	@foreach($topics->all() as $topics) 
		<p><a style="text-decoration:none;"href='{{url("users/mylessons/{$user_ID}/{$topics->title}/{$problem_id}")}}'>{{$topics->title}}</a></p>
	@endforeach
	
	</div>
</div> 
</div>

@endsection