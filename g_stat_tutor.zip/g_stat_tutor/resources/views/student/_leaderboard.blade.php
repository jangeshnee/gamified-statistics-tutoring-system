@extends('layouts.app')

@section('content')
<?php $rank_counter = 0; ?>
<div class="container">
    <div class="slide">
    <div class="row">
         <div class="col-md-12">
                <h3>Leaderboard</h3>
                
                <div class="table-responsive">
                <table class="table">
                     <tr>
                      <th>Rank #</th>
                      <th>First Name</th>
                      <th>Last Name</th>
                      <th>Points</th>
                    </tr>
                @foreach($leaderboard->all() as $leaderboard)
                <?php $rank_counter++; ?>
                <tr>
                  <td> {{$rank_counter}}</td>
                  <td>{{ $leaderboard->fname }}</td>
                  <td>{{ $leaderboard->lname }}</td>
                  <td>{{ $leaderboard->points_earned }}</td>
                </tr>
                @endforeach
                </table>
            </div>
                   
            </div>
            </div>
        </div>

</div>
@endsection


