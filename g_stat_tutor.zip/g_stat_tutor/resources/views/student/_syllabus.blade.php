@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-3">
            <center><img src="{{ url ('icons/005-girl.png')}}" width="70%" height="70%"></center> <br>

            <center><h4> {{ Auth::user()->fname }} {{ Auth::user()->lname }}</h4> </center>
            <ul class="nav nav-pills nav-stacked"> 
              <li><a href='{{url("users/view_profile")}}'>Profile</a></li> 
              <li><a href='{{url("users/settings")}}'>Account Settings</a></li> 
              <li><a href='{{url("users/leaderboard")}}'>Leaderboard</a></li> 
              <li  class="active"><a href='{{url("users/syllabus")}}'>Course Progress</a></li>  
            </ul>
        </div>
         <div class="col-md-8">
           <div class="panel panel-default">
                <div class="panel-heading">INTRODUCTION TO STATISTICS BANNER</div>

                <div class="panel-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif
                    <div class="progress progress-striped"> <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 150%;"> <span class="sr-only">30% Complete (info)</span> </div> </div>
                    <button type="submit" class="btn btn-success">
                                    RESUME
                    </button>
                </div>
            </div>

            <ul class="nav nav-tabs"> 
              <li class="active"><a href='{{url("/home#overview")}}' data-toggle="tab">Overview</a></li>
              <li><a href='{{url("/home#syllabus")}}' data-toggle="tab">Progress Details</a></li> 
            </ul>

             <!-- Tab panes -->
            <div class="tab-content">
              <div class="tab-pane fade in active" id="overview">
                    <h4>Overview</h4>
                     <p>This is an introductory course on Statistics. 
              This course will discuss the basic concepts of Statistics. 
              This course will also discuss the different measures of location 
              and variability. It will also explore the methods sampling 
              and designs of experiments as well as the very basics of testing 
              of hypotheses and analysis of variance</p>
              </div>

              <div class="tab-pane fade in active" id="syllabus">
                    <h4>Progress</h4>
                     <p><ul>
                     @if(count($topic) > 0)
                        @foreach($topic->all() as $topic)
                            <li> <b>{{ $topic->title }} </b></li>

                           
                                @foreach($subtopic->all() as $subtopic)
                                    @if($subtopic->topic_id == $topic->id)
                                    <a> {{ $subtopic->title }} </a> <br>
                                    @endif
                                @endforeach
                          
                        @endforeach
                    @endif
                </ul></p>
              </div>
            </div>

        </div>
    </div>
 

</div>
@endsection


