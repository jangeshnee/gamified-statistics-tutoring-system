<?php 
// get total number of problems, student_solved_problems
// solve total progress 
// conditions statements for badges

?>

@extends('layouts.app')

@section('content')
<?php 
$total_points=0; 
$all_problems = 0; 
$solved_problems=0;
$progress_percent = 0;
$cnt = 0;
$avatar_filename = Auth::user()->avatar;
$users_solved_problems_titles = array();
$users_solved_problems_badge = array();
$user_id = Auth::user()->id;
?>

@foreach($problems->all() as $problems) <!-- Count All Problems -->
     <?php $all_problems++; ?>
@endforeach

@foreach($stud_problem_solved->all() as $stud_problem_solved) <!-- Count All Solved Problems -->
     <?php $solved_problems++; 
     $users_solved_problems_titles[$cnt] = $stud_problem_solved->title;
    // $users_solved_problems_badge[$cnt] = $stud_problem_solved->badge;

     if($stud_problem_solved->badge==1){
      $users_solved_problems_badge[$cnt] = "onestar";
     }else if($stud_problem_solved->badge==2){
      $users_solved_problems_badge[$cnt] = "twostar";
     }else if($stud_problem_solved->badge==3){
      $users_solved_problems_badge[$cnt] = "threestar";
     }else{

     }


     $cnt++;
     ?> 
@endforeach



<?php $progress_percent = round(($solved_problems/$all_problems)*100); ?>
<div class="container">
  <div class="row">
        <div class="col-md-12">
           <div class="white-panel">
            <div class="row">
              <div class="col-md-2">
                <img src='{{ url("icons/{$avatar_filename}") }}' width="90%" height="90%">
                
              </div>
              <div class="col-md-8">
                <h3>{{ Auth::user()->fname }} {{ Auth::user()->lname }}</h3>
                <p class="card-text">Age: <b>{{ Auth::user()->age }} </b></p>
                <p class="card-text">Gender: <b>{{ Auth::user()->gender }} </b></p>
              </div>
              <div class="col-md-2">
                <h3>Points</h3>
                <!-- Solve Points -->
                @foreach($stud_points->all() as $stud_points)
                  <?php $total_points = $total_points + $stud_points->points_earned?>
                @endforeach

                <h2><?php echo $total_points;?></h2>
              </div>

            </div>             
           </div>
        </div>
     </div>

    <!-- % Progress Solving -->
    

     <div class="row">
        <div class="col-md-12">
          <div class="green-panel">
            <div class="green-header"> <h4> <b>Learning Progress  <?php echo $progress_percent."/100";?>  </b></h4></div>
            <div class="white-body">
            <div class="row">

                  <div class="col-md-10">
                   
                    <div class="progress">
                    <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $progress_percent ?>%;"></div>
                    </div>
                  
                  </div>
                  
                  <div class="col-md-2">
                    <a href='{{url("users/resume/{$user_id}")}}' class="btn btn-success">RESUME </a>
                  </div>

            </div>
          </div>
          
                   
          </div>
        </div>
     </div>


     <div class="row">
        <div class="col-md-12">
          <div class="red-panel">
            <div class="red-header"> <h4> <b>Achievements and Badges <?php echo $solved_problems."/".$all_problems; ?></b>  </h4></div>

              
              @for ($i=0;$i<$solved_problems;$i++)
              <div class="row">
                <div class="col-md-4"><p> {{$users_solved_problems_titles[$i]}} </p> </div>
                <?php $badge_filename =  $users_solved_problems_badge[$i].".png"; ?>
                <div class="col-md-2"> 
                <img src='{{ url("icons/{$badge_filename}") }}' width="70%" height="70%"></div>
               </div>
              @endfor
            

          </div>

        </div>
     </div>
 </div>
@endsection


