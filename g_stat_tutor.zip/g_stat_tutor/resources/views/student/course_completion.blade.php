@extends('layouts.app1')

@section('content')


<div class="row">
	<div class="col-md-8 col-md-offset-2"> 
	<div style="padding:30px;background:#ffd55c;margin:30px;color:#000;">	
		<center>
			<img src='{{ url("icons/tropie.png") }}'>
			<h1>Congratulations!</h1>
			<p>You completed all the problems</p>

		</center>

	<br>
	
	
	</div>
</div> 
</div>

@endsection