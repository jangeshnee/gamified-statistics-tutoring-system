<!DOCTYPE html>
<html>
<head>
<title>Lesson Page</title>

<link href="{{ asset('css/app.css') }}" rel="stylesheet"> 
<link href="{{ asset('css/mystyle.css') }}" rel="stylesheet">
</head>

<body>

<div class="row">
	<div class="col-md-12">
		@foreach($singletopic->all() as $singletopic) 
	
			<h2>{{$singletopic->title}}</h2>
			<p>{{$singletopic->description}}</p>
		@endforeach

	</div>
</div>

</body>
</html>

