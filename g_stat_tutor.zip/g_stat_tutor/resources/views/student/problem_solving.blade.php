@extends('layouts.app')

@section('content')

<?php // check the problem pre requisite here before display 
$maximum_score = 0;
$userid = $user_id; // to save points of the user

//
?>


<div class="container">
   
   <script src="{{ url('component/Bubbles.js')}}"></script>
   <script src="{{ url('js/computation_step_guide.js')}}"></script>
   <script src="{{ url('js/problem_solving.js')}}"></script>
   

  @foreach($problem_task->all() as $problem_tasks)
    <script> getTotalTaskandMaximumPoints('{{$problem_tasks->id}}','{{$problem_tasks->task_points}}')</script>
    
    <?php 
    $maximum_score = $maximum_score + $problem_tasks->task_points;
    ?>
  @endforeach

  <?php $current_problem_id; ?>

  @foreach($problems->all() as $problemss)
    <script> getProblemId('{{$problemss->id}}')</script>
    <?php $current_problem_id = $problemss->id + 1; ?>
  @endforeach


               <!--    @foreach($problem_step_guide->all() as $problem_step_guide)
                  <script> 
                  importStepGuide('{{$problem_step_guide->prob_task_id}}',
                    '{{$problem_step_guide->step_order}}',
                    '{{$problem_step_guide->demo_desc}}',
                    '{{$problem_step_guide->prompt_desc}}',
                    '{{$problem_step_guide->prompt_ans}}',
                    '{{$problem_step_guide->hint}}');
                           
                  </script>
                  @endforeach -->

<!-- <div class="row">
<div class="col-md-12">
<ul class="pager"> 
  <li class="previous"><a href="#">&larr; Previous</a></li> 
  <li class="next"><a href='{{url("users/problemsolving/$current_problem_id")}}'>Next &rarr;</a></li> 
</ul>
</div>

</div> -->


 	<div class="row">
     @foreach($problems->all() as $problems)

        <div class="col-lg-8 green-panel pn">  <!--style="background-color:#ffeead; padding:15px;box-shadow: 0px 3px 2px #aab2bd;"-->
   
              <div class="row">  <!-- Problem Title and Description -->
                <div class="col-lg-12">
                 
                  <h2 style="background: #43b1a9; padding: 3px; margin-bottom: 15px; color: white; text-align: center;"><b>{{ $problems->title }}</b></h2>
                  <p style="font-size: 1.5em; background-color:#ffffff;">{{ $problems->description }}</p>
                 
                </div>
              </div>

              <div class="row"> <!-- Problem Data List -->
                <div class="col-lg-12">
                  <!-- <p><h2>{{ $problems->data_list }}</h2> -->
                  <center>
                  <?php  
                  $cnt = $problems->data_list;
                  echo "<h2 id='listdata'>";
                  for($i=0;$i<$cnt;$i++){
                    echo rand(1,9)." ";

                  }
                  //echo "1 2 3 ";
                  echo "</h2>";

                  ?> 
                    </center>
                </p>
                </div>
              </div>

              <div class="row"> <!-- Task items -->
                <div class="col-lg-12">
                    <h3><b>Task items</b></h3> 
                  @foreach($problem_task->all() as $problem_task)
                  
                  <form class="form-horizontal" method="POST" action="{{ url('/') }}">

                    <div class="row">
                    <div class="col-lg-3" >
                    <label control-label>{{ $problem_task->task_title }}</label> 
                    </div>
                    
                    <div class="col-lg-5">
                      <input type="text" name="answer" placeholder="Your Answer Here" class="form-control" id="inputAnswer{{$problem_task->id}}" >
                    </div>
                    <div class="col-lg-3">
                    <!--<a href='{{ url("problem/check/{$problem_task->id}") }}' class="btn btn-primary">Check</a> -->
                    <input type="button" class="btn btn-primary" value="Check" onclick="checkAnswer('{{$problem_task->id}}','{{ $problem_task->task_ans_feedback }}','{{ $problem_task->task_points}}','{{ $problem_task->task_topic}}')" />
                    </div>
                    </div>
                    
                  </form>  
                  <br>
                 @endforeach

                </div>
              </div>
              <br><br><br><br><br><br>
              <div class="row" style="background-color:#f7464a; font-size:15px; font-weight:bold;"> <!--Points-->
                <div class="col-lg-4">
                  <!--<p id="taskAttempted">Task Attempted: </p> <!-- Task Attempted: -->
                  <h3 id="totalAttempts">Attempts: 0/3 </h3> <!-- Total Attempts: -->
                  <!-- <p id="currentPoints">Current Points:</p> <!-- Current Point: --> 
                </div>
                <div class="col-lg-4">
                   <h3 id="currentPoints">Points: 0/<?php echo $maximum_score?></h3>
                  
                  <!--<p id="deduction">Deduction Points:</p>  <!-- Deduction: -->
                  <!--<p id="totalPointss">Total Points:</p>  <!-- Total Points: -->
                </div>
                <div class="col-lg-4"> <h3 id="totalPointss">Total Points: 0/5</h3></div>
              </div>
   
          </div>
       
     @endforeach

          <div class="col-lg-4" style="padding:15px; box-shadow: 0px 3px 2px #aab2bd;">
       
                    <h3>TUTORIAL DIALOG</h3>

                      <!-- <div id="tutor" class="convo-panel"> 
                     </div>
                    <input type="text" name="prompt_ans" class="form-control" id="prompt_answer" >
                    <input type="button" class="btn btn-primary" value="Respond" onclick="getUserPromptResponse()" /> -->
                    <div id="chat"></div>

    <!-- import the JavaScript file -->
    
    <script>

var chatWindow = new Bubbles(document.getElementById("chat"), "chatWindow");


var phase_one_conversation = {
    ice: 
    { says: ["Hello there!","I am Stella and I would love to help you."], //,"<input type='text' name='num' id='nums' placeholder='ex. 1,3,5,6'>"
      reply: [
      {
        question: "Good morning",
        answer: "greet_1"
      },
      {
        question: "Hi Stella!",
        answer: "greet_2"
      }
      ,
      {
        question: "Hello!",
        answer: "greet_3"
      }
    ]
    },
  greet_1: {
    says: ["Good morning! In this problem there are item/s that you need to answer correctly.","Would you like me to help you solve the problem?"],
    reply: [
     {
        question: "No, Thanks!",
        answer: "instruct_to_solve"
      },
      {
        question: "Yes, Please!",
        answer: "instruct_to_read"
      }
    ]
  },
  greet_2: {
    says: ["Great! In this problem there are item/s that you need to answer correctly. ","Would you like me to help you solve the problem?"],
    reply: [
     {
        question: "No, Thanks!",
        answer: "instruct_to_solve"
      },
      {
        question: "Yes, Please!",
        answer: "instruct_to_read"
      }
    ]
  },
  greet_3: {
    says: ["Hi! In this problem there are item/s that you need to answer correctly.","Would you like me to help you solve the problem?"],
    reply: [
      {
        question: "No, Thanks!",
        answer: "instruct_to_solve"
      },
      {
        question: "Yes, Please!",
        answer: "instruct_to_read"
      }
    ]
  },
  instruct_to_read: {
    says: ["It's my pleasure to help you.", "First of all, I want you to read and understand the problem","Just tell me if you're done!"],
    reply: [{question: "I am done!", answer: "topicAndExample"}]
  },
  general_instruction: {
    says: ["Good! In this problem, you have to solve all the task items","(To be continue)"] // Concept script here 
  },
  instruct_to_solve: {
    says: ["Okay, carefully read the problem then enter your answer on the box and click the check it button. "],
    reply: [{question: "Start Over", answer: "ice"}]
  }
}


var phase_two_conversation = { 

define_the_topic: {
    says: ["Great! Definition here","Would you like me to show how to find the (topic)?"],
      reply: [
      {
        question: "No, Thanks!",
        answer: ""
      },
      {
        question: "Yes, Please!",
        answer: ""
      }
    ]
  }

}

chatWindow.talk(phase_one_conversation);

topicAndExample =  function() {

  chatWindow.talk(phase_two_conversation, "define_the_topic")
}

instructToSolve = function(){
  chatWindow.talk(phase_one_conversation, "instruct_to_solve")
}

</script>
                 
         
          </div>        
     </div>
    

     
             
   
 </div>


@endsection