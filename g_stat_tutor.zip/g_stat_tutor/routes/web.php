<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
//-------WELCOME PAGE
Route::get('/', function () {
    return view('welcome');
});

//--LOG-IN AND REGISTRATIONS
Auth::routes();
Route::get('/users/logout','Auth\LoginController@userLogout')->name('user.logout');

//--HOME PAGE - List of Topics
Route::get('/home', 'StudentController@displayHome');

//--TOPIC PROBLEM LIST
Route::get('/users/topicproblemlist/{user_id}/{topic_id}', 'StudentController@displayProblemList');

//------PROFILE PAGE--update avatar
Route::get('/users/view_profile/{id}','StudentController@displayProfile');
Route::get('/users/updateavatar/{name}/{id}','StudentController@updateAvatar');
//------TUTORIAL PAGE--completion(saveperformance)
Route::get('/users/problemtutorial/{user_id}/{topic_id}/{problem_id}', 'StudentController@displayProblemTutorial');
Route::get('/users/problemtutorial/save/{user_id}/{p_perf}/{q_perf}', 'StudentController@savePerformance');
Route::get('/users/calculator','StudentController@displayCalculator');
//------LESSON PAGE
Route::get('/users/lessons','StudentController@displayLesson');
//Route::get('/users/lessons/{user_id}/{topicid}/{probid}','StudentController@displayLessonTopic');
Route::get('/users/mylessons/{user_id}/{topicname}/{probid}','StudentController@displayTopicLesson');
//------LEADERBOARD
Route::get('/users/leaderboard','StudentController@displayLeaderboard');

//------ACCOUNT SETTINGS
Route::get('/users/settings','StudentController@displayAccountSettings');
Route::post('/users/settings/update-info/{id}','StudentController@updateAccountInfo');
Route::post('/users/settings/update-pass','StudentController@updatePassword');


//====================================================================

Route::get('/users/resume/{pid}','StudentController@resumetoLatestProblem');
Route::get('/users/progress_levels/{id}','StudentController@displayProgressLevel');
Route::get('users/profile', 'StudentController@displayProblemList');
Route::get('/users/problemsolving/{userid}/{id}','StudentController@displayProblem');
Route::get('/users/problemsolving/{id}/{tpoints}/{badge}','StudentController@problemCompleted');
Route::get('/users/problemsolving/continue/{pid}','StudentController@continueToNextProblem');
Route::get('/questionperformancelog/','StudentController@saveQuestionLog');

Route::prefix('admin')->group(function(){
	Route::get('/login','Auth\AdminLoginController@showLoginForm')->name('admin.login');
	Route::post('/login','Auth\AdminLoginController@login')->name('admin.login.submit');
	Route::get('/', 'AdminController@index')->name('admin.dashboard');	
	Route::get('/logout','Auth\AdminLoginController@logout')->name('admin.logout');
	Route::get('/userslist','AdminController@displayUsers');
	Route::get('/course_structure','AdminController@displayCourseStructure');

});

//-------------TEMP_ROUTES

Route::get('/sample', 'AdminController@displayUsers');
Route::get('/sample1/{id}', 'HomeController@sample');
Route::post('/changepassword','StudentController@changePassword');
Route::get('/users/tutorial/{id}','StudentController@displayProblem');
Route::get('/users/dashboard','StudentController@displayDashboard');
Route::get('/users/edit_profile/{id}','StudentController@displayEditProfile');
Route::post('/users/update_profile/{id}','StudentController@updateProfile');
Route::get('/users/subtopicprogress','StudentController@displaySubTopicProgress');
Route::get('/users/subtopicprogress/update','StudentController@updateSubTopicProgress');
Route::get('/users/syllabus','StudentController@displaySyllabus');

// -------------COURSE------------//
Route::prefix('course')->group(function(){
	Route::get('/create','CourseController@create_view'); //view create.blade.php
	Route::get('/edit/{id}','CourseController@edit_view'); //view data to be updated
		//Database
	Route::get('/list','CourseController@list_view'); // list of course
	Route::get('/view/{id}','CourseController@read_view'); 
	Route::post('/save','CourseController@save'); 
	Route::post('/update/{id}','CourseController@update');
	Route::get('/delete/{id}','CourseController@delete');
});

//----------TOPIC FOR A COURSE --------------//
Route::prefix('topic')->group(function(){
	Route::get('/create','TopicController@create_view'); //view create.blade.php with course id
	Route::get('/edit/{id}','TopicController@edit_view'); //view data to be updated
		//Database
	Route::get('/list/{id}','TopicController@list_view'); // list of course
	Route::get('/view/{id}','TopicController@read_view'); 
	Route::post('/save','TopicController@save'); 
	Route::post('/update/{id}','TopicController@update');
	Route::get('/delete/{id}','TopicController@delete');

});

//----------SUB-TOPIC FOR EACH TOPIC --------------//
Route::prefix('subtopic')->group(function(){
Route::get('/create','SubTopicController@create_view'); //view create.blade.php
Route::get('/edit/{id}','SubTopicController@edit_view'); //view data to be updated
//Database
Route::get('/list','SubTopicController@list_view'); // list of course
Route::get('/view/{id}','SubTopicController@read_view'); 
Route::post('/save','SubTopicController@save'); 
Route::post('/update/{id}','SubTopicController@update');
Route::get('/delete/{id}','SubTopicController@delete');

});

//----------PROBLEM FOR EACH SUBTOPIC --------------//
Route::prefix('problem')->group(function(){
Route::get('/list/all','ProblemController@displayAllProblems'); 
Route::get('/create','ProblemController@create_view'); //view create.blade.php
Route::get('/edit/{id}','ProblemController@edit_view'); //view data to be updated
//Database
Route::get('/list','ProblemController@list_view'); // list of course
Route::post('/save','ProblemController@save'); 
Route::post('/update/{id}','ProblemController@update');
Route::get('/delete/{id}','ProblemController@delete');

});

