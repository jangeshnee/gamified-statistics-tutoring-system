//var tutorialFlowLog
var qStepID = new Array();
var qStepOrder = new Array();
var qCode = new Array();
var qDesc = new Array();
var qExplain = new Array();
var qExample = new Array();
var qDemo = new Array();
var qMethod = new Array();
var qPoints = new Array();
var qInstruct = new Array();
var stepID = new Array();
var stepOrder = new Array();
var stepDesc = new Array();
var stepMethod = new Array();
var stepInstruction = new Array();
var user_ID;

var currentQuestionID = 0; 
var currentMethod ="";
var stepOrderCounter=1;
var currentPoints = 0;
var totalPoints = 0;
var totalFaults = 0;

var finalProblemPoints = 0; //with bonus points

var questionSolvedCnt = 0;
var faultCnt = 0;
var attemptCnt = 0;

var problemStatus = 1; // 0-fail 1-pass
var starBadge = 0;
var ProblemAttempt;
var MaxProbPoints = 0;
var ProblemID = 0;
var MaximumPoints = 0;
var ProblemBonusPoints = 0;

var pointsDeduction = 0;

var help_log = new Array(); 

var probLog ="";
var questionLog="";

function getAllQuestiondetails(qtStepID,qtStepOrder,qtCode,qtDesc,qtExplain, qtExample,qtDemo,qtMethod,qtInstruct,qtPoints){
qStepID.push(qtStepID);
qStepOrder.push(qtStepOrder);
qCode.push(qtCode);
qDesc.push(qtDesc);
qExplain.push(qtExplain);
qExample.push(qtExample);
qDemo.push(qtDemo);
qMethod.push(qtMethod);
qInstruct.push(qtInstruct);
qPoints.push(qtPoints);
//addTutorReply("Push Question:"+qtDesc+" Method:"+qtMethod);
}

function getAllStepdetails(stID,stOrder,stDesc,stMethod,stInstruction){
stepID.push(stID);
stepOrder.push(stOrder);
stepDesc.push(stDesc);
stepMethod.push(stMethod);
stepInstruction.push(stInstruction);
//addTutorReply("Push Question:"+stDesc);
}

function getProblemInfo(prob_attempt,prob_id,userID,maxp,bonus){
ProblemAttempt = prob_attempt;
ProblemAttempt++;
ProblemID = prob_id;
user_ID=userID;
MaximumPoints = maxp;
ProblemBonusPoints = bonus;
//addTutorReply("Push:"+prob_id);
}

function displayQuestion(questionDesc,questionMethod,questionInstruction){

	var question_description = document.getElementById('question-description');
	question_description.innerHTML = questionDesc;

	var question_instruction = document.getElementById('question-instruction');
	question_instruction.innerHTML = questionInstruction;
	currentMethod = questionMethod;
}

function findTheCorrectAnswer(methodForCorrectAnswer){
	switch(methodForCorrectAnswer){
		case "orderData":
		//get feedback here
		return orderData();
		break;
		case "findMode":
		//get feedback here
		return findMode();
		break;

		case "findMedian":
		return findMedian();
		break;

		case "getSumofAllData":
		return getSumofAllData();
		break;

		case "countAllTheData":
		return countAllTheData();
		break;

		case "findMean":
		return findMean();
		break;

		case "getTheMinValue":
		return getTheMinValue();
		break;

		case "getTheMaxValue":
		return getTheMaxValue();
		break;

		case "findRange":
		return findRange();

		case "getTheSumofSquaredDifference":
		return getTheSumofSquaredDifference();

		case "findVariance":
		return findVariance();

		case "findSD":
		return findSD();

		default:
		break;
	}
}

function solvedForTotalPoints(){
		totalPoints = totalPoints + currentPoints;
		totalFaults = totalFaults + faultCnt; 



		var tPoints = document.getElementById('tpoints');
		var tFaults = document.getElementById('tfaults');

		tPoints.innerHTML = totalPoints;
		tFaults.innerHTML = totalFaults;
}

function solvedForStarBadge(){
	//var maximumpoints = document.getElementById('maxPoints').innerHTML;
    MaxProbPoints = MaximumPoints;

	var percent_badge = (totalPoints/parseInt(MaximumPoints))*100;

	if(percent_badge<=44){
		//addTutorReply("Badge 1");
		starBadge = 1;
		problemStatus = 0;	
	}
	else if(percent_badge>=45 && percent_badge<=85)
	{
		//addTutorReply("Badge 2");
		starBadge = 2;
		problemStatus = 1;	
	}
	else if(percent_badge>=86 && percent_badge<=100){
		//addTutorReply("Badge 3");
		starBadge = 3;
		problemStatus = 1;	
	}else{}

}

function saveLog(){
	questionLog = questionLog.substring(0,questionLog.length-1);
    window.location = "/users/problemtutorial/save/"+user_ID+"/"+probLog+"/"+questionLog;
}


function checkIfProblemisCompleted(){
	//solve for overall points 
	solvedForTotalPoints();

	if(stepID.length==questionSolvedCnt){ //problem complete

		var snd = new Audio("/audio/audio-1.mp3");
		snd.play();

		addTutorReply("<span style='color:#22b24c; font-weight:bold;'>Problem Completed! Please click the button below</span>");
		var mybtn = document.getElementById('btnSubmit');
		mybtn.disabled = "disabled";
		//display a pop-up box here 
		//ask for open-ended-question
		//feedback for problem completion -> star badge, total points, student performance
		//if student failed then he needs to try again else proceed to next problem
		//solved for badge
		solvedForStarBadge();
		questionPerformanceLog();
		problemPerformanceLog();
		// canProceedToNextProblem();

		// var starBadgeNumm = document.getElementById('starBadgeNum');
 	// 	starBadgeNumm.innerHTML = starBadge;
 	
 		

	}else{ // there is a next question

		var myinputbox = document.getElementById("inputAnswer").value="";
		// var btnHelp1 = document.getElementById('btnShowExplain');
		// var btnHelp2 = document.getElementById('btnShowExample');
		// var btnHelp3 = document.getElementById('btnShowDemo');

		// btnHelp1.disabled = false;
		// btnHelp2.disabled = false;
		// btnHelp3.disabled = false;

		//call the questionPerformanceLog()
		questionPerformanceLog();
		//reset the help_log after the question_performance is recorded
		help_log = [];

		//reset the fault counter and current points
		faultCnt = 0;
		currentPoints = 0;
		attemptCnt = 0;
		stepOrderCounter++;
		//stepOrderCounter = 1;
		var cnt = 0;
		//determine if one step has one or many question
		for(var i=0;i<qStepOrder.length;i++){
			 if(stepOrderCounter==qStepOrder[i]){
			 	cnt++;
		    }
		}

			if(cnt>1){
				
				// get the method for next step
				var method = stepMethod[stepOrderCounter-1];
				//to generate the questionCode
				findTheCorrectAnswer(method);
				//to getTheQuestionCode
				var questCode = getQuestionCode();
				//find the index of questCode in the qCode array
				var indOfQ;
				for(var i=0;i<qCode.length;i++){
					if(questCode==qCode[i]){
						indOfQ = i;
					}
				}

				currentQuestionID = indOfQ;

				// addTutorReply("One Step has many question branch method->"+method+" questCode->"+questCode);
				// addTutorReply(qExplain[indOfQ]);

				displayQuestion(qDesc[indOfQ],qMethod[indOfQ],qInstruct[indOfQ]);
			}else{
				//addTutorReply("One question One Step");
				currentQuestionID = stepOrderCounter-1;
				displayQuestion(qDesc[currentQuestionID],qMethod[currentQuestionID],qInstruct[currentQuestionID]);
			}
		
	}
}

//--------------HELP STRATEGIES DISPLAY-------------
function showExplain(){
	//addTutorReply -> pass the qExplain index of the currentProblem
	//disablethebutton: how to disable the button you select in javascript onclick
	//record in Pathway Log, record help strategy used
	// var mybtn = document.getElementById('btnShowExplain');
	// mybtn.disabled = true;
	//addConvoReply("Show Explaination");
	addTutorReply(qExplain[currentQuestionID]);
	help_log.push("explain");
}

function showExample(){
	// var mybtn = document.getElementById('btnShowExample');
	// mybtn.disabled = true;
	//addConvoReply("Show Example");

	var correctAnswer = findTheCorrectAnswer(currentMethod);
	var example = getExample();

	addTutorReply(example);
	help_log.push("example");
}

function showDemonstration(){
	// var mybtn = document.getElementById('btnShowDemo');
	// mybtn.disabled = true;
	//addConvoReply("Show Demonstration");

	var correctAnswer = findTheCorrectAnswer(currentMethod);
	var demo = getDemo();

	addTutorReply(demo);
	help_log.push("demonstration");
}

//---------------END OF HELP STRATEGIES--------------------

function questionHelp(){

if(faultCnt>=3){
addTutorReply("<span style='color:#f57a00;font-weight:bold;'>You only have one last chance to answer the question correctly.</span>");	
}

switch(faultCnt){
	case 1:
	showExplain();
	break;
	case 2:
	showExample();
	break;
	case 3:
	showDemonstration();
	break;
	default:
	break;
} 


// if(help_log.length>2){
// addTutorReply("Please try again.");
// }else{
// addTutorReply("Please choose some of the following help below:");
// }


//window.document.createElement
}

function questionPerformanceLog(){
var problemCode = "prob_"+ProblemID+"_"+ProblemAttempt;
//log the questionCode
finalProblemPoints = finalProblemPoints + totalPoints;
questionLog = questionLog+""+problemCode+"-"+qStepID[currentQuestionID]+"-"+attemptCnt+"-"+faultCnt+"-"+help_log+"-"+currentPoints+"*"; //questionID?
//addTutorReply("Problem Code: "+problemCode+" Total Attempt: "+attemptCnt+" Total Fault: "+faultCnt+" Help Logs: "+help_log+" Total Points: "+currentPoints);
//id,student_id,problem_code,question_id,attempt,fault,help_log,points
//addTutorReply(questionLog);
}

function problemPerformanceLog(){
//addTutorReply("Problem Attempt: "+ProblemAttempt+" Data: "+problemDataList+ "Total Points: "+totalPoints+" Maximum Points: "+ MaximumPoints+" Status: "+problemStatus+" Badge:"+starBadge);
probLog = probLog+""+ProblemID+"-"+ProblemAttempt+"-"+problemDataList+"-"+totalPoints+"-"+MaximumPoints+"-"+starBadge;

var ourList = document.getElementById("chatlist");
		ourList.innerHTML += "<li> <center><input type='button' onclick='saveLog()' class='btn btn-default btnComplete' value='COMPLETE'></center></li>";
		scrollChat();
}

function submitAnswer(){

var studentInputAnswer = document.getElementById('inputAnswer').value; 
var displayQuestionCnt =  document.getElementById('questionCounter');
var displayPoints = document.getElementById('points');
var displayFaults = document.getElementById('faults');

var correctAnswer;
var methodForCorrectAnswer = currentMethod;

//1:Check if the field is not empty
if(studentInputAnswer==""){
var snd = new Audio("/audio/audio-warning.mp3");
snd.play();
addTutorReply("<span style='color:#f57a00;font-weight:bold;'>Ooops! Kindly enter your answer in the box!</span>");

}else{
	correctAnswer = findTheCorrectAnswer(methodForCorrectAnswer);
	var tfeedback = getFeedback();

	addConvoReply(studentInputAnswer);
	//count for attempt 
	attemptCnt++;
	//addTutorReply("Correct answer"+correctAnswer);
	
			//2:Check the fault counter
			//3: Check if the it is already solved do not proceed
			if(faultCnt<3){
					
					//get the question code - will not work for step 1, step 2 with one question
					//getQuestionCode();

					
					//addTutorReply("Method "+methodForCorrectAnswer+" correctAnswer: "+correctAnswer+"Currect question ID"+currentQuestionID);
					
					if(correctAnswer==studentInputAnswer){
						var snd = new Audio("/audio/audio-1.mp3");
							snd.play();

						addTutorReply("<span style='color:#22b24c; font-weight:bold;'>Well done!</span><p>"+tfeedback+"</p>");
						//increment the question counter display
						questionSolvedCnt++;

						//record log for answered question
						pointsDeduction = (qPoints[currentQuestionID]/5)*faultCnt;
						currentPoints = qPoints[currentQuestionID] - pointsDeduction;
						//questionPerformanceLog();
						displayQuestionCnt.innerHTML = stepOrderCounter;
						displayPoints.innerHTML = currentPoints;
						displayFaults.innerHTML = faultCnt;

						checkIfProblemisCompleted();

					}else{
						addTutorReply("<span style='color:#ff0000; font-weight:bold;'>Oh no! That is not the correct answer!</span>");
						faultCnt++;
						pointsDeduction = (qPoints[currentQuestionID]/5)*faultCnt;
						currentPoints = qPoints[currentQuestionID] - pointsDeduction;
						questionHelp();
						var snd = new Audio("/audio/audio-error.mp3");
						snd.play();
					}

					//givepoints 	
					//currentPoints = qPoints[currentQuestionID] - faultCnt;
			}
			else{ // display answer

				//faultCnt++;
				//Maximum Faults displaying the correct answer
				addTutorReply("Nice try! But you did not get the correct answer."+tfeedback);

				//increment questionSolvedCounter
				questionSolvedCnt++;
				//go to next question if ever

				//no points for the question
				//currentPoints = 0;
				pointsDeduction = (qPoints[currentQuestionID]/5)*faultCnt;
				currentPoints = qPoints[currentQuestionID] - pointsDeduction;
				//questionPerformanceLog();
				checkIfProblemisCompleted();
			}
	


	//currentPoints = qPoints[currentQuestionID] - faultCnt;

	

	displayQuestionCnt.innerHTML = stepOrderCounter;
	displayPoints.innerHTML = currentPoints;
	displayFaults.innerHTML = faultCnt;
}


}
