var problemDataList;
var feedback = "";
var questionCode = "";
var example ="";
var demo = "";


function generateRandomList(len){
    var num;
    var exampleData="";

    for(var i=0;i<len;i++){
        num = Math.floor(Math.random()*5)+1;
        exampleData = exampleData+""+num+" ";
    }
    exampleData = exampleData.substring(0,(exampleData.length-1));

    return exampleData;
}

function getDataList(dataList){ //working
problemDataList = dataList.substring(1,(dataList.length));
} 

//----------Mode-------------//
function orderData(){//working
var splitted = problemDataList.split(" ");
var sorted_data = splitted.sort();
//questionCode = "modeS1";
feedback = "Arranging the data set of the problem in ascending order the result is "+sorted_data+".";

var temp = generateRandomList(5);
var temp_data = temp.split(" ");
example ="Example: Suppose in a data set of "+temp_data+". Ordering the data in ascending order the result is "+temp_data.sort()+".";

demo ="Arranging data in ascending order does not need for computation. You just need to arrange the data from smallest to largest.";

sorted_data = sorted_data+",";

var f_sortedData = "";

// for(var i=0;i<sorted_data.length;i++){
// f_sortedData = f_sortedData+""+sorted_data[i]+" ";
// }

return sorted_data;
}

function findMode(){ //working

    var numbers = problemDataList.split(" ");
    var modes = [], count = [], i, number, maxIndex = 0;
 
    for (i = 0; i < numbers.length; i += 1) {
        number = numbers[i];
        count[number] = (count[number] || 0) + 1;
        if (count[number] > maxIndex) {
            maxIndex = count[number];
        }
    }
 
    for (i in count)
        if (count.hasOwnProperty(i)) {
            if (count[i] === maxIndex) {
                modes.push(Number(i));
            }
        }

    if(maxIndex==1){ //no mode
      feedback = "All the values in the data set appears exactly once. Therefore, we have no mode.";
      example="Example: In an ordered data set such as 2,4,5,6,7. All the numbers appears once. Therefore, it has <b>no mode</b>.";
      demo ="If all the values appears exactly once. Please enter “no mode” in answering the question. ";
      questionCode = "modeS2c";
      return 0;
    }
    else if(modes.length>1 && maxIndex>1){ // more than one mode
      feedback = "The values: "+modes+" appears "+maxIndex+" times. Therefore, we have two or more mode in the data set. ";
      example="In an ordered data set such as 1,2,2,3,3,5. The values 2 and 3 both appears twice.";
      demo ="There is no need for computation in finding the values with highest frequency. You just have to find values that have the same number of appearance in the data set.";
      questionCode = "modeS2b";      
      return modes;      
    }
    else{ //one mode
      feedback = "The value "+modes+" occurs "+maxIndex+" times. Therefore, "+modes+" is the mode.";
      example="Example: In an ordered data set such as 1,2,2,2,3,3,5. The number with a highest frequency is 2.";
      demo ="There is no need for computation in finding a value with the highest frequency. You just have to count how often the value appear in your ordered data set. ";
      questionCode = "modeS2a";     
      return modes;
    }
}

function findMedian(){//working
    var splitted = problemDataList.split(" ");
    var sorted_data = splitted.sort();
    var median;

    //determine if the data lis is odd or even
    if(sorted_data.length%2==0){//even
        //get the index 1
        //get the index 2
        var ind1 = ((parseInt(sorted_data.length))/2)-1;
        var ind2 = ind1+1; 
        m_sum = (parseInt(sorted_data[ind1])+parseInt(sorted_data[ind2]));     
        median = m_sum/2; 
        feedback ="Adding the two middle values"+sorted_data[ind1]+" and "+sorted_data[ind2]+" divide it by half, the result is "+median+". Therefore, "+median+" is the median.";
        
        var temp = generateRandomList(6);
        var temp_data = temp.split(" ");
        var temp_data_sort = temp_data.sort();
        var t_ind1 = ((parseInt(temp_data_sort.length))/2)-1;
        var t_ind2 = t_ind1 + 1;
        t_sum = (parseInt(temp_data_sort[t_ind1])+parseInt(temp_data_sort[t_ind2]));
        t_median = t_sum/2; 


        example="Example: In an ordered data set of "+temp_data_sort+". The two middle values are "+temp_data_sort[t_ind1]+" and "+temp_data_sort[t_ind2]+". The sum of this values is "+t_sum+" divide it by 2, the result is "+t_median+".";
        demo ="In the data set of the problem, the median is the sum of the middle values "+sorted_data[ind1]+" and "+sorted_data[ind2]+" which is "+m_sum+" divided by 2.";
        questionCode = "mediS2b";     
    }else{ //odd        
        var median_index = ((parseInt(sorted_data.length)-1)/2);
        median = sorted_data[median_index];
        feedback = "The center value of the data set is "+median+". Therefore, "+median+" is the median.";
        
        var temp = generateRandomList(5);
        var temp_data = temp.split(" ");
        var temp_data_sort = temp_data.sort();
        var t_ind1 = ((parseInt(temp_data_sort.length)-1)/2);
        var t_median = temp_data_sort[t_ind1];

        example="In an ordered data set of "+temp_data_sort+". The center value is "+t_median+".";
        
        if(sorted_data.length>5){
            demo ="If there are "+sorted_data.length+" values in the data set, the center value is in the "+median_index+"th position of the ordered data set. "; 
        }
        else{
            demo ="If there are 5 values in the data set, the center value is in the 3rd position of the ordered data set. "; 
        }
        
        questionCode = "mediS2a";
    }

    return median;
}

//----mean-------------
function getSumofAllData(){
    var numbers = problemDataList.split(" ");
    var sum = 0;
    var sDemo="";
    for(var i=0;i<numbers.length;i++){
        sum = sum + parseInt(numbers[i]);
        sDemo = sDemo+""+numbers[i]+"+";
    }
    feedback = "The sum of all the values in the data set is "+sum+".";

    var temp = generateRandomList(5);
    var temp_data = temp.split(" ");
    var t_sum = 0;

    for(var j=0;j<temp_data.length;j++){
         t_sum = t_sum + parseInt(temp_data[j]);
     }

    example="Example: In a data set of "+temp+". The sum is "+t_sum+".";
    
    sDemo = sDemo.substring(0,(sDemo.length-1));
    demo ="Using the data set of the problem compute the following: "+sDemo;
    return sum;
}

function countAllTheData(){
    var numbers = problemDataList.split(" ");
    feedback = "The total number of values in the data set is "+numbers.length+".";
    var temp = generateRandomList(5);
    var temp_data = temp.split(" ");
    example="In a data set of "+temp+". There are "+temp_data.length+" number of values.";
    demo ="Count the total number of values in the data set.";
    return numbers.length;
}

function findMean(){
var sum = getSumofAllData();
var n = countAllTheData();
var mean = sum/n;
//mean = mean.toFixed(2);
feedback = "Dividing the sum of all the values "+sum+" by "+n+" . The result is "+mean+". Therefore "+mean+" is the mean of the problem. "


    var temp = generateRandomList(5);
    var temp_data = temp.split(" ");
    var t_sum = 0;

    for(var j=0;j<temp_data.length;j++){
         t_sum = t_sum + parseInt(temp_data[j]);
     }

    var t_mean = t_sum/parseInt(temp_data.length);

example="In a data set of "+temp+". The sum of all the values is "+t_sum+" dividing it by the total number of values which is "+temp_data.length+". The mean is "+t_mean+".";

demo ="Using the data set of the problem compute the following: "+sum+"/"+n;
return mean;
}

//------range----------

function getTheMaxValue(){
var numbers = problemDataList.split(" ");
var sorted_data = numbers.sort();
var last_ind = parseInt(sorted_data.length)-1;

feedback = "The largest value in the data set is "+sorted_data[last_ind]+".";

var temp = generateRandomList(5);
var temp_data = temp.split(" ");
var temp_data_sort = temp_data.sort();
var ind = temp_data_sort.length-1;
example="In a data set of "+temp_data+". The largest value is "+temp_data_sort[ind];

demo ="Arranging the data set of the problem in ascending order the result is "+sorted_data+". The last number is the largest value of the data set.";
return parseInt(sorted_data[last_ind]);
}

function getTheMinValue(){
var numbers = problemDataList.split(" ");
var sorted_data = numbers.sort();

feedback ="The smallest value in the data set is "+sorted_data[0]+".";

var temp = generateRandomList(5);
var temp_data = temp.split(" ");
var temp_data_sort = temp_data.sort();

example="In a data set of "+temp_data+". The smallest value is "+temp_data_sort[0];
demo ="Arranging the data set of the problem in ascending order the result is "+sorted_data+". The first number is the smallest value of the data set.";
return parseInt(sorted_data[0]);
}

function findRange(){
var numbers = problemDataList.split(" ");
var sorted_data = numbers.sort();
var last_ind = parseInt(sorted_data.length)-1;
var range = parseInt(sorted_data[last_ind]) - parseInt(sorted_data[0]);

feedback = "The difference of the largest and smallest number of the data set is "+range+". Therefore, "+range+" is the range.";
demo ="In the data set of the problem, the range is the difference of the smallest value "+sorted_data[0]+" to the largest value "+sorted_data[last_ind]+".";

 var temp = generateRandomList(5);
 var temp_data = temp.split(" ");
 var temp_data_sort = temp_data.sort();
 var tLind = parseInt(temp_data_sort.length) - 1;
 var tRange = parseInt(temp_data_sort[tLind])-parseInt(temp_data_sort[0]); 

example="Example: In a data set of "+temp_data+". Subtracting the smallest value "+temp_data_sort[0]+" to the largest value "+temp_data_sort[tLind]+" , the result is "+tRange+".";

return range;
}

//------------variance--------------

function getTheSumofSquaredDifference(){
var splitted = problemDataList.split(" ");
var mean = findMean();
var sDemo1 = "";
var sDemo2 = "";
var sDemo3 = "";

var sum = 0;
var diff;
    for(var i=0;i<splitted.length;i++){
    diff = parseInt(splitted[i])-mean;
    diff = diff.toFixed(2);
    sDemo1 = sDemo1 +""+splitted[i]+" - "+mean+" = "+diff+"<br>";
    sDemo2 =sDemo2+""+diff+" x "+diff+" = "+(diff*diff).toFixed(2)+"<br>";
    sDemo3 = sDemo3 +""+(diff*diff).toFixed(2)+"+";
    sum = sum + (diff*diff);
    }
    sDemo3 = sDemo3.substring(0,sDemo3.length-1)

    sum = sum.toFixed(2);

feedback ="The sum of squared difference of mean to each data is "+sum+".";
demo ="Subtracting the mean to each data: <br>"+sDemo1+"<br>Squaring each of the difference:<br>"+sDemo2+"<br>Finally, adding the squared values:<br>"+sDemo3+" is equal to ?";
example="In a data set of <b>1,2,3</b> . The mean is <b>2</b>. <br> First, we subtract the mean to each data:<br> 1-2 = -1 <br> 2-2 = 0 <br> 3-2 = 1 <br> Then squared these values:<br> -1 x -1 = 1<br>0 x 0 = 0<br>1 x 1 = 1<br> Finally, adding the squared values:<br> 1 + 0 + 1 <br> The result is <b>2</b>";

return sum;
}

function findVariance(){

var sumofsquare = getTheSumofSquaredDifference();
var n = countAllTheData();
var variance = sumofsquare/n;

//variance = variance.toFixed(2);

feedback ="The variance of the problem is "+variance+".";

demo ="In the problem, to determine the variance, divide the sum of squared difference of mean to each data point which is "+sumofsquare+" by "+n+", the total number of values.";
example="In a data set of <b>1,2,3</b>. The sum of squared difference of mean to each data point is <b>2</b>. Diving it by 3, the total number of values. The variance is 0.67";

return variance;
}

//---------Standard Deviation

function findSD(){
var variance = findVariance();
var std = Math.sqrt(variance);

//std = std.toFixed(2);
feedback ="The standard deviation is "+std+".";

example="If the computed variance of a data set is 25 . The standard deviation is the square root of 25 which is <b>5</b>.";
demo ="In the problem, the variance is "+variance+" . The standard deviation is the square root of "+variance+".";
return std;
}



//---------------------end of computation methods----------------------------
function addConvoReply(message){
var ourList = document.getElementById("chatlist");
ourList.innerHTML += "<li class='user-reply'>" + message +"</li>";
scrollChat();    
}

function addTutorReply(message){
var ourList = document.getElementById("chatlist");
ourList.innerHTML += "<li class='tutor-say'>" + message +"</li>";
scrollChat();
}


function getQuestionCode(){
    //addTutorReply("This is questionCode"+questionCode)
    return questionCode;
}


function getFeedback(){
    return feedback;
}

function getExample(){
    return example;
}

function getDemo(){
    return demo;
}