var display = "";
var solved_task = new Array(); //task items already solved
var problem_summary;
var problem_completion_status = 0 ; // 0 - not complete 1- complete

var total_points_earned = 0;

//this variables correspond with each other: 
//for every task attempted there is corresponding num of attempts, current points, points deduction
var task_attempted = new Array(); // task attempted
var num_of_attempt_in_task = new Array();
var task_attempted_points = new Array(); 
var task_points_deduction = new Array();

var attemp_counter;
var points_deduction_counter;
var prompt_attempt_cnt;
var num_steps;
var total_task_to_solve = new Array();

var last_task_attempted;

//for step Guide Variables
var task_item_id = new Array();
var task_step_order = new Array();
var task_demo = new Array();
var task_prompt = new Array();
var task_promt_ans = new Array();
var task_hint = new Array();

var step_attempted_correct = new Array(); 
var num_of_attempt_in_steps = new Array();

function getTotalTask(num){
// task to solve, to determine if the problem is complete if all the task items is complete compare it to solved task
total_task_to_solve.push(num);
}

function getProblemSummary(summary){
problem_summary=summary;
}

function importStepGuide(task_id,step_order,demo,prompt,correct_prompt,hint){
//this is working
task_item_id.push(task_id);
task_step_order.push(step_order);
task_demo.push(demo);
task_prompt.push(prompt);
task_promt_ans.push(correct_prompt);
task_hint.push(hint);

}

function checkAnswerifCorrect(){}

function getUserPromptResponse(){
// getElementbyID //prompting continue - eval prompt response if correct
var input_user_prompt = document.getElementById('prompt_answer').value;
//display = display + input_user_prompt;


//get the index of step guide of the task chosen						 	
var i;
var step_ind = new Array();
var total_num_steps = 0;
									 
for (i = 0; i < task_item_id.length; i++) {
	if(task_item_id[i]==last_task_attempted){
		step_ind.push(i); // index of task steps
	    //display = display + "index of steps "+ step_ind + "<br>";
	    total_num_steps++;
		}
	}



if(input_user_prompt==""){ //check input if empty
display = display + "Please enter your response on the box <br>";

}else{
	//check if task attempted is empty or not
	if(task_attempted.length>0){ //user already attempted to solve task item
		//display = display + "Last Item task attempted" + last_task_attempted+"<br>";
			
			//check if task item is already solved
			var task_exist = 0;
			var j;
			
			for(j=0;j<solved_task.length;j++){
			     if(last_task_attempted==solved_task[j]){
			         task_exist = 1; // it exist
			     }
		     }

		     if(task_exist==0){ //task is not completed already 
		     	prompt_attempt_cnt++; // prompt will be incremented when response button is clicked	     
		     	//display = display + "Prompt Counter " + prompt_attempt_cnt +"<br>";
		     	
		     	//check if prompt is correct or not
		     	//display = display + "Number of Steps for ind " + num_steps +"<br>";
		     	var indpp = step_ind[num_steps];
		     	//display = display + "Task Prompt Ans" + task_promt_ans[indpp] +"<br>";
		     	
		     //check if steps is already done if it is not done proceed else Start Over? ->reset all the prompt


		     	if(input_user_prompt==task_promt_ans[indpp]){ // if response is correct
						display= display+"Okay! Prompt Correct!<br>"; 
						step_attempted_correct.push(indpp); //step is already done
						

						//proceed to next steps
						num_steps++;
						prompt_attempt_cnt = 0;
						if(num_steps<total_num_steps){
						 indpp = step_ind[num_steps];	
						 display = display + " Next Demo "+ task_demo[indpp];
						}else{ //all steps are done
						 display = display + "Okay! Input the correct answer in task item box";
						}			
						
				}else{ //if response is not correct
					
					if(prompt_attempt_cnt<2){
						display= display+"Hint:"+task_hint[indpp]+"Please try again<br>";
					}else{
						display= display+"Display Prompt correct answer";

						num_steps++;
						prompt_attempt_cnt = 0;
						if(num_steps<total_num_steps){
						 indpp = step_ind[num_steps];	
						 display = display + " Next Demo "+ task_demo[indpp];
						}else{ //all steps are done
						 display = display + "Okay! Input the correct answer in task item box";
						}
					}				
				}

		     }else{
		     	display= display+" This task is already solved. Proceed to other task <br>";
		     } // end check if task item is already solved

	}else{
		display = display + "Kindly answer task items by entering answer on the input box and click check it button<br>";
	}
}


var holder = document.getElementById('tutor');
holder.innerHTML = display;
}


function checkAnswer(task_id,task_answer,task_feedback,task_points){

//Footer Items
var task_attempted_holder = document.getElementById('taskAttempted');
var total_attempt_holder = document.getElementById('totalAttempts');
var current_point_holder = document.getElementById('currentPoints');
var deduction_holder = document.getElementById('deduction');
var total_points_holder = document.getElementById('totalPointss');


//




//get user_input_task_item_answer
var input_varname = "inputAnswer"+task_id;
var input_task_item_answer = document.getElementById(input_varname).value;

last_task_attempted = task_id;
task_attempted_holder.innerHTML =last_task_attempted;

//Determine Problem Competion
if((solved_task.length)<total_task_to_solve.length){
problem_completion_status = 0; //not complete


if(input_task_item_answer==""){ //check if input is blank or not
//display = display + "Please fill in your answer in the box! <br>";
chatWindow.talk({ice: { says: ["Ooops! Kindly enter your answer in the box!"]}});
}else{

	//check if task item is already solved
	var task_exist = 0;
	var j;
	
	for(j=0;j<solved_task.length;j++){
	     if(task_id==solved_task[j]){
	         task_exist = 1; // it exist
	     }
     }

     if(task_exist==0){ //check if the task is already solved

     		//check task_attempted exist
     		var task_attempt_exist = 0;
     		for(j=0;j<task_attempted.length;j++){
			     if(task_id==task_attempted[j]){
			         task_attempt_exist = 1; // it exist
			     }
     		}

     		// task attempts
     		if(task_attempt_exist==0){ //task is first time to attempt

     			attemp_counter = 1;
     			points_deduction_counter = 0;
     			task_attempted.push(task_id);
     			num_of_attempt_in_task.push(attemp_counter); // value = 1
     		    //parseInt

     		    // display = display + "task attempted "+task_attempted + "<br>";
     		    // display = display + "num of attempt"+num_of_attempt_in_task + "<br>";
     		    
     		    //evaluateUserAnswer(input_task_item_answer,task_answer);
		     		    	if(input_task_item_answer==task_answer){ //correct answer

								// display = display + "Well done! "+ task_feedback + "<br>"; 
								// display = display + "Please proceed to solving next task item <br>";
								chatWindow.talk({ice: { says: ["Well done!","Please proceed to solving next task item"]}});				 
								solved_task.push(task_id);
										 
							}else{ // wrong answer
							
							 points_deduction_counter++;
							 
							 //display= display+" Oh no! That is not the correct answer <br>";
							 chatWindow.talk({ice: { says: ["Oh no! That is not the correct answer."]}});
									 //get the index of step guide of the task chosen						 	
							 		 var i;
							 		 var ind = new Array();
									 
									 for (i = 0; i < task_item_id.length; i++) {
										if(task_item_id[i]==task_id){
											ind.push(i); // index of task steps
										}
									 }
									 //user prompting - step 1 only 
									 ind_p = ind[0];
									 // display = display + "Demo " +task_demo[ind_p] + "<br>";
									 // display = display + "Prompt " +task_prompt[ind_p] + "<br>";
									 chatWindow.talk({ice: { says: [task_demo[ind_p]]}});
									 chatWindow.talk({ice: { says: [task_prompt[ind_p]]}});
									 prompt_attempt_cnt = 0;
									 num_steps = 0; 
							
							}
			//Points Solving here 
			var current_points_earned;					
			current_points_earned = parseInt(task_points) - points_deduction_counter;
			task_attempted_points.push(current_points_earned);
			task_points_deduction.push(points_deduction_counter);

			// display = display + "Task Attempted Points" +task_attempted_points + "<br>";
			// display = display + "Task Points Deductions" +task_points_deduction + "<br>";

			total_attempt_holder.innerHTML = attemp_counter;
			current_point_holder.innerHTML = current_points_earned;
			deduction_holder.innerHTML = points_deduction_counter;

     		}else{
     			var ind_of_task = task_attempted.indexOf(task_id);
     			attemp_counter = num_of_attempt_in_task[ind_of_task]; // put the value 
     			attemp_counter++;
     			num_of_attempt_in_task[ind_of_task] = attemp_counter;
     			
     	
     			// display = display + "task attempted "+task_attempted + "<br>";
     		 //    display = display + "num of attempt"+num_of_attempt_in_task + "<br>";
     		 
     	
     		    // if attempt_counter == 3 then state the correct answer else 
     		    	if(attemp_counter < 3){
     		    		if(input_task_item_answer==task_answer){ //correct answer
							// display = display + "Well done! "+ task_feedback + "<br>"; 
							// display = display + "Please proceed to solving next task item <br>";										 
							chatWindow.talk({ice: { says: ["Well done!","Please proceed to solving next task item"]}});
							solved_task.push(task_id);							 
						}else{ // wrong answer
							
						 points_deduction_counter++;				 
						 // display= display+" Oh no! That is not the correct answer <br> Let's try again <br>";
						 chatWindow.talk({ice: { says: ["Oh no! That is not the correct answer.","Let's try again"]}});			 var i;
							 		 var ind = new Array();
									 
									 for (i = 0; i < task_item_id.length; i++) {
										if(task_item_id[i]==task_id){
											ind.push(i);
										}
									 }
									 //user prompting - step 1 only 
								     ind_p = ind[0];
									 // display = display + "Demo " +task_demo[ind_p] + "<br>";
									 // display = display + "Prompt " +task_prompt[ind_p] + "<br>";
									 chatWindow.talk({ice: { says: [task_demo[ind_p]]}});
									 chatWindow.talk({ice: { says: [task_prompt[ind_p]]}});

									 prompt_attempt_cnt = 0;
									 num_steps = 0; 
						}
     		    	} else { //if attemp_counter 3 and its still wrong state the correct answer
     		    		
     		    		if(input_task_item_answer==task_answer){ //correct answer

							// display = display + "Well done! "+ task_feedback + "<br>"; 
							// display = display + "Please proceed to solving next task item <br>";
							chatWindow.talk({ice: { says: ["Well done!","Please proceed to solving next task item"]}});			 
						}else{ // wrong answer
							// things to check: if wrong attempt is not equal to 2
							points_deduction_counter++;		 
							// display = display + "Nice try! The correct answer is _ <br>";
							// display = display + "Please proceed to solving next task item <br>";
							chatWindow.talk({ice: { says: ["Nice try! The correct answer is _ ","Please proceed to solving next task item"]}});							 
						// start looping the step guide from database
						}

     		    		 solved_task.push(task_id); // if three attempts push the task item to solved
     		    	}

     		//Points Solving here 
     		var current_points_earned;					
			current_points_earned = parseInt(task_points) - points_deduction_counter;
			task_attempted_points[ind_of_task] = current_points_earned;
			task_points_deduction[ind_of_task] = points_deduction_counter;
			// display = display + "Task Attempted Points" +task_attempted_points + "<br>";
			// display = display + "Task Points Deductions" +task_points_deduction + "<br>";

			total_attempt_holder.innerHTML = num_of_attempt_in_task[ind_of_task];
			current_point_holder.innerHTML = task_attempted_points[ind_of_task];
			deduction_holder.innerHTML = task_points_deduction[ind_of_task];
     		
     		}//end if task attemp more than 1

     }else{
     	// display= display+" This task is already solved. Proceed to other task <br>";
     	chatWindow.talk({ice: { says: ["This task is already solved","Proceed to other task"]}});
     }
	
}//end input is not blank

}else{  // problem complete!!
problem_completion_status = 1; //complete
// display = display + "Summary: "+problem_summary;
chatWindow.talk({ice: { says: [problem_summary]}});
//Solve Badges here



window.location.href = "{{url('users/leaderboard')}}";
//pass total points, badge, problem id completed then display a form

} // end check if problem is completed


// var holder = document.getElementById('tutor');
// holder.innerHTML = display;

//Solve for total points earned
var total_points_earned = 0;
for(var i=0;i<task_attempted_points.length;i++){
total_points_earned = parseInt(total_points_earned) + parseInt(task_attempted_points[i]);
}

var badge;
var maximumpoints = 15;
var percent_badge = (total_points_earned/maximumpoints)*100;

if(percent_badge<=44){
//chatWindow.talk({ice: { says: ["one star",""+percent_badge]}});
}
else if(percent_badge>=45 && percent_badge<=85)
{
//chatWindow.talk({ice: { says: ["two star",""+percent_badge]}});
}
else if(percent_badge>=86 && percent_badge<=100){
//chatWindow.talk({ice: { says: ["three star",""+percent_badge]}});
}else{}

total_points_holder.innerHTML = total_points_earned;

} //end of checkAnswerFunction






-------------------------------------

var step_convo = {
  ice: {
    says: ["Demo","Prompt"],
    reply: [{question: "A", answer: "correct"},{question: "B", answer: "wrong"},{question: "C", answer: "wrong"}]
  },
  correct:{
    says: ["That's right!","Let's proceed?"],
    reply:[{question:"Yes!", answer:"externalResourceFunction"}] //how can I proceed to next demo?
  },
  wrong:{
     says: ["Uh-huh. Please try again"],
    reply: [{question: "A", answer: "correct"},{question: "B", answer: "wrong"},{question: "C", answer: "wrong"}]
  },
  proceed:{
    says:["Proceed test"]
  }
}

var next = {
  ice: {
    says: ["Demo1","Prompt1"],
    reply: [{question: "A", answer: "correct"},{question: "B", answer: "wrong"},{question: "C", answer: "wrong"}]
  } }

chatWindow.talk(step_convo);

externalResourceFunction = function() {
  chatWindow.talk(next, "ice")
}