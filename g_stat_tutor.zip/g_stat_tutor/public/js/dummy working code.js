var display = "";
var solved_task = new Array(); //task items already solved
var problem_summary;
var problem_completion_status = 0 ; // 0 - not complete 1- complete

var total_points_earned = 0;
var task_attempted = new Array();
var num_of_attempt_in_task = new Array();
//var task_attempted_points = new Array();
var attemp_counter;
var prompt_attempt_cnt;
var num_steps;
var total_task_to_solve = new Array();

var last_task_attempted;

//for step Guide Variables
var task_item_id = new Array();
var task_step_order = new Array();
var task_demo = new Array();
var task_prompt = new Array();
var task_promt_ans = new Array();
var task_hint = new Array();

var step_attempted_correct = new Array(); 
var num_of_attempt_in_steps = new Array();

function getTotalTask(num){
// task to solve, to determine if the problem is complete if all the task items is complete compare it to solved task
total_task_to_solve.push(num);
}

function getProblemSummary(summary){
problem_summary=summary;
}

function importStepGuide(task_id,step_order,demo,prompt,correct_prompt,hint){
//this is working
task_item_id.push(task_id);
task_step_order.push(step_order);
task_demo.push(demo);
task_prompt.push(prompt);
task_promt_ans.push(correct_prompt);
task_hint.push(hint);

}

function getUserPromptResponse(){
// getElementbyID //prompting continue - eval prompt response if correct
var input_user_prompt = document.getElementById('prompt_answer').value;
//display = display + input_user_prompt;


//get the index of step guide of the task chosen						 	
var i;
var step_ind = new Array();
var total_num_steps = 0;
									 
for (i = 0; i < task_item_id.length; i++) {
	if(task_item_id[i]==last_task_attempted){
		step_ind.push(i); // index of task steps
	    //display = display + "index of steps "+ step_ind + "<br>";
	    total_num_steps++;
		}
	}



if(input_user_prompt==""){ //check input if empty
display = display + "Please enter your response on the box <br>";
}else{
	//check if task attempted is empty or not
	if(task_attempted.length>0){ //user already attempted to solve task item
		//display = display + "Last Item task attempted" + last_task_attempted+"<br>";
			
			//check if task item is already solved
			var task_exist = 0;
			var j;
			
			for(j=0;j<solved_task.length;j++){
			     if(last_task_attempted==solved_task[j]){
			         task_exist = 1; // it exist
			     }
		     }

		     if(task_exist==0){ //task is not completed already 
		     	prompt_attempt_cnt++; // prompt will be incremented when response button is clicked	     
		     	display = display + "Prompt Counter " + prompt_attempt_cnt +"<br>";
		     	
		     	//check if prompt is correct or not
		     	//display = display + "Number of Steps for ind " + num_steps +"<br>";
		     	var indpp = step_ind[num_steps];
		     	//display = display + "Task Prompt Ans" + task_promt_ans[indpp] +"<br>";
		     	
		     //check if steps is already done if it is not done proceed else Start Over? ->reset all the prompt


		     	if(input_user_prompt==task_promt_ans[indpp]){ // if response is correct
						display= display+"Okay! Prompt Correct!<br>"; 
						step_attempted_correct.push(indpp); //step is already done
						

						//proceed to next steps
						num_steps++;
						prompt_attempt_cnt = 0;
						if(num_steps<total_num_steps){
						 indpp = step_ind[num_steps];	
						 display = display + " Next Demo "+ task_demo[indpp];
						}else{ //all steps are done
						 display = display + "Okay! Input the correct answer in task item box";
						}			
						
				}else{ //if response is not correct
					
					if(prompt_attempt_cnt<2){
						display= display+"Hint:"+task_hint[indpp]+"Please try again<br>";
					}else{
						display= display+"Display Prompt correct answer";

						num_steps++;
						prompt_attempt_cnt = 0;
						if(num_steps<total_num_steps){
						 indpp = step_ind[num_steps];	
						 display = display + " Next Demo "+ task_demo[indpp];
						}else{ //all steps are done
						 display = display + "Okay! Input the correct answer in task item box";
						}
					}				
				}

		     }else{
		     	display= display+" This task is already solved. Proceed to other task <br>";
		     } // end check if task item is already solved

	}else{
		display = display + "Kindly answer task items by entering answer on the input box and click check it button<br>";
	}
}


var holder = document.getElementById('tutor');
holder.innerHTML = display;
}


function checkAnswer(task_id,task_answer,task_feedback,task_points){

//get user_input_task_item_answer
var input_varname = "inputAnswer"+task_id;
var input_task_item_answer = document.getElementById(input_varname).value;

var current_point = 0;
last_task_attempted = task_id;



//Determine Problem Competion
if((solved_task.length+1)<total_task_to_solve.length){
problem_completion_status = 0; //not complete



}else{
problem_completion_status = 1; //complete
display = display + "Summary: "+problem_summary;
} // end check if problem is completed


if(input_task_item_answer==""){ //check if input is blank or not
display = display + "No blank answer! <br>";

}else{

	//check if task item is already solved
	var task_exist = 0;
	var j;
	
	for(j=0;j<solved_task.length;j++){
	     if(task_id==solved_task[j]){
	         task_exist = 1; // it exist
	     }
     }

     if(task_exist==0){ //check if the task is already solved

     		//check task_attempted exist
     		var task_attempt_exist = 0;
     		for(j=0;j<task_attempted.length;j++){
			     if(task_id==task_attempted[j]){
			         task_attempt_exist = 1; // it exist
			     }
     		}

     		// task attempts
     		if(task_attempt_exist==0){ //task is first time to attempt

     			attemp_counter = 1;
     			task_attempted.push(task_id);
     			num_of_attempt_in_task.push(attemp_counter); // value = 1
     		    //parseInt

     		    // display = display + "task attempted "+task_attempted + "<br>";
     		    // display = display + "num of attempt"+num_of_attempt_in_task + "<br>";
     		    
     		    //evaluateUserAnswer(input_task_item_answer,task_answer);
		     		    	if(input_task_item_answer==task_answer){ //correct answer

								display = display + "Well done! "+ task_feedback + "<br>"; 
								display = display + "Please proceed to solving next task item <br>";				 
								solved_task.push(task_id);
								total_points_earned = total_points_earned + parseInt(task_points);
								display = display + "Points earned: "+total_points_earned;			 
							}else{ // wrong answer
								
							 display= display+" Task Item " + task_id +" Oh no! That is not the correct answer <br>";
									 
									 //get the index of step guide of the task chosen						 	
							 		 var i;
							 		 var ind = new Array();
									 
									 for (i = 0; i < task_item_id.length; i++) {
										if(task_item_id[i]==task_id){
											ind.push(i); // index of task steps
										}
									 }
									 //user prompting - step 1 only 
									 ind_p = ind[0];
									 display = display + "Demo " +task_demo[ind_p] + "<br>";
									 display = display + "Prompt " +task_prompt[ind_p] + "<br>";
									 prompt_attempt_cnt = 0;
									 num_steps = 0; 
							
							}

     		}else{
     			var ind_of_task = task_attempted.indexOf(task_id);
     			attemp_counter = num_of_attempt_in_task[ind_of_task]; // put the value 
     			attemp_counter++;
     			num_of_attempt_in_task[ind_of_task] = attemp_counter;
     			
     		

     			// display = display + "task attempted "+task_attempted + "<br>";
     		 //    display = display + "num of attempt"+num_of_attempt_in_task + "<br>";
     		 
     		    //evaluateUserAnswer(input_task_item_answer,task_answer);

     		    // if attempt_counter == 3 then state the correct answer else 
     		    	if(attemp_counter < 3){
     		    		if(input_task_item_answer==task_answer){ //correct answer
							display = display + "Well done! "+ task_feedback + "<br>"; 
							display = display + "Please proceed to solving next task item <br>";										 
							solved_task.push(task_id);							 
						}else{ // wrong answer
							
										 
						 display= display+" Task Item " + task_id +" Oh no! That is not the correct answer <br> Let's try again <br>";
						 			 var i;
							 		 var ind = new Array();
									 
									 for (i = 0; i < task_item_id.length; i++) {
										if(task_item_id[i]==task_id){
											ind.push(i);
										}
									 }
									 //user prompting - step 1 only 
									 ind_p = ind[0];
									 display = display + "Demo " +task_demo[ind_p] + "<br>";
									 display = display + "Prompt " +task_prompt[ind_p] + "<br>";
									 prompt_attempt_cnt = 0;
									 num_steps = 0; 
						}
     		    	} else { //if attemp_counter 3 and its still wrong state the correct answer
     		    		
     		    		if(input_task_item_answer==task_answer){ //correct answer

							display = display + "Well done! "+ task_feedback + "<br>"; 
							display = display + "Please proceed to solving next task item <br>";
										 
						}else{ // wrong answer
							// things to check: if wrong attempt is not equal to 2		 
							display = display + "Nice try! The correct answer is _ <br>";
							display = display + "Please proceed to solving next task item <br>";							 
						// start looping the step guide from database
						}

     		    		 solved_task.push(task_id); // if three attempts push the task item to solved
     		    	} 		    
     		}

     }else{
     	display= display+" This task is already solved. Proceed to other task <br>";
     }
	
}


var holder = document.getElementById('tutor');
holder.innerHTML = display;

}



