
function order_all_data(datalist){}
function count_all_data(datalist){}
function add_all_data(datalist){}

function add_two_data(data1,data2){}
function subtract_two_data(data1,data2){}
function multiply_two_data(data1,data2){}
function divide_two_data(data1,data2){}

function get_highest_data(datalist){}
function get_lowest_data(datalist){}
function get_square_data(data1){} //multiply by itself
function get_square_root(data1){}