var display = "";
var solved_task = new Array(); //task items already solved
var problem_id;
var problem_data_list;
var problem_completion_status = 0 ; // 0 - not complete 1- complete

var total_points_earned = 0;

//this variables correspond with each other: 
//for every task attempted there is corresponding num of attempts, current points, points deduction
var task_attempted = new Array(); // task attempted
var num_of_attempt_in_task = new Array();
var task_attempted_points = new Array(); 
var task_points_deduction = new Array();

var attemp_counter;
var points_deduction_counter;
var prompt_attempt_cnt;
var num_steps;
var total_task_to_solve = new Array();
var total_task_to_solve_points = new Array();
var last_task_attempted;

//for step Guide Variables
var task_item_id = new Array();
var task_step_order = new Array();
var task_demo = new Array();
var task_prompt = new Array();
var task_promt_ans = new Array();
var task_hint = new Array();

var step_attempted_correct = new Array(); 
var num_of_attempt_in_steps = new Array();


var feedback_for_correct = "";
var badge = 0;

var probsolving_convo_script = {
	no_blank_answer: {
	says: ["<span style='color:#f57a00; font-size:15px; font-weight:bold;'>Ooops! Kindly enter your answer in the box!</span>"]
	},
	well_done:{
	says: ["Well done!"+feedback_for_correct]	
	},
	wrong_feedback:{
	says: ["Oh no! That is not the correct answer."]	
	},
	task_already_solved: {
	says: ["You're done in this item","Try to solve the remaining task item."]	
	},
	nice_try_feedback:{
	says: ["<span style='color:#f57a00; font-size:15px; font-weight:bold;'> Nice try, the correct answer is _"+feedback_for_correct+"</span>"]	
	},
	proceed_to_next_item:{
	says: ["Please proceed to solving the next item."]	
	},
	finish_problem_feedback:{
	says: ["<span style='color:#337eb3; font-size:15px; font-weight:bold;'>Congratulations on finishing the problem!</span>"] ,
	reply: [{question: "Continue", answer:"proceedToNextProblem"}]	
	}

	//In this problem you w
}



function getTotalTaskandMaximumPoints(task,points){
// task to solve, to determine if the problem is complete if all the task items is complete compare it to solved task
total_task_to_solve.push(task);
total_task_to_solve_points.push(points);

}

function getProblemId(data){
problem_id = data;
//problem_data_list = data;

//problem_data_list = document.getElementById('listdata').innerHTML;
} 

function importStepGuide(task_id,step_order,demo,prompt,correct_prompt,hint){
//this is working
task_item_id.push(task_id);
task_step_order.push(step_order);
task_demo.push(demo);
task_prompt.push(prompt);
task_promt_ans.push(correct_prompt);
task_hint.push(hint);

}

function solveBadge(){
	//Solve for total points earned
	var total_points_earned = 0;
	for(var i=0;i<task_attempted_points.length;i++){
	total_points_earned = parseInt(total_points_earned) + parseInt(task_attempted_points[i]);
	}

	
	var maximumpoints = 0;
	for(var j=0;j<solved_task.length;j++){
	maximumpoints = maximumpoints + parseInt(total_task_to_solve_points[j]);
	}

	var percent_badge = (total_points_earned/maximumpoints)*100;

			if(percent_badge<=44){
			///chatWindow.talk({ice: { says: ["one star",""+percent_badge]}});
			badge = 1;
			}
			else if(percent_badge>=45 && percent_badge<=85)
			{
			badge = 2;
			//chatWindow.talk({ice: { says: ["two star",""+percent_badge]}});
			}
			else if(percent_badge>=86 && percent_badge<=100){
			badge = 3;
			//chatWindow.talk({ice: { says: ["three star",""+percent_badge]}});
			}else{}
}

function proceedToNextProblem(){
// save the points and badges in the database; display it then proceed to next problem
//get points Points:5/5
var frmhtmlpoints = document.getElementById('currentPoints').innerHTML;
var points = frmhtmlpoints.substring(7,8);
window.location = "/users/problemsolving/"+problem_id+"/"+points+"/"+badge;	//users/problemsolving/{problem_id}/{totalpoints}/{badge}
}


function checkIfProblemIsComplete(answer_status){
	var test = (solved_task.length);
	if(test==total_task_to_solve.length){ //problem is complete
	//Problem Summary and wrap up here 
	
	chatWindow.talk(probsolving_convo_script,"finish_problem_feedback");
	// chatWindow.talk({ice: { says: ["Congratulations on finishing the problem!"]}});
	// chatWindow.talk({ice: { says: ["In this problem you were able to "]}});
	
	// // In this problem you were able to compute the _ 
	// // loop for solved_task and generate the summary then a reply 'proceed to load for next problem'
	// for(var i=0;i<solved_task.length;i++){
	// chatWindow.talk({ice: { says: ["Summary for topic:"+solved_task[i]]}});	
	// }
	// //Solve the badge
    solveBadge();
    
   // window.location = "1/5/2"; //users/problemsolving/{task_id}/{totalpoints}/{badge}
	}	
	else if(test<total_task_to_solve.length && answer_status==1){ // problem not complete
	chatWindow.talk(probsolving_convo_script,"proceed_to_next_item");	
	}	
}

function stepGuide(task_topic){
    switch(task_topic){
    	case "1": //mode
    	   	
    	stepGuideMode(problem_data_list);
    	break;
    	
    	case "2": //median    	
    	stepGuideMedian(problem_data_list);
    	break;

    	case "3": //mean
    	stepGuideMean(problem_data_list);
    	break;

    	case "4": //range
    	stepGuideRange(problem_data_list);
    	break;

    	case "5": //variance
    	 stepGuideVariance(problem_data_list);
    	break;

    	case "6": //standard deviation
    	stepGuideStandardDeviation(problem_data_list);
    	break

    	default:
    	break;
    }

}

function getFeedback(task_topic){
	switch(task_topic){
    	case "1": //mode   	
    	feedbackMode(problem_data_list);
    	break;
    	
    	case "2": //median
    	feedbackMedian(problem_data_list);
    	break;

    	case "3": //mean
    	feedbackMean(problem_data_list);
    	break;

    	case "4": //range
    	feedbackRange(problem_data_list);
    	break;

    	case "5": //variance
    	feedbackVariance(problem_data_list);
    	break;

    	case "6": //standard deviation
    	feedbackStandardDeviation(problem_data_list);
    	break

    	default:
    	break;
    }
}

function evaluateTheAnswerifCorrectOrWrong(input_task_item_answer,task_answer,task_id,task_topic){
	var answer_status;
	if(input_task_item_answer==task_answer){ //correct answer
		
		getFeedback(task_topic);
		//chatWindow.talk(probsolving_convo_script,"well_done");
	    solved_task.push(task_id);	
	    answer_status = 1;							 
	}else{
		points_deduction_counter++;
		//chatWindow.talk(probsolving_convo_script,"wrong_feedback");
		
		//call the step by step guide
		stepGuide(task_topic);
		answer_status = 0;
	}
	return answer_status;
}



function determineIf_TaskIsSolved(task_id){	
	var task_exist = 0;
	for(var j=0;j<solved_task.length;j++){
	     if(task_id==solved_task[j]){
	     	 var task_exist = 1;
	     }
     }
     return task_exist;
}

function determineIf_TaskAttemptExist(task_id){
	var task_attempt_exist = 0;
     		for(j=0;j<task_attempted.length;j++){
			     if(task_id==task_attempted[j]){
			         task_attempt_exist = 1; // it exist
			     }
     		}
     		return task_attempt_exist;
}

function determinedTheCorrectAnswer(task_topic){

	var task_answer="";
	switch(task_topic){
    	case "1": //mode
    	// var data = "1 1 2 2 3";
    	var mode_list = findMode(problem_data_list);
    		if(mode_list.length==1){ //one mode
    			task_answer = mode_list[0];
    		}else if(mode_list.length>1){ //two ormode mode 
    			for(var i=0;i<mode_list.length;i++){
    			 task_answer = task_answer+""+mode_list[i]+",";
    			}
    			var len = task_answer.length;
    			task_answer = task_answer.substring(0,(len-1));
    		}else{ //no mode
    			task_answer="0"; 
    		}

    	break;
    	case "2": //median
    	task_answer = findMedian(problem_data_list);
    	break;
    	case "3": //mean
    	task_answer = findMean(problem_data_list);
    	break;
    	case "4": //range
    	task_answer = findRange(problem_data_list);
    	break;
    	case "5": //variance
    	task_answer = findVariance(problem_data_list);
    	break;
    	case "6": //std
    	task_answer = findStandardDeviation(problem_data_list);
    	break;
    	default:
    	break;
    }

   
    return task_answer;
}


function checkAnswer(task_id,task_feedback,task_points,task_topic){

//Footer Items

//var task_attempted_holder = document.getElementById('taskAttempted');
var total_attempt_holder = document.getElementById('totalAttempts');
var current_point_holder = document.getElementById('currentPoints');
//var deduction_holder = document.getElementById('deduction');
var total_points_holder = document.getElementById('totalPointss');

//get user_input_task_item_answer
var input_varname = "inputAnswer"+task_id;
var input_task_item_answer = document.getElementById(input_varname).value;
var getproblem_data_list = document.getElementById('listdata').innerHTML;

problem_data_list = getproblem_data_list.substring(0,(getproblem_data_list.length)-1);
//compute the correct answer
var task_answer = determinedTheCorrectAnswer(task_topic);
feedback_for_correct = task_answer;
//chatWindow.talk({ice: { says: ["Correct answer:"+task_answer]}});

//task_attempted_holder.innerHTML =task_id;

	switch(input_task_item_answer){
		case "": //input box is blank
		 chatWindow.talk(probsolving_convo_script, "no_blank_answer");
		break;

		default: //input box is not blank
		//check if the task is solved or not
		var task_exist = determineIf_TaskIsSolved(task_id);
			switch(task_exist){
				case 0: //task not yet solved				
				
				//check if the task is already attempted or not
				var task_attempt_exist = determineIf_TaskAttemptExist(task_id);
					switch(task_attempt_exist){
						case 0: // First attempt for task item
							attemp_counter = 1;
     						points_deduction_counter = 0;
     						task_attempted.push(task_id);
     						num_of_attempt_in_task.push(attemp_counter);

     						//evaluateTheAnswerifCorrectOrWrong
     						var answer_status = evaluateTheAnswerifCorrectOrWrong(input_task_item_answer,task_answer,task_id,task_topic);

     						//Solve the points
     						var current_points_earned;					
							current_points_earned = parseInt(task_points) - points_deduction_counter;
							task_attempted_points.push(current_points_earned);
							task_points_deduction.push(points_deduction_counter);

							total_attempt_holder.innerHTML = "Attempts: "+attemp_counter+"/3";
							current_point_holder.innerHTML = "Points:"+current_points_earned+"/5";
							//deduction_holder.innerHTML = points_deduction_counter;
							checkIfProblemIsComplete(answer_status);	
						break;
						
						case 1: //Task already attempted
							var ind_of_task = task_attempted.indexOf(task_id);
     						attemp_counter = num_of_attempt_in_task[ind_of_task]; // put the value 
     						attemp_counter++;
     						num_of_attempt_in_task[ind_of_task] = attemp_counter;

     						if(attemp_counter < 3){
     					
     						//evaluateTheAnswerifCorrectOrWrong
     						var answer_status = evaluateTheAnswerifCorrectOrWrong(input_task_item_answer,task_answer,task_id,task_topic);
     						}else{
     							if(input_task_item_answer==task_answer){ //correct answer
								//chatWindow.talk({ice: { says: ["Well done!(concat with feedback)"]}});			 
								getFeedback(task_topic);
								answer_status = 1;
								}else{ // wrong answer
								points_deduction_counter++;		 
								chatWindow.talk(probsolving_convo_script,"nice_try_feedback");							 
								answer_status = 1;
								}

     		    		 	solved_task.push(task_id); 
     		    		 	//check if problem is complete
     		    		 	
     						}
     						//Solving Points 
	     					var current_points_earned;					
							current_points_earned = parseInt(task_points) - points_deduction_counter;
							task_attempted_points[ind_of_task] = current_points_earned;
							task_points_deduction[ind_of_task] = points_deduction_counter;
							
							total_attempt_holder.innerHTML = "Attempts:"+num_of_attempt_in_task[ind_of_task]+"/3";
							current_point_holder.innerHTML = "Points:"+task_attempted_points[ind_of_task]+"/5";
							//deduction_holder.innerHTML = task_points_deduction[ind_of_task];
							checkIfProblemIsComplete(answer_status);		
						break;
					}//end for checking if task is already atttempted or not
				break;
				
				case 1://task already solved
				chatWindow.talk(probsolving_convo_script, "task_already_solved");
				break;
			}//end for checking if task is solved or not
		break;
	}//end for checking if the input is blank


//Solve for total points earned
var total_points_earned = 0;
for(var i=0;i<task_attempted_points.length;i++){
total_points_earned = parseInt(total_points_earned) + parseInt(task_attempted_points[i]);
}
total_points_holder.innerHTML = total_points_earned;

} //end of checkAnswerFunction






