var convo = {
                      ice: {
                        says: ["Hi", "Would you like banana or ice cream?"],
                        reply: [
                          {
                            question: "Banana",
                            answer: "banana"
                          },
                          {
                            question: "Ice Cream",
                            answer: "ice-cream"
                          }
                        ]
                      },
                      banana: {
                        says: ["🍌"],
                        reply: [
                          {
                            question: "Start Over",
                            answer: "ice"
                          }
                        ]
                      },
                      "ice-cream": {
                        says: ["🍦"],
                        reply: [
                          {
                            question: "Start Over",
                            answer: "ice"
                          }
                        ]
                      }
                    }