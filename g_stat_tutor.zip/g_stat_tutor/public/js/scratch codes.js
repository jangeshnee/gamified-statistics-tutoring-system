var display = "";
var wrong_attempts = 0;
var num_task_to_solve = 0;
var solved_task = new Array(); //task items already solved
var task_to_solve = new Array();


function variableValueSetUp(){
// task to solve
}


function checkAnswer(task_id,task_answer,task_feedback){

//get user_input_task_item_answer
var input_varname = "inputAnswer"+task_id;
var input_task_item_answer = document.getElementById(input_varname).value;


// checked if the task is completed or not -- if it exist in solved_task array

// if task is not completed yet - it does not exist in solved_task array


if(input_task_item_answer==task_answer){ //correct answer
 //display = "That's good! "+ task_feedback;
 display = display + " That's good! "+ task_feedback + "<br>";
 // solved_task.push(task_id);

}else{ // wrong answer
 display= display+" Wrong answer "+wrong_attempts+"<br>";
 wrong_attempts++;
/*
 I'm sorry your answer is wrong, would you like me to help you solve the problem? 

 */
}

var holder = document.getElementById('tutor');
holder.innerHTML = display;

}


function stepGuide(){

}
