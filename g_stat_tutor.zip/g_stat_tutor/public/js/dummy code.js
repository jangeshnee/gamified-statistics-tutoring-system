					//get the index of step guide of the task chosen						 	
					var i,indp_counter=0, indp;
					var step_ind = new Array();
									 
					for (i = 0; i < task_item_id.length; i++) {
						if(task_item_id[i]==last_task_attempted){
							step_ind.push(i); // index of task steps
							//display = display + "index of steps "+ step_ind + "<br>";
						}
					}


					indp = step_ind[indp_counter]; //step_id

					//compare counter < step_ind.length



					//check if step is already done or not before prompt evaluation
					var step_exist = 0;
					var step_cnt = 0;
					var j;
	
					for(j=0;j<step_attempted_correct.length;j++){
					     if(indp==step_attempted_correct[j]){
					         step_exist = 1; // it exist
					     }
				     }

				     if(step_exist==0){ //step 1 prompt not yet done 

				     	//check if prompt_attempt = 0;
				     	//compare input_user_prompt to correct input of step 1 else demo-prompt 2 
							if(input_user_prompt==task_promt_ans[indp]){ // if response is correct
								display= display+"Okay! Prompt Correct!<br>"; 
								step_attempted_correct.push(ind_p); //step is already done
								//proceed to next steps

								display = display + " Next Demo "+ task_demo[ind_p+1];
								//check if ind is not empty ...


							}else{ //if response is not correct
								//display hint
								display= display+"Hint:"+task_hint[ind_p]+"Please try again<br>";
							}


				     }else{
				     	display= display+"Step Prompt already done"; 
				     	//display next step if there is any
				     }
-----------------------------------

function evaluateUserAnswer(input_task_item_answer1,task_answer1){

   if(input_task_item_answer1==task_answer1){ //correct answer

		display = display + "Well done! "+ task_feedback + "<br>"; 
		display = display + "Please proceed to solving next task item <br>";
					 
		solved_task.push(task_id);
		//display = display + solved_task + "<br>";
					 
	}else{ // wrong answer
		// things to check: if wrong attempt is not equal to 2
	 wrong_attempts++;
					 
	 display= display+" Task Item " + task_id +"Wrong answer "+wrong_attempts+"<br>";
					 
	// start looping the step guide from database
	}


var holder = document.getElementById('tutor');
holder.innerHTML = display;
}

function stepGuide(task_id){
// info needed: 
var number_of_steps = 0;
var prompt_attempt = 0;
var user_prompt_attempt;
var i;

//loop all the task_steps guide count if task id is equal 
for (i = 0; i > task_item_id.length; i++) {
	if(task_item_id[i]==task_id){
		display = display + "Demo " +task_demo[i] + "<br>";
		display = display + "Prompt " +task_prompt[i] + "<br>";
	}
}


for (i = 0; i > number_of_steps; i++) {
	display = display + "Demo Description here<br>"; 
	display = display + "Prompt Description here<br>"; 
};

var holder = document.getElementById('tutor');
holder.innerHTML = display;

}


---------------

chatWindow.talk({
    ice: {
      says: ["Hey!", "Test Only!"]  
    }) // end required "ice" conversation object
-----------------------------

<div class="col-md-3">
               PROBLEM TITLE correspond with BADGE <br>
               TOTAL PROBLEM SOLVED 6/total 
              </div>

              <div class="col-md-3">
                <img src="icons/035-silver-medal.png" width="40%" height="40%">
              </div>

              <div class="col-md-3">
               PROBLEM TITLE correspond with BADGE <br>
               TOTAL PROBLEM SOLVED 6/total 
              </div>

              <div class="col-md-3">
                <img src="icons/035-silver-medal.png" width="40%" height="40%">
              </div>



               echo "<div class='col-md-6'>";
             echo $users_solved_problems_titles[$p_index]."".$users_solved_problems_badge[$p_index].
             "</div>";

             echo "<div class='col-md-6'>";
             echo $users_solved_problems_titles[$p_index+1]."".$users_solved_problems_badge[$p_index+1].
             "</div>";
            


                      <?php 
            
            //$total_row = ceil($solved_problems/2);
            $total_row = $solved_problems;
            $prob_solved = $solved_problems;
            //echo $total_row;
            
            //if solved_problems is odd 
            //if solved_problems is even
            
            $p_index = 0;
            for ($i=0; $i<$total_row; $i++){
             echo "<div class='row'>";
             
             
             echo "<div class='col-md-6'>";
             echo $users_solved_problems_titles[$p_index];
             echo "<img src='url('icons/005-girl.png')' width='70%' height='70%'>".
             //$users_solved_problems_badge[$p_index].
             "</div>";

             echo "</div>";
             $p_index = $p_index+1;
                }
            ?>