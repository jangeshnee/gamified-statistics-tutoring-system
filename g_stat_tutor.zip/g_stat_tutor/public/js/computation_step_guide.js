//--------------Computations to solve the correct answer
function findMode(data_list){

    var numbers = data_list.split(" ");
    var modes = [], count = [], i, number, maxIndex = 0;
 
    for (i = 0; i < numbers.length; i += 1) {
        number = numbers[i];
        count[number] = (count[number] || 0) + 1;
        if (count[number] > maxIndex) {
            maxIndex = count[number];
        }
    }
 
    for (i in count)
        if (count.hasOwnProperty(i)) {
            if (count[i] === maxIndex) {
                modes.push(Number(i));
            }
        }

    if(maxIndex==1){ //no mode
      return 0;
    }
    else if(modes.length>1 && maxIndex>1){ // more than one mode
      return modes;
    }
    else{ //one mode
       return modes;
    }

   
}
function findMedian(data_list){
	var splitted = data_list.split(" ");
	var sorted_data = splitted.sort();
	var median;

	//determine if the data lis is odd or even
	if(sorted_data.length%2==0){//even
		//get the index 1
		//get the index 2
		var ind1 = ((parseInt(sorted_data.length))/2)-1;
		var ind2 = ind1+1;		
		median = (parseInt(sorted_data[ind1])+parseInt(sorted_data[ind2]))/2;		
	}else{ //odd		
		var median_index = ((parseInt(sorted_data.length)-1)/2);
		median = sorted_data[median_index];
	}

	return median;
}

function findMean(data_list){

	var splitted = data_list.split(" ");
	var sum = 0;
	for(var i=0;i<splitted.length;i++){
	sum = sum + parseInt(splitted[i]);
	}
	var mean = sum/parseInt(splitted.length);
	mean = mean.toFixed(2);
	return mean;
}

function findRange(data_list){
	var splitted = data_list.split(" ");
	var sorted_data = splitted.sort();

	var last_ind = parseInt(sorted_data.length)-1;

	var range = parseInt(sorted_data[last_ind]) - parseInt(sorted_data[0]);
	return range;
}

function findVariance(data_list){
	var mean = findMean(data_list);
	var splitted = data_list.split(" ");
	
	var sum = 0;
	var diff;
		for(var i=0;i<splitted.length;i++){
		diff = parseInt(splitted[i])-mean;
		sum = sum + (diff*diff);
		}
	var variance = sum/(parseInt(splitted.length)-1);
	variance = variance.toFixed(2);
	
	return variance;
}


function findStandardDeviation(data_list){
	var variance = findVariance(data_list);
	var std = Math.sqrt(variance);
    std = std.toFixed(2);
	return std;
}

//------------------Step by Step Guide Conversation Script --------------
function stepGuideMode(data_list){
	var splitted = data_list.split(" ");
	var sorted_data = splitted.sort();


  var mode_step_convo_script = {
		ice: {
    		says: ["<span style='color:#ff0000; font-size:15px; font-weight:bold;'>Oh no! That is not the correct answer.</span>","Would you like me to help you?"],
    		reply: [
    		        {question: "No, Thanks!", answer: "instruct_to_solve"},
    		        {question: "Yes, Please!", answer: "define_topic"}
    		        ]
  		},
    start_over: {
        says: ["Would you like me to help you?"],
        reply: [
                {question: "No, Thanks!", answer: "instruct_to_solve"},
                {question: "Yes, Please!", answer: "define_topic"}
                ]
      },
  		instruct_to_solve: {
		    says: ["Okay,carefully read the problem then enter your answer on the box and click the check it button. "],
		    reply: [{question: "Start Over", answer: "start_over"}]
  	    },
  	 define_topic: {
		    says: ["I'm glad to help you!","The <b>mode</b> of a data set is the value that occurs most frequently. ","Let me help you!"],
		    reply: [{question: "Okay, proceed!", answer: "step_one"}]
  		},
  		step_one: {
		    says: ["First, we need to order the values from smallest to largest.","Let me order the data for you."],
		    reply: [{question: "Okay", answer: "step_order_data"}] // function to determine if one, two or no mode
  		},
  		step_order_data: {
		    says: ["Ordering the data the result is : "+splitted],
		    reply: [{question: "Proceed", answer: "nextStep_Mode"}] // function to determine if one, two or no mode
  		}

	}//mode_step_convo_script
	chatWindow.talk(mode_step_convo_script,"ice");
}

//chatWindow.talk({ice: { says: ["List of data:"+data_list]}});
function nextStep_Mode(){

var data_list = document.getElementById('listdata').innerHTML;
var splitted = data_list.split(" ");
var sorted_data = splitted.sort();

//chatWindow.talk({ice: { says: ["List of data:"+data_list]}});

  var numbers = data_list.split(" ");
  var modes = [], count = [], i, number, maxIndex = 0;
 
    for (i = 0; i < numbers.length; i += 1) {
        number = numbers[i];
        count[number] = (count[number] || 0) + 1;
        if (count[number] > maxIndex) {
            maxIndex = count[number];
        }
    }
 
    for (i in count)
        if (count.hasOwnProperty(i)) {
            if (count[i] === maxIndex) {
                modes.push(Number(i));
            }
        }


  var mode_step_convo_script = {
      step_one_mode_final: {
        says: ["Which value appears most often?","Enter your answer on the box and click the check it button."]
        // reply: [{question: "Proceed", answer: "step_two_mode"}] 
      },
      step_two_mode: {
        says: ["Oh wait! Did you notice that there are more than one value which appears "+maxIndex+" times?"],
        reply: [{question: "Yes", answer: "step_two_mode_final"},{question: "No", answer: "step_two_mode_correction_final"}] //check if answer is correct function
      },
      step_two_mode_final: {
        says: ["Which values are this?","Kindly enter the numbers separated by (,) ex. 5,8 ;in the box and click the check it button. "]
        //reply: [{question: "Proceed", answer: ""}]
      },
      step_two_mode_correction_final: {
        says: ["Uh-huh! There are more than one value which appears "+maxIndex+" times. ","Which values are this?","Kindly enter the numbers separated by (,) in the box and click the check it button. "]
      },
      step_no_mode:{
        says: ["Oh wait! Did you notice that all the values in our data set appear only once? "],
        reply: [{question: "Yes", answer: "step_no_mode_final"},{question: "No", answer: "step_no_mode_correction_final"}] 
      },
      step_no_mode_final:{
        says: ["Great! This means that our data set has no mode.","Please enter 0 in the box and click the check it button. "]
      },
      step_no_mode_correction_final:{
        says: ["Uh-huh! All the values in our data set appear once.","This means that our data set has no mode.","Please enter 0 in the box and click the check it button. "]
      }

  }//mode_step_convo_script



    //determine if one, more than one or no mode

    if(maxIndex==1){ //no mode
    	chatWindow.talk(mode_step_convo_script, "step_no_mode");
    }
    else if(modes.length>1 && maxIndex>1){ // more than one mode
    	chatWindow.talk(mode_step_convo_script, "step_two_mode");
    	
    }
    else{ //one mode
    	chatWindow.talk(mode_step_convo_script, "step_one_mode_final");
    }

}

function stepGuideMedian(data_list){
	var splitted = data_list.split(" ");
	var sorted_data = splitted.sort();
	
	var median_step_convo_script = {
		ice: {
        says: ["<span style='color:#ff0000; font-size:15px; font-weight:bold;'>Oh no! That is not the correct answer.</span>","Would you like me to help you?"],
        reply: [
                {question: "No, Thanks!", answer: "instruct_to_solve"},
                {question: "Yes, Please!", answer: "define_topic"}
                ]
      },
    start_over: {
        says: ["Would you like me to help you?"],
        reply: [
                {question: "No, Thanks!", answer: "instruct_to_solve"},
                {question: "Yes, Please!", answer: "define_topic"}
                ]
      },
      instruct_to_solve: {
        says: ["Okay,carefully read the problem then enter your answer on the box and click the check it button. "],
        reply: [{question: "Start Over", answer: "start_over"}]
        },
  	    define_topic: {
		    says: ["I'm glad to help you!","<b>Median</b> is the middle value in a data set.","Let me help you!"],
		    reply: [{question: "Okay, proceed!", answer: "step_one"}]
  		},
      step_one: {
        says: ["First, we need to order the values from smallest to largest.","Let me order the data for you."],
        reply: [{question: "Okay", answer: "step_order_data"}] // function to determine if one, two or no mode
      },
      step_order_data: {
        says: ["Ordering the data the result is : "+splitted],
        reply: [{question: "Proceed", answer: "StepTwoMedian"}] // function to determine if one, two or no mode
      }
	}

	chatWindow.talk(median_step_convo_script);
}

function StepTwoMedian(){ // How many values are in the data set?

  var data_list = document.getElementById('listdata').innerHTML;
  data_list = data_list.substring(0,(data_list.length-1));
  var splitted = data_list.split(" ");
  var num_of_choices = Math.floor(Math.random()*3)+1; // find a way to make it random from 1-3
  var choice_key = "";
  var data_list_length = splitted.length;
  var option_A = data_list_length - 1;
  var option_B = data_list_length - 2;

  switch(num_of_choices){
    case 1:
    choice_key = "step_two_choice_one";   
    break;    
    case 2:
    choice_key = "step_two_choice_two";
    break;   
    case 3:
    choice_key = "step_two_choice_three";
    break;
    default:
    //chatWindow.talk(median_step_convo_script, "step_two_choice_one");
    break;
  }
  
  var median_step_convo_script = {
    step_two_choice_one: {
        says: ["How many values are in the data set?"],
        reply: [{question: data_list_length, answer: "step_two_correct"},{question: option_A, answer: "step_two_wrong"},{question: option_B, answer: "step_two_wrong"}] //check if answer is correct function
      },
    step_two_choice_two: {
        says: ["How many values are in the data set?"],
        reply: [{question: option_A, answer: "step_two_wrong"},{question: data_list_length, answer: "step_two_correct"},{question: option_B, answer: "step_two_wrong"}] //check if answer is correct function
      },
    step_two_choice_three: {
        says: ["How many values are in the data set?"],
        reply: [{question: option_B, answer: "step_two_wrong"},{question: option_A, answer: "step_two_wrong"},{question: data_list_length, answer: "step_two_correct"}] //check if answer is correct function
      },
     step_two_correct: {
        says: ["Great! Is <b>"+data_list_length+" </b> odd or even? "],
        reply: [{question: "Odd", answer: "stepThreeMedianDetermineIfOdd"},{question: "Even", answer: "stepThreeMedianDetermineIfEven"}] //check if answer is correct function
      },
     step_two_wrong:{
      says: ["Oh no! Please try again."],
      reply: [{question: "Okay!", answer:choice_key}]
     }
  }

  switch(num_of_choices){
    case 1:   
    chatWindow.talk(median_step_convo_script, "step_two_choice_one"); 
    break;
    
    case 2:   
    chatWindow.talk(median_step_convo_script, "step_two_choice_two");
    break;
    
    case 3:
    chatWindow.talk(median_step_convo_script, "step_two_choice_three");
    break;

    default:
    //chatWindow.talk(median_step_convo_script, "step_two_choice_one");
    break;
  }
}

function stepThreeMedianDetermineIfOdd(){
  var data_list = document.getElementById('listdata').innerHTML;
  data_list = data_list.substring(0,(data_list.length-1));
  var splitted = data_list.split(" ");

  var median_step_convo_script = {
    step_odd: {
        says: ["Since there are <b>"+splitted.length+"</b> values in our data set. And <b>"+splitted.length+"</b> is an <b>odd</b> number.","What is the center value of the data set?","Enter your answer in the box and click the check it button."]
      },
    step_even_correction:{
      says: ["Uh-huh! The number <b>"+splitted.length+"</b> is <b> even </b>!"], // call stepThreeMedianEven
      reply: [{question: "Proceed", answer:"stepThreeMedianDetermineIfEven"}]
     }
  }
  if(splitted.length%2==0){ //even // the user is wrong need to correct
    chatWindow.talk(median_step_convo_script, "step_even_correction");
  }else{ //odd // the user is correct
    chatWindow.talk(median_step_convo_script, "step_odd");
  }
}

function stepThreeMedianDetermineIfEven(){
  var data_list = document.getElementById('listdata').innerHTML;
  data_list = data_list.substring(0,(data_list.length-1));
  var splitted = data_list.split(" ");
  var num_of_choices = Math.floor(Math.random()*3)+1;
  var sorted_data = splitted.sort();
  var ind1 = ((parseInt(sorted_data.length))/2)-1;
  var ind2 = ind1+1;

  var correct_option= sorted_data[ind1]+" and "+sorted_data[ind2];
  var wrong_option = (parseInt(sorted_data[ind1])-1) +" and "+ (parseInt(sorted_data[ind2])+1);



  var median_step_convo_script = {
   step_even_choice_one: {
        says: ["Since there are  <b>"+splitted.length+"</b> values in our data set. And <b>"+splitted.length+"</b> is <b>even</b> number.","In our ordered data set: <b>"+splitted.sort()+"</b>","What are the two middle values?"],
        reply: [{question: correct_option , answer: "step_even_correct"},{question: wrong_option, answer: "step_even_correction"}] //check if answer is correct function
      },
  step_even_choice_two: {
        says: ["Since there are  <b>"+splitted.length+"</b> values in our data set. And <b>"+splitted.length+"</b> is <b>even</b> number.","In our ordered data set: <b>"+splitted.sort()+"</b>","What are the two middle values?"],
        reply: [{question: wrong_option, answer: "step_even_correction"},{question: correct_option, answer: "step_even_correct"}] //check if answer is correct function
      },
    step_even_correct:{
       says: ["Great! Add <b>"+ sorted_data[ind1]+"</b> and <b>"+ sorted_data[ind2]+"</b> then divide it by <b>2</b>. Enter your answer on the box and click check it button."]
     },
    step_even_correction:{
       says: ["Uh-huh!The two middle values of the data set are <b>"+ sorted_data[ind1]+"</b> and <b>"+ sorted_data[ind2]+"</b>",
       "Now, Add <b>"+ sorted_data[ind1]+"</b> and <b>"+ sorted_data[ind2]+"</b> then divide it by <b>2</b>. Enter your answer on the box and click check it button."]
     },
    step_odd_correction:{
      says: ["Uh-huh! The number <b>"+splitted.length+"</b> is <b> odd </b>!"],
      reply: [{question: "Proceed", answer:"stepThreeMedianDetermineIfOdd"}]
     }
  }
  if(splitted.length%2==0){ //even // the user is correct
    if(num_of_choices==1){
      chatWindow.talk(median_step_convo_script, "step_even_choice_one");
    }else if(num_of_choices==2){
      chatWindow.talk(median_step_convo_script, "step_even_choice_two");
    }else{}
    
  }else{ //odd // the user is wrong need to correct
    chatWindow.talk(median_step_convo_script, "step_odd_correction");
  }
}



function stepGuideMean(data_list){

	var mean_step_convo_script = {
	ice: {
        says: ["<span style='color:#ff0000; font-size:15px; font-weight:bold;'>Oh no! That is not the correct answer.</span>","Would you like me to help you?"],
        reply: [
                {question: "No, Thanks!", answer: "instruct_to_solve"},
                {question: "Yes, Please!", answer: "define_topic"}
                ]
      },
    start_over: {
        says: ["Would you like me to help you?"],
        reply: [
                {question: "No, Thanks!", answer: "instruct_to_solve"},
                {question: "Yes, Please!", answer: "define_topic"}
                ]
      },
      instruct_to_solve: {
        says: ["Okay,carefully read the problem then enter your answer on the box and click the check it button. "],
        reply: [{question: "Start Over", answer: "start_over"}]
        },
  	  define_topic: {
		    says: ["I'm glad to help you!","<b>Mean</b> is the most common measure of average.","Let me help you!"],
		    reply: [{question: "Okay, proceed!", answer: "stepOneMean"}]
  		}
	}//mean_step_convo_script

	chatWindow.talk(mean_step_convo_script);
}

function stepOneMean(){ //what is the sum?
  var data_list = document.getElementById('listdata').innerHTML;
  data_list = data_list.substring(0,(data_list.length-1));
  var num_of_choices = Math.floor(Math.random()*3)+1;
  var choice_key = "";

  //get the sum 
  var splitted = data_list.split(" ");
  var sum = 0;
  for(var i=0;i<splitted.length;i++){
  sum = sum + parseInt(splitted[i]);
  }

  //create options here
  var option_A = sum - 1;
  var option_B = sum - 2;

  switch(num_of_choices){
    case 1:
    choice_key = "step_one_mean_choice_one";   
    break;    
    case 2:
    choice_key = "step_one_mean_choice_two";
    break;   
    case 3:
    choice_key = "step_one_mean_choice_three";
    break;
    default:
    //chatWindow.talk(median_step_convo_script, "step_two_choice_one");
    break;
  }

  var mean_step_convo_script = {
    step_one_mean_choice_one: {
        says: ["What is sum of all the values in the data set?"],
        reply: [{question: sum, answer: "stepTwoMean"},{question: option_A, answer: "step_one_wrong"},{question: option_B, answer: "step_one_wrong"} ] 
      },
    step_one_mean_choice_two: {
        says: ["What is sum of all the values in the data set?"],
        reply: [{question: option_A, answer: "step_one_wrong"},{question: sum, answer: "stepTwoMean"},{question: option_B, answer: "step_one_wrong"} ] 
      },
    step_one_mean_choice_three: {
        says: ["What is sum of all the values in the data set?"],
        reply: [{question: option_A, answer: "step_one_wrong"},{question: option_B, answer: "step_one_wrong"},{question: sum, answer: "stepTwoMean"} ] 
      },
     step_one_wrong:{
      says: ["Oh no! Please try again."],
      reply: [{question: "Okay!", answer:choice_key}]
     }
  }

   switch(num_of_choices){
    case 1:   
    chatWindow.talk(mean_step_convo_script, "step_one_mean_choice_one"); 
    break;
    
    case 2:   
    chatWindow.talk(mean_step_convo_script, "step_one_mean_choice_two");
    break;
    
    case 3:
    chatWindow.talk(mean_step_convo_script, "step_one_mean_choice_three");
    break;

    default:
    //chatWindow.talk(median_step_convo_script, "step_two_choice_one");
    break;
  }
}

function stepTwoMean(){ //How many values are in the data set?
var data_list = document.getElementById('listdata').innerHTML;
  data_list = data_list.substring(0,(data_list.length-1));

  var splitted = data_list.split(" ");
  var num_of_choices = Math.floor(Math.random()*3)+1;
  var choice_key = "";
  var data_list_length = splitted.length;
  var option_A = data_list_length - 1;
  var option_B = data_list_length - 2;

  switch(num_of_choices){
    case 1:
    choice_key = "step_two_choice_one";   
    break;    
    case 2:
    choice_key = "step_two_choice_two";
    break;   
    case 3:
    choice_key = "step_two_choice_three";
    break;
    default:
    //chatWindow.talk(median_step_convo_script, "step_two_choice_one");
    break;
  }
  
  //get the sum 
  
  var sum = 0;
  for(var i=0;i<splitted.length;i++){
  sum = sum + parseInt(splitted[i]);
  }

  var mean_step_convo_script = {
    step_two_choice_one: {
        says: ["How many values are in the data set?"],
        reply: [{question: data_list_length, answer: "step_two_correct"},{question: option_A, answer: "step_two_wrong"},{question: option_B, answer: "step_two_wrong"}] //check if answer is correct function
      },
    step_two_choice_two: {
        says: ["How many values are in the data set?"],
        reply: [{question: option_A, answer: "step_two_wrong"},{question: data_list_length, answer: "step_two_correct"},{question: option_B, answer: "step_two_wrong"}] //check if answer is correct function
      },
    step_two_choice_three: {
        says: ["How many values are in the data set?"],
        reply: [{question: option_B, answer: "step_two_wrong"},{question: option_A, answer: "step_two_wrong"},{question: data_list_length, answer: "step_two_correct"}] //check if answer is correct function
      },
     step_two_correct: {
        says: ["Good! Divide <b>"+sum+"</b> by <b>"+splitted.length+"</b>.","Enter your answer on the box and click check it button"]
      },
     step_two_wrong:{
      says: ["Oh no! Please try again."],
      reply: [{question: "Okay!", answer:choice_key}]
     }
  }

  switch(num_of_choices){
    case 1:   
    chatWindow.talk(mean_step_convo_script, "step_two_choice_one"); 
    break;
    
    case 2:   
    chatWindow.talk(mean_step_convo_script, "step_two_choice_two");
    break;
    
    case 3:
    chatWindow.talk(mean_step_convo_script, "step_two_choice_three");
    break;

    default:
    //chatWindow.talk(median_step_convo_script, "step_two_choice_one");
    break;
  }
}


function stepGuideRange(data_list){
	var splitted = data_list.split(" ");
  var sorted_data = splitted.sort();
  

  var range_step_convo_script = {
    ice: {
        says: ["<span style='color:#ff0000; font-size:15px; font-weight:bold;'>Oh no! That is not the correct answer.</span>","Would you like me to help you?"],
        reply: [
                {question: "No, Thanks!", answer: "instruct_to_solve"},
                {question: "Yes, Please!", answer: "define_topic"}
                ]
      },
    start_over: {
        says: ["Would you like me to help you?"],
        reply: [
                {question: "No, Thanks!", answer: "instruct_to_solve"},
                {question: "Yes, Please!", answer: "define_topic"}
                ]
      },
      instruct_to_solve: {
        says: ["Okay,carefully read the problem then enter your answer on the box and click the check it button. "],
        reply: [{question: "Start Over", answer: "start_over"}]
        },
     define_topic: {
        says: ["I'm glad to help you!","The <b>range</b>is the difference between the largest and smallest values of a data distribution.","Let me help you!"],
        reply: [{question: "Okay, proceed!", answer: "step_one"}]
      },
      step_one: {
        says: ["First, we need to order the values from smallest to largest.","Let me order the data for you."],
        reply: [{question: "Okay", answer: "step_order_data"}] // function to determine if one, two or no mode
      },
      step_order_data: {
        says: ["Ordering the data the result is : "+splitted],
        reply: [{question: "Proceed", answer: "stepTwoRange"}] // function to determine if one, two or no mode
      }

  }//mode_step_convo_script
  chatWindow.talk(range_step_convo_script,"ice");
}

function stepTwoRange(){ //What is the largest data?
var data_list = document.getElementById('listdata').innerHTML;
    data_list = data_list.substring(0,(data_list.length-1));
var splitted = data_list.split(" ");
var sorted_data = splitted.sort();
var last_ind = parseInt(sorted_data.length)-1;

var num_of_choices = Math.floor(Math.random()*3)+1;
var choice_key = "";

var option_A = parseInt(sorted_data[last_ind])+1;
var option_B = parseInt(sorted_data[last_ind])-1;

switch(num_of_choices){
    case 1:
    choice_key = "step_two_choice_one";   
    break;    
    case 2:
    choice_key = "step_two_choice_two";
    break;   
    case 3:
    choice_key = "step_two_choice_three";
    break;
    default:
    //chatWindow.talk(median_step_convo_script, "step_two_choice_one");
    break;
  }

 var range_step_convo_script = {
    step_two_choice_one: {
        says: ["What is the highest value in the data set?"],
        reply: [{question: sorted_data[last_ind], answer: "stepThreeRange"},{question: option_A, answer: "step_two_wrong"},{question: option_B, answer: "step_two_wrong"}] //check if answer is correct function
      },
    step_two_choice_two: {
         says: ["What is the highest value in the data set?"],
        reply: [{question: option_A, answer: "step_two_wrong"},{question: sorted_data[last_ind], answer: "stepThreeRange"},{question: option_B, answer: "step_two_wrong"}] //check if answer is correct function
      },
    step_two_choice_three: {
         says: ["What is the highest value in the data set?"],
        reply: [{question: option_B, answer: "step_two_wrong"},{question: option_A, answer: "step_two_wrong"},{question: sorted_data[last_ind], answer: "stepThreeRange"}] //check if answer is correct function
      },
     step_two_wrong:{
      says: ["Oh no! Please try again."],
      reply: [{question: "Okay!", answer:choice_key}]
     }
  }

  switch(num_of_choices){
    case 1:   
    chatWindow.talk(range_step_convo_script, "step_two_choice_one"); 
    break;
    
    case 2:   
    chatWindow.talk(range_step_convo_script, "step_two_choice_two");
    break;
    
    case 3:
    chatWindow.talk(range_step_convo_script, "step_two_choice_three");
    break;

    default:
    break;
  }
}

function stepThreeRange(){ //What is the smallest data?
var data_list = document.getElementById('listdata').innerHTML;
    data_list = data_list.substring(0,(data_list.length-1));
var splitted = data_list.split(" ");
var sorted_data = splitted.sort();
var last_ind = parseInt(sorted_data.length)-1;

var num_of_choices = Math.floor(Math.random()*3)+1;
var choice_key = "";

var option_A = parseInt(sorted_data[0])+1;
var option_B = parseInt(sorted_data[0])-1;

switch(num_of_choices){
    case 1:
    choice_key = "step_two_choice_one";   
    break;    
    case 2:
    choice_key = "step_two_choice_two";
    break;   
    case 3:
    choice_key = "step_two_choice_three";
    break;
    default:
    //chatWindow.talk(median_step_convo_script, "step_two_choice_one");
    break;
  }

 var range_step_convo_script = {
    step_two_choice_one: {
        says: ["What is the smallest value in the data set?"],
        reply: [{question: sorted_data[0], answer: "step_two_correct"},{question: option_A, answer: "step_two_wrong"},{question: option_B, answer: "step_two_wrong"}] //check if answer is correct function
      },
    step_two_choice_two: {
         says: ["What is the smallest value in the data set?"],
        reply: [{question: option_A, answer: "step_two_wrong"},{question: sorted_data[0], answer: "step_two_correct"},{question: option_B, answer: "step_two_wrong"}] //check if answer is correct function
      },
    step_two_choice_three: {
         says: ["What is the smallest value in the data set?"],
        reply: [{question: option_B, answer: "step_two_wrong"},{question: option_A, answer: "step_two_wrong"},{question: sorted_data[0], answer: "step_two_correct"}] //check if answer is correct function
      },
    step_two_correct:{
      says: ["Good! Subtract <b>"+sorted_data[0]+"</b> to <b>"+sorted_data[last_ind]+"</b>","Enter your answer on the box and click check it button"]
    },
     step_two_wrong:{
      says: ["Oh no! Please try again."],
      reply: [{question: "Okay!", answer:choice_key}]
     }
  }

  switch(num_of_choices){
    case 1:   
    chatWindow.talk(range_step_convo_script, "step_two_choice_one"); 
    break;
    
    case 2:   
    chatWindow.talk(range_step_convo_script, "step_two_choice_two");
    break;
    
    case 3:
    chatWindow.talk(range_step_convo_script, "step_two_choice_three");
    break;

    default:
    break;
  }
}

function stepGuideVariance(data_list){
	//chatWindow.talk({ice: { says: ["Variance Step Guide"]}});
  var variance_step_convo_script = {
  ice: {
        says: ["<span style='color:#ff0000; font-size:15px; font-weight:bold;'>Oh no! That is not the correct answer.</span>","Would you like me to help you?"],
        reply: [
                {question: "No, Thanks!", answer: "instruct_to_solve"},
                {question: "Yes, Please!", answer: "define_topic"}
                ]
      },
    start_over: {
        says: ["Would you like me to help you?"],
        reply: [
                {question: "No, Thanks!", answer: "instruct_to_solve"},
                {question: "Yes, Please!", answer: "define_topic"}
                ]
      },
      instruct_to_solve: {
        says: ["Okay,carefully read the problem then enter your answer on the box and click the check it button. "],
        reply: [{question: "Start Over", answer: "start_over"}]
        },
      define_topic: {
        says: ["I'm glad to help you!",
        "<b>Variance</b> measures how far a data set is spread out.",
        "The computation formula of variance is <br> <span style='font-size:20px'> <span style='color:#ff0000'>&sum;x<sup>2</sup> </span> - <span style='color:#0000ff'>(&sum;x)<sup>2</sup>/n) </span>/ <span style='color:#00ff00'>(n-1) </span></span>",
        "In this formula <b>x</b> represent <i>any value in the data set</i> and <b style='font-size:15px'> ∑ </b>is a <i>summation symbol.</i>",
        "The notation <b style='font-size:15px'>&sum;x</b> is read as <i>the sum of all given x values</i> and <b>n</b> is the <i>total number of values in the data set.</i>"],
        reply: [{question: "Okay, Got it!", answer: "stepOneVariance"}]
      }
  }//variance_step_convo_script

  chatWindow.talk(variance_step_convo_script, "ice");
}

function stepOneVariance(){ //Add up all the numbers
  var data_list = document.getElementById('listdata').innerHTML;
  data_list = data_list.substring(0,(data_list.length-1));
  var num_of_choices = Math.floor(Math.random()*3)+1;
  var choice_key = "";

  //get the sum 
  var splitted = data_list.split(" ");
  var sum = 0;
  for(var i=0;i<splitted.length;i++){
  sum = sum + parseInt(splitted[i]);
  }

  //create options here
  var option_A = sum - 1;
  var option_B = sum - 2;

  switch(num_of_choices){
    case 1:
    choice_key = "step_one_var_choice_one";   
    break;    
    case 2:
    choice_key = "step_one_var_choice_two";
    break;   
    case 3:
    choice_key = "step_one_var_choice_three";
    break;
    default:
    break;
  }

  var variance_step_convo_script = {
    step_one_var_choice_one: {
        says: ["Step1: Compute <span style='color:#0000ff'>&sum;x </span>by adding all the values in the data set.","What would be the result?"],
        reply: [{question: sum, answer: "stepTwoVariance"},{question: option_A, answer: "step_one_wrong"},{question: option_B, answer: "step_one_wrong"} ] 
      },
    step_one_var_choice_two: {
       says: ["Step1: Compute <span style='color:#0000ff'>&sum;x </span>by adding all the values in the data set.","What would be the result?"],
        reply: [{question: option_A, answer: "step_one_wrong"},{question: sum, answer: "stepTwoVariance"},{question: option_B, answer: "step_one_wrong"} ] 
      },
    step_one_var_choice_three: {
        says: ["Step1: Compute <span style='color:#0000ff'>&sum;x </span>by adding all the values in the data set.","What would be the result?"],
        reply: [{question: option_A, answer: "step_one_wrong"},{question: option_B, answer: "step_one_wrong"},{question: sum, answer: "stepTwoVariance"} ] 
      },
     step_one_wrong:{
      says: ["Oh no! Please try again."],
      reply: [{question: "Okay!", answer:choice_key}]
     }
  }

   switch(num_of_choices){
    case 1:   
    chatWindow.talk(variance_step_convo_script, "step_one_var_choice_one"); 
    break;
    
    case 2:   
    chatWindow.talk(variance_step_convo_script, "step_one_var_choice_two");
    break;
    
    case 3:
    chatWindow.talk(variance_step_convo_script, "step_one_var_choice_three");
    break;

    default:
    break;
  }
}


function stepTwoVariance(){ // squared sum divide by n
var data_list = document.getElementById('listdata').innerHTML;
  data_list = data_list.substring(0,(data_list.length-1));
  var num_of_choices = Math.floor(Math.random()*3)+1;
  var choice_key = "";

  //get the sum 
  var splitted = data_list.split(" ");
  var sum = 0;
  for(var i=0;i<splitted.length;i++){
  sum = sum + parseInt(splitted[i]);
  }

  var step_two_result = (sum * sum)/parseInt(splitted.length);
  var option_A = step_two_result + 1;
  var option_B = step_two_result - 1;

    switch(num_of_choices){
    case 1:
    choice_key = "step_two_var_choice_one";   
    break;    
    case 2:
    choice_key = "step_two_var_choice_two";
    break;   
    case 3:
    choice_key = "step_two_var_choice_three";
    break;
    default:
    break;
  }

var variance_step_convo_script = {
  step_two_var_choice_one: {
        says: ["Step 2: Compute for <span style='color:#0000ff'>(&sum;x)<sup>2</sup>/n) </span> by <i> squaring the sum and divide it by the total number of entries</i>.",
              "Here is the computation demo: <b>"+sum+" x "+sum+" divided by "+splitted.length+"</b>",
              "What is the result?"],
        reply: [{question: step_two_result, answer: "stepThreeVariance"},{question: option_A, answer: "step_two_wrong"},{question: option_B, answer: "step_two_wrong"}] 
      },
  step_two_var_choice_two: {
        says: ["Step 2: Compute for <span style='color:#0000ff'>(&sum;x)<sup>2</sup>/n) </span> by <i> squaring the sum and divide it by the total number of entries</i>.","Here is the computation demo: <b>"+sum+" x "+sum+" divided by "+splitted.length+"</b>","What is the result?"],
        reply: [{question: option_A, answer: "step_two_wrong"},{question: step_two_result, answer: "stepThreeVariance"},{question: option_B, answer: "step_two_wrong"}] 
      },
  step_two_var_choice_three: {
       says: ["Step 2: Compute for <span style='color:#0000ff'>(&sum;x)<sup>2</sup>/n) </span> by <i> squaring the sum and divide it by the total number of entries</i>.","Here is the computation demo: <b>"+sum+" x "+sum+" divided by "+splitted.length+"</b>","What is the result?"],
        reply: [{question: option_A, answer: "step_two_wrong"},{question: option_B, answer: "step_two_wrong"},{question: step_two_result, answer: "stepThreeVariance"}] 
      },
    step_two_wrong:{
      says: ["Oh no! Please try again."],
      reply: [{question: "Okay!", answer:choice_key}]
    }
}

    switch(num_of_choices){
    case 1:   
    chatWindow.talk(variance_step_convo_script, "step_two_var_choice_one"); 
    break;
    
    case 2:   
    chatWindow.talk(variance_step_convo_script, "step_two_var_choice_two");
    break;
    
    case 3:
    chatWindow.talk(variance_step_convo_script, "step_two_var_choice_three");
    break;

    default:
    chatWindow.talk(variance_step_convo_script, "step_two_var_choice_one"); 
    break;
  }

}


function stepThreeVariance(){ //individual squared sum 
var data_list = document.getElementById('listdata').innerHTML;
  data_list = data_list.substring(0,(data_list.length-1));
  var num_of_choices = Math.floor(Math.random()*3)+1;
  var choice_key = "";

  //get the sum 
  var splitted = data_list.split(" ");
  var sum=0,sum1 = 0;
  var demo = "";
  for(var i=0;i<splitted.length;i++){
  sum1 = sum1 + (parseInt(splitted[i])*parseInt(splitted[i]));
  sum = sum + parseInt(splitted[i]);
  demo = demo+"("+splitted[i]+"x"+splitted[i]+")+";
  }

  var step_two_result = (sum * sum)/parseInt(splitted.length);
  demo = demo.substring(0,(demo.length-1));

  var step_three_result = sum1; //(sum *sum) - ((sum * sum)/parseInt(splitted.length));
  var option_A = step_three_result + 1;
  var option_B = step_three_result - 1;

    switch(num_of_choices){
    case 1:
    choice_key = "step_three_var_choice_one";   
    break;    
    case 2:
    choice_key = "step_three_var_choice_two";
    break;   
    case 3:
    choice_key = "step_three_var_choice_three";
    break;
    default:
    break;
  }


var variance_step_convo_script = {
  step_three_var_choice_one: {
        says: ["Great! <span style='color:#0000ff'>(&sum;x)<sup>2</sup>/n) </span> is equal to <b>"+step_two_result+"</b>",
                "Step3: Compute for <span style='color:#ff0000'>&sum;x<sup>2</sup></span> by taking the original set of numbers, <i>squared them individually and add them all.</i>",
                "Here is the computation demo: <br>"+demo,"What would be the result?"],
        reply: [{question: step_three_result, answer: "stepFourVariance"},{question: option_A, answer: "step_three_wrong"},{question: option_B, answer: "step_three_wrong"}] 
      },
   step_three_var_choice_two: {
        says: ["Great! <span style='color:#0000ff'>(&sum;x)<sup>2</sup>/n) </span> is equal to <b>"+step_two_result+"</b>",
                "Step3: Compute for <span style='color:#ff0000'>&sum;x<sup>2</sup></span> by taking the original set of numbers, <i>squared them individually and add them all.</i>",
                "Here is the computation demo: <br>"+demo,"What would be the result?"],
        reply: [{question: option_A, answer: "step_three_wrong"},{question: step_three_result, answer: "stepFourVariance"},{question: option_B, answer: "step_three_wrong"}] 
      },
    step_three_var_choice_three: {
        says: ["Great! <span style='color:#0000ff'>(&sum;x)<sup>2</sup>/n) </span> is equal to <b>"+step_two_result+"</b>",
                "Step3: Compute for <span style='color:#ff0000'>&sum;x<sup>2</sup></span> by taking the original set of numbers, <i>squared them individually and add them all.</i>",
                "Here is the computation demo: <br>"+demo,"What would be the result?"],
        reply: [{question: option_A, answer: "step_three_wrong"},{question: option_B, answer: "step_three_wrong"},{question: step_three_result, answer: "stepFourVariance"}] 
      },
    step_three_wrong:{
      says: ["Oh no! Please try again."],
      reply: [{question: "Okay!", answer:"step_three_var_choice_one"}]
    }
}

    switch(num_of_choices){
    case 1:   
    chatWindow.talk(variance_step_convo_script, "step_three_var_choice_one"); 
    break;
    
    case 2:   
    chatWindow.talk(variance_step_convo_script, "step_three_var_choice_two");
    break;
    
    case 3:
    chatWindow.talk(variance_step_convo_script, "step_three_var_choice_three");
    break;

    default:
    chatWindow.talk(variance_step_convo_script, "step_three_var_choice_one"); 
    break;
  }

  //chatWindow.talk(variance_step_convo_script, "step_three_var_choice_one"); 
}

function stepFourVariance(){ //step 3 minus step 2

var data_list = document.getElementById('listdata').innerHTML;
  data_list = data_list.substring(0,(data_list.length-1));
  var num_of_choices = Math.floor(Math.random()*3)+1;
  var choice_key = "";

  //get the sum 
  var splitted = data_list.split(" ");
  var sum = 0;
  var sum_ind_sq = 0;
  for(var i=0;i<splitted.length;i++){
  sum = sum + parseInt(splitted[i]);
  sum_ind_sq = sum_ind_sq + (parseInt(splitted[i])*parseInt(splitted[i]));
  }
  var sum_sq_n = ((sum*sum)/parseInt(splitted.length));
  var step_four_result = sum_ind_sq - sum_sq_n;
  step_four_result = step_four_result.toFixed(2);

  var option_A = step_four_result+ 1;
  var option_B = step_four_result+ 2;

  switch(num_of_choices){
    case 1:
    choice_key = "step_four_var_choice_one";   
    break;    
    case 2:
    choice_key = "step_four_var_choice_two";
    break;   
    case 3:
    choice_key = "step_four_var_choice_three";
    break;
    default:
    break;
  }


  var variance_step_convo_script = {
  step_four_var_choice_one: {
        says: ["Great! <span style='color:#ff0000'>&sum;x<sup>2</sup></span> is equal to <b>"+sum_ind_sq+"</b>",
        "Step 4: Subtract the result of <span style='color:#0000ff'>(&sum;x)<sup>2</sup>/n) </span> from the result of <span style='color:#ff0000'>&sum;x<sup>2</sup></span>"," Here is the computation demo <b> "+sum_ind_sq+" subtract by "+sum_sq_n+"</b>","What would be the result?"],
        reply: [{question: step_four_result, answer: "step_var_final"},{question: option_A, answer: "step_four_wrong"},{question: option_B, answer: "step_four_wrong"}] 
      },
  step_four_var_choice_two: {
        says: ["Great! <span style='color:#ff0000'>&sum;x<sup>2</sup></span> is equal to <b>"+sum_ind_sq+"</b>",
        "Step 4: Subtract the result of <span style='color:#0000ff'>(&sum;x)<sup>2</sup>/n) </span> from the result of <span style='color:#ff0000'>&sum;x<sup>2</sup></span>"," Here is the computation demo <b> "+sum_ind_sq+" subtract by "+sum_sq_n+"</b>","What would be the result?"],
        reply: [{question: option_A, answer: "step_four_wrong"},{question: step_four_result, answer: "step_var_final"},{question: option_B, answer: "step_four_wrong"}] 
      },
  step_four_var_choice_three: {
        says: ["Great! <span style='color:#ff0000'>&sum;x<sup>2</sup></span> is equal to <b>"+sum_ind_sq+"</b>",
        "Step 4: Subtract the result of <span style='color:#0000ff'>(&sum;x)<sup>2</sup>/n) </span> from the result of <span style='color:#ff0000'>&sum;x<sup>2</sup></span>"," Here is the computation demo <b> "+sum_ind_sq+" subtract by "+sum_sq_n+"</b>","What would be the result?"],
        reply: [{question: option_A, answer: "step_four_wrong"},{question: option_B, answer: "step_four_wrong"},{question: step_four_result, answer: "step_var_final"}] 
      },
    step_four_wrong:{
      says: ["Oh no! Please try again."],
      reply: [{question: "Okay!", answer:choice_key}]
    },
    step_var_final:{
      says: ["Great! The result is <b>"+step_four_result+"</b>",
      "Finally, divide the result by <b>(n-1)</b> where it means that you have to <i>subtract 1 from the total number of values.</i>",
      "Here is the computation demo: <b>"+step_four_result+" divided by "+splitted.length+"-1 </b>",
      "Make sure to round off your answer to the nearest hundreth.",
      "Enter your answer on the box and click the check it button"]
    }
}

 switch(num_of_choices){
    case 1:   
    chatWindow.talk(variance_step_convo_script, "step_four_var_choice_one"); 
    break;
    
    case 2:   
    chatWindow.talk(variance_step_convo_script, "step_four_var_choice_two");
    break;
    
    case 3:
    chatWindow.talk(variance_step_convo_script, "step_four_var_choice_three");
    break;

    default:
    chatWindow.talk(variance_step_convo_script, "step_four_var_choice_one"); 
    break;
  }


//chatWindow.talk(variance_step_convo_script, "step_four_var_choice_one");
}


function stepGuideStandardDeviation(data_list){
 var sdeviation_step_convo_script = {
  ice: {
        says: ["<span style='color:#ff0000; font-size:15px; font-weight:bold;'>Oh no! That is not the correct answer.</span>","Would you like me to help you?"],
        reply: [
                {question: "No, Thanks!", answer: "instruct_to_solve"},
                {question: "Yes, Please!", answer: "define_topic"}
                ]
      },
    start_over: {
        says: ["Would you like me to help you?"],
        reply: [
                {question: "No, Thanks!", answer: "instruct_to_solve"},
                {question: "Yes, Please!", answer: "define_topic"}
                ]
      },
      instruct_to_solve: {
        says: ["Okay,carefully read the problem then enter your answer on the box and click the check it button. "],
        reply: [{question: "Start Over", answer: "start_over"}]
        },
      define_topic: {
        says: ["I'm glad to help you!",
        "To compute for <b>Standard Deviation</b>, you just have to take the <i>square root of the variance</i>. ",
        "As a recap, here is the computation formula for variance <br> <span style='font-size:20px'> <span style='color:#ff0000'>&sum;x<sup>2</sup> </span> - <span style='color:#0000ff'>(&sum;x)<sup>2</sup>/n) </span>/ <span style='color:#00ff00'>(n-1) </span></span>",
        "So let’s start to compute the variance of the data set. "],
        reply: [{question: "Okay, Start!", answer: "stepOneSD"}]
      }
  }//variance_step_convo_script

  chatWindow.talk(sdeviation_step_convo_script, "ice");
}

function stepOneSD(){ //Add up all the numbers
  var data_list = document.getElementById('listdata').innerHTML;
  data_list = data_list.substring(0,(data_list.length-1));
  var num_of_choices = Math.floor(Math.random()*3)+1;
  var choice_key = "";

  //get the sum 
  var splitted = data_list.split(" ");
  var sum = 0;
  for(var i=0;i<splitted.length;i++){
  sum = sum + parseInt(splitted[i]);
  }

  //create options here
  var option_A = sum - 1;
  var option_B = sum - 2;

  switch(num_of_choices){
    case 1:
    choice_key = "step_one_sd_choice_one";   
    break;    
    case 2:
    choice_key = "step_one_sd_choice_two";
    break;   
    case 3:
    choice_key = "step_one_sd_choice_three";
    break;
    default:
    break;
  }

  var sdeviation_step_convo_script = {
    step_one_sd_choice_one: {
        says: ["Step1: Compute <span style='color:#0000ff'>&sum;x </span>by adding all the values in the data set.","What would be the result?"],
        reply: [{question: sum, answer: "stepTwoSD"},{question: option_A, answer: "step_one_wrong"},{question: option_B, answer: "step_one_wrong"} ] 
      },
    step_one_sd_choice_two: {
       says: ["Step1: Compute <span style='color:#0000ff'>&sum;x </span>by adding all the values in the data set.","What would be the result?"],
        reply: [{question: option_A, answer: "step_one_wrong"},{question: sum, answer: "stepTwoSD"},{question: option_B, answer: "step_one_wrong"} ] 
      },
    step_one_sd_choice_three: {
        says: ["Step1: Compute <span style='color:#0000ff'>&sum;x </span>by adding all the values in the data set.","What would be the result?"],
        reply: [{question: option_A, answer: "step_one_wrong"},{question: option_B, answer: "step_one_wrong"},{question: sum, answer: "stepTwoSD"} ] 
      },
     step_one_wrong:{
      says: ["Oh no! Please try again."],
      reply: [{question: "Okay!", answer:choice_key}]
     }
  }

   switch(num_of_choices){
    case 1:   
    chatWindow.talk(sdeviation_step_convo_script, "step_one_sd_choice_one"); 
    break;
    
    case 2:   
    chatWindow.talk(sdeviation_step_convo_script, "step_one_sd_choice_two");
    break;
    
    case 3:
    chatWindow.talk(sdeviation_step_convo_script, "step_one_sd_choice_three");
    break;

    default:
    break;
  }
}

function stepTwoSD(){ // SD:squared sum divide by n
var data_list = document.getElementById('listdata').innerHTML;
  data_list = data_list.substring(0,(data_list.length-1));
  var num_of_choices = Math.floor(Math.random()*3)+1;
  var choice_key = "";

  //get the sum 
  var splitted = data_list.split(" ");
  var sum = 0;
  for(var i=0;i<splitted.length;i++){
  sum = sum + parseInt(splitted[i]);
  }

  var step_two_result = (sum * sum)/parseInt(splitted.length);
  var option_A = step_two_result + 1;
  var option_B = step_two_result - 1;

    switch(num_of_choices){
    case 1:
    choice_key = "step_two_sd_choice_one";   
    break;    
    case 2:
    choice_key = "step_two_sd_choice_two";
    break;   
    case 3:
    choice_key = "step_two_sd_choice_three";
    break;
    default:
    break;
  }

var sdeviation_step_convo_script = {
  step_two_sd_choice_one: {
        says: ["Step 2: Compute for <span style='color:#0000ff'>(&sum;x)<sup>2</sup>/n) </span> by <i> squaring the sum and divide it by the total number of entries</i>.",
              "Here is the computation demo: <b>"+sum+" x "+sum+" divided by "+splitted.length+"</b>",
              "What is the result?"],
        reply: [{question: step_two_result, answer: "stepThreeSD"},{question: option_A, answer: "step_two_wrong"},{question: option_B, answer: "step_two_wrong"}] 
      },
  step_two_sd_choice_two: {
        says: ["Step 2: Compute for <span style='color:#0000ff'>(&sum;x)<sup>2</sup>/n) </span> by <i> squaring the sum and divide it by the total number of entries</i>.","Here is the computation demo: <b>"+sum+" x "+sum+" divided by "+splitted.length+"</b>","What is the result?"],
        reply: [{question: option_A, answer: "step_two_wrong"},{question: step_two_result, answer: "stepThreeSD"},{question: option_B, answer: "step_two_wrong"}] 
      },
  step_two_sd_choice_three: {
       says: ["Step 2: Compute for <span style='color:#0000ff'>(&sum;x)<sup>2</sup>/n) </span> by <i> squaring the sum and divide it by the total number of entries</i>.","Here is the computation demo: <b>"+sum+" x "+sum+" divided by "+splitted.length+"</b>","What is the result?"],
        reply: [{question: option_A, answer: "step_two_wrong"},{question: option_B, answer: "step_two_wrong"},{question: step_two_result, answer: "stepThreeSD"}] 
      },
    step_two_wrong:{
      says: ["Oh no! Please try again."],
      reply: [{question: "Okay!", answer:choice_key}]
    }
}

    switch(num_of_choices){
    case 1:   
    chatWindow.talk(sdeviation_step_convo_script, "step_two_sd_choice_one"); 
    break;
    
    case 2:   
    chatWindow.talk(sdeviation_step_convo_script, "step_two_sd_choice_two");
    break;
    
    case 3:
    chatWindow.talk(sdeviation_step_convo_script, "step_two_sd_choice_three");
    break;

    default:
    chatWindow.talk(sdeviation_step_convo_script, "step_two_var_choice_one"); 
    break;
  }

}

function stepThreeSD(){ //individual squared sum 
var data_list = document.getElementById('listdata').innerHTML;
  data_list = data_list.substring(0,(data_list.length-1));
  var num_of_choices = Math.floor(Math.random()*3)+1;
  var choice_key = "";

  //get the sum 
  var splitted = data_list.split(" ");
  var sum=0,sum1 = 0;
  var demo = "";
  for(var i=0;i<splitted.length;i++){
  sum1 = sum1 + (parseInt(splitted[i])*parseInt(splitted[i]));
  sum = sum + parseInt(splitted[i]);
  demo = demo+"("+splitted[i]+"x"+splitted[i]+")+";
  }

  var step_two_result = (sum * sum)/parseInt(splitted.length);
  demo = demo.substring(0,(demo.length-1));

  var step_three_result = sum1; //(sum *sum) - ((sum * sum)/parseInt(splitted.length));
  var option_A = step_three_result + 1;
  var option_B = step_three_result - 1;

    switch(num_of_choices){
    case 1:
    choice_key = "step_three_sd_choice_one";   
    break;    
    case 2:
    choice_key = "step_three_sd_choice_two";
    break;   
    case 3:
    choice_key = "step_three_sd_choice_three";
    break;
    default:
    break;
  }


var sdeviation_step_convo_script = {
  step_three_sd_choice_one: {
        says: ["Great! <span style='color:#0000ff'>(&sum;x)<sup>2</sup>/n) </span> is equal to <b>"+step_two_result+"</b>",
                "Step3: Compute for <span style='color:#ff0000'>&sum;x<sup>2</sup></span> by taking the original set of numbers, <i>squared them individually and add them all.</i>",
                "Here is the computation demo: <br>"+demo,"What would be the result?"],
        reply: [{question: step_three_result, answer: "stepFourSD"},{question: option_A, answer: "step_three_wrong"},{question: option_B, answer: "step_three_wrong"}] 
      },
   step_three_sd_choice_two: {
        says: ["Great! <span style='color:#0000ff'>(&sum;x)<sup>2</sup>/n) </span> is equal to <b>"+step_two_result+"</b>",
                "Step3: Compute for <span style='color:#ff0000'>&sum;x<sup>2</sup></span> by taking the original set of numbers, <i>squared them individually and add them all.</i>",
                "Here is the computation demo: <br>"+demo,"What would be the result?"],
        reply: [{question: option_A, answer: "step_three_wrong"},{question: step_three_result, answer: "stepFourSD"},{question: option_B, answer: "step_three_wrong"}] 
      },
    step_three_sd_choice_three: {
        says: ["Great! <span style='color:#0000ff'>(&sum;x)<sup>2</sup>/n) </span> is equal to <b>"+step_two_result+"</b>",
                "Step3: Compute for <span style='color:#ff0000'>&sum;x<sup>2</sup></span> by taking the original set of numbers, <i>squared them individually and add them all.</i>",
                "Here is the computation demo: <br>"+demo,"What would be the result?"],
        reply: [{question: option_A, answer: "step_three_wrong"},{question: option_B, answer: "step_three_wrong"},{question: step_three_result, answer: "stepFourSD"}] 
      },
    step_three_wrong:{
      says: ["Oh no! Please try again."],
      reply: [{question: "Okay!", answer:"step_three_var_choice_one"}]
    }
}

    switch(num_of_choices){
    case 1:   
    chatWindow.talk(sdeviation_step_convo_script, "step_three_sd_choice_one"); 
    break;
    
    case 2:   
    chatWindow.talk(sdeviation_step_convo_script, "step_three_sd_choice_two");
    break;
    
    case 3:
    chatWindow.talk(sdeviation_step_convo_script, "step_three_sd_choice_three");
    break;

    default:
    chatWindow.talk(sdeviation_step_convo_script, "step_three_sd_choice_one"); 
    break;
  }

  //chatWindow.talk(variance_step_convo_script, "step_three_var_choice_one"); 
}

function stepFourSD(){ //step 3 minus step 2

var data_list = document.getElementById('listdata').innerHTML;
  data_list = data_list.substring(0,(data_list.length-1));
  var num_of_choices = Math.floor(Math.random()*3)+1;
  var choice_key = "";

  //get the sum 
  var splitted = data_list.split(" ");
  var sum = 0;
  var sum_ind_sq = 0;
  for(var i=0;i<splitted.length;i++){
  sum = sum + parseInt(splitted[i]);
  sum_ind_sq = sum_ind_sq + (parseInt(splitted[i])*parseInt(splitted[i]));
  }
  var sum_sq_n = ((sum*sum)/parseInt(splitted.length));
  var step_four_result = sum_ind_sq - sum_sq_n;
  step_four_result = step_four_result.toFixed(2);

  var option_A = parseInt(step_four_result)+ 1;
  var option_B = parseInt(step_four_result)+ 2;

  switch(num_of_choices){
    case 1:
    choice_key = "step_four_sd_choice_one";   
    break;    
    case 2:
    choice_key = "step_four_sd_choice_two";
    break;   
    case 3:
    choice_key = "step_four_sd_choice_three";
    break;
    default:
    break;
  }


  var sdeviation_step_convo_script = {
  step_four_sd_choice_one: {
        says: ["Great! <span style='color:#ff0000'>&sum;x<sup>2</sup></span> is equal to <b>"+sum_ind_sq+"</b>",
        "Step 4: Subtract the result of <span style='color:#0000ff'>(&sum;x)<sup>2</sup>/n) </span> from the result of <span style='color:#ff0000'>&sum;x<sup>2</sup></span>"," Here is the computation demo <b> "+sum_ind_sq+" subtract by "+sum_sq_n+"</b>","What would be the result?"],
        reply: [{question: step_four_result, answer: "stepFiveSD"},{question: option_A, answer: "step_four_wrong"},{question: option_B, answer: "step_four_wrong"}] 
      },
  step_four_sd_choice_two: {
        says: ["Great! <span style='color:#ff0000'>&sum;x<sup>2</sup></span> is equal to <b>"+sum_ind_sq+"</b>",
        "Step 4: Subtract the result of <span style='color:#0000ff'>(&sum;x)<sup>2</sup>/n) </span> from the result of <span style='color:#ff0000'>&sum;x<sup>2</sup></span>"," Here is the computation demo <b> "+sum_ind_sq+" subtract by "+sum_sq_n+"</b>","What would be the result?"],
        reply: [{question: option_A, answer: "step_four_wrong"},{question: step_four_result, answer: "stepFiveSD"},{question: option_B, answer: "step_four_wrong"}] 
      },
  step_four_sd_choice_three: {
        says: ["Great! <span style='color:#ff0000'>&sum;x<sup>2</sup></span> is equal to <b>"+sum_ind_sq+"</b>",
        "Step 4: Subtract the result of <span style='color:#0000ff'>(&sum;x)<sup>2</sup>/n) </span> from the result of <span style='color:#ff0000'>&sum;x<sup>2</sup></span>"," Here is the computation demo <b> "+sum_ind_sq+" subtract by "+sum_sq_n+"</b>","What would be the result?"],
        reply: [{question: option_A, answer: "step_four_wrong"},{question: option_B, answer: "step_four_wrong"},{question: step_four_result, answer: "stepFiveSD"}] 
      },
    step_four_wrong:{
      says: ["Oh no! Please try again."],
      reply: [{question: "Okay!", answer:choice_key}]
    }
}

 switch(num_of_choices){
    case 1:   
    chatWindow.talk(sdeviation_step_convo_script, "step_four_sd_choice_one"); 
    break;
    
    case 2:   
    chatWindow.talk(sdeviation_step_convo_script, "step_four_sd_choice_two");
    break;
    
    case 3:
    chatWindow.talk(sdeviation_step_convo_script, "step_four_sd_choice_three");
    break;

    default:
    chatWindow.talk(sdeviation_step_convo_script, "step_four_sd_choice_one"); 
    break;
  }
}

function stepFiveSD(){
var data_list = document.getElementById('listdata').innerHTML;
  data_list = data_list.substring(0,(data_list.length-1));
  var num_of_choices = Math.floor(Math.random()*3)+1;
  var choice_key = "";

  //get the sum 
  var splitted = data_list.split(" ");
  var sum = 0;
  var sum_ind_sq = 0;
  for(var i=0;i<splitted.length;i++){
  sum = sum + parseInt(splitted[i]);
  sum_ind_sq = sum_ind_sq + (parseInt(splitted[i])*parseInt(splitted[i]));
  }
  var sum_sq_n = ((sum*sum)/parseInt(splitted.length));
  var step_four_result = sum_ind_sq - sum_sq_n;
  step_four_result = step_four_result.toFixed(2);

  step_five_result = step_four_result/ (parseInt(splitted.length)-1);
  step_five_result = step_five_result.toFixed(2);
  var option_A = parseInt(step_five_result)+ 1;
  var option_B = parseInt(step_five_result)+ 2;

  var sdeviation_step_convo_script = {
     step_five_sd_choice_one:{
      says: ["Great! The result is <b>"+step_four_result+"</b>",
      "Step 5: Compute the <b>variance</b> by dividing the result by <b>(n-1)</b> where it means that you have to <i>subtract 1 from the total number of values.</i>",
      "Here is the computation demo: <b>"+step_four_result+" divided by "+splitted.length+"-1 </b>",
      "What would be the result?"],
      reply: [{question: step_five_result, answer: "step_sd_final"},{question: option_A, answer: "step_five_wrong"},{question: option_B, answer: "step_five_wrong"}] 
    },
    step_sd_final:{
      says: ["Great! Our variance is equal to <b>"+step_five_result+"</b>",
      "Finally, compute the <b>Standard Deviation</b> by taking the square root of the variance",
      "Here is the computation demo: <b><span style='white-space:nowrap;font-size:larger'> &radic; <span style='text-decoration:overline;'>"+step_five_result+"&nbsp; </span></span></b>",
      "Make sure to round off your answer to the nearest hundreth",
      "Enter your answer on the box and click the check it button."]
    },
    step_five_wrong:{
      says: ["Oh no! Please try again."],
      reply: [{question: "Okay!", answer:choice_key}]
    }
  }

  chatWindow.talk(sdeviation_step_convo_script, "step_five_sd_choice_one");
}

//-----------------Feedback of topic if correct ----



function feedbackMode(data_list){
var numbers = data_list.split(" ");
    var modes = [], count = [], i, number, maxIndex = 0;
 
    for (i = 0; i < numbers.length; i += 1) {
        number = numbers[i];
        count[number] = (count[number] || 0) + 1;
        if (count[number] > maxIndex) {
            maxIndex = count[number];
        }
    }
 
    for (i in count)
        if (count.hasOwnProperty(i)) {
            if (count[i] === maxIndex) {
                modes.push(Number(i));
            }
        }

  var mode_feedback_script = {
    one_mode_feedback: {
     says: ["<span style='color:#22b24c; font-size:15px; font-weight:bold;'>Well done, that is the correct answer!</span> <br>The <b>mode</b> of the data set is <b>"+modes[0]+"</b> because it appears <b>"+ maxIndex+"</b> times."]
    },
    two_mode_feedback:{
     says: ["<span style='color:#22b24c; font-size:15px; font-weight:bold;'>Well done, that is the correct answer!</span> <br>It is possible to have a data set with <b> more than one mode</b>. The values <b>"+modes+"</b> appears "+maxIndex+" times."] 
   },
   no_mode_feedback:{
    says: ["<span style='color:#22b24c; font-size:15px; font-weight:bold;'>Well done, that is the correct answer!</span> <br>Our data set has no mode."]
   }
  }

     if(maxIndex==1){ //no mode
      chatWindow.talk(mode_feedback_script,"no_mode_feedback");
    }
    else if(modes.length>1 && maxIndex>1){ // more than one mode
      chatWindow.talk(mode_feedback_script,"two_mode_feedback");
    }
    else{ //one mode
      chatWindow.talk(mode_feedback_script,"one_mode_feedback");
    }
    		
   			// if(modes.length==1){ //one mode  
    		// 	//chatWindow.talk({ice: { says: ["The <b>mode</b> of the data set is <b>"+modes[0]+"</b> because it appears <b>"+ maxIndex+"</b> times."]}});
    		//   chatWindow.talk(mode_feedback_script,"one_mode_feedback");
      //   }else if(modes.length>1){ //two ormode mode 
    		// 	//chatWindow.talk({ice: { says: ["It is possible to have a data set with <b> more than one mode</b>. The values <b>"+modes+"</b> appears "+maxIndex+" times."]}});
    		//   chatWindow.talk(mode_feedback_script,"two_mode_feedback");
      //   }else{ //no mode
      //     chatWindow.talk(mode_feedback_script,"no_mode_feedback");
    		// 	//chatWindow.talk({ice: { says: ["Our data set has no mode."]}});
    		// }
}


function feedbackMedian(data_list){
var feedback = "";
var splitted = data_list.split(" ");
var sorted_data = splitted.sort();
var median;

  //determine if the data lis is odd or even
  if(sorted_data.length%2==0){//even
    //get the index 1
    //get the index 2
    var ind1 = ((parseInt(sorted_data.length))/2)-1;
    var ind2 = ind1+1;    
    median = (parseInt(sorted_data[ind1])+parseInt(sorted_data[ind2]))/2; 

    chatWindow.talk({ice: { says: ["<span style='color:#22b24c; font-size:15px; font-weight:bold;'>Well done, that is the correct answer!</span> <br> Even: The median of the data set is <b> "+median+"</b>."]}});
    feedback = "The median of the data set is even";
  }else{ //odd    
    var median_index = ((parseInt(sorted_data.length)-1)/2);
    median = sorted_data[median_index];
     chatWindow.talk({ice: { says: ["<span style='color:#22b24c; font-size:15px; font-weight:bold;'>Well done, that is the correct answer!</span> <br> Odd:The median of the data set is <b> "+median+"</b>."]}});
    feedback = "The median of the data set is odd";
  }


  return feedback;

}

function feedbackMean(data_list){

var splitted = data_list.split(" ");
  var sum = 0;
  for(var i=0;i<splitted.length;i++){
  sum = sum + parseInt(splitted[i]);
  }
  var mean = sum/parseInt(splitted.length);
  mean = mean.toFixed(2);
  

chatWindow.talk({ice: { says: ["<span style='color:#22b24c; font-size:15px; font-weight:bold;'>Well done, that is the correct answer!</span> <br>The <b>mean</b> of the data set is <b>"+mean+"</b>"]}});	

}

function feedbackRange(data_list){

var range = findRange(data_list);
chatWindow.talk({ice: { says: ["<span style='color:#22b24c; font-size:15px; font-weight:bold;'>Well done, that is the correct answer!</span> <br>The <b>range</b> of the data set is <b>"+range+"</b>"]}});
}

function feedbackVariance(data_list){
var variance = findVariance(data_list);
chatWindow.talk({ice: { says: ["<span style='color:#22b24c; font-size:15px; font-weight:bold;'>Well done, that is the correct answer!</span> <br>The <b> variance </b> of the data set is <b>"+variance+"</b>"]}});
}

function feedbackStandardDeviation(data_list){
var sd = findStandardDeviation(data_list);
chatWindow.talk({ice: { says: ["<span style='color:#22b24c; font-size:15px; font-weight:bold;'>Well done, that is the correct answer!</span> <br>The <b> standard deviation </b> of the data set is <b>"+sd+"</b>"]}});
}


