var step_says = "";
var option_A =""; // next step ID
var option_B = "";
var option_C="";

//Step Object - 1 says may have or may not have options

function setValues(){

}

function getNextStepObject(){
	
}


//three options: correct, confuse, 
function stepConvotemplate(){
	//get random number for choices manipulation
	//how can I generate the option choices? 
	//In the answer: how can I determine what is the next step base on ID from database
	var step_script = {
		 step_choice_one: {
        	says: [step_says],
        	reply: [
			        {question: option_A, answer: ""},
			        {question: option_B, answer: ""},
			        {question: option_C, answer: ""} 
			        ] 
      }
	}
}

//no options
function finalConvotemplate(){
	var final_step_script = {
		step_one_mean_choice_one: {
        	says: [step_says]
        }
	}
}