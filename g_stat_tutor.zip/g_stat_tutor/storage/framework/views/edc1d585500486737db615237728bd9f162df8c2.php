<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <legend>Course List Page</legend>
            <?php if(session('info')): ?>
                <?php echo e(session('info')); ?>

            <?php endif; ?>
            <a href='/course/create' class="btn btn-primary">NEW COURSE</a> <br>
            <table class="table table-striped table-hover">
                <thead>
                    <tr> 
                    	<th>ID</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Actions</th>
                       
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($course) > 0): ?>
                        <?php $__currentLoopData = $course->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr> 
                            	
                                <td><?php echo e($course->id); ?></td>
                                <td><?php echo e($course->name); ?></td>
                                <td><?php echo e($course->description); ?></td>
                                <td>
                                    <a href='<?php echo e(url("course/view/{$course->id}")); ?>' class="label label-primary">View</a>
                                    <a href='<?php echo e(url("course/edit/{$course->id}")); ?>' class="label label-success">Update</a>
                                    <a href='<?php echo e(url("course/delete/{$course->id}")); ?>' class="label label-danger">Delete</a>
                                </td>
                            </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>

        </div>
    </div>
    <?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>