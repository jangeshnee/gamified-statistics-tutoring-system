<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="row">
         <div class="col-md-10 col-md-offset-1">
            
                <div class="row">
                    <div class="col-md-8 col-md-offset-2">
                        <br>
                        <div class="green-panel">
                                <div class="green-header">Register</div>

                                <div class="panel-body">
                                    <form class="form-horizontal" method="POST" action="<?php echo e(route('register')); ?>">
                                        <?php echo e(csrf_field()); ?>


                                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                            <label for="fname" class="col-md-4 control-label">First Name</label>

                                            <div class="col-md-6">
                                                <input id="name" type="text" class="form-control" name="fname" value="<?php echo e(old('name')); ?>" required autofocus>

                                                <?php if($errors->has('name')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                            <label for="lname" class="col-md-4 control-label">Last Name</label>

                                            <div class="col-md-6">
                                                <input id="name" type="text" class="form-control" name="lname" value="<?php echo e(old('name')); ?>" required autofocus>

                                                <?php if($errors->has('name')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                            <label for="age" class="col-md-4 control-label">Age</label>

                                            <div class="col-md-6">
                                                <input id="name" type="text" class="form-control" name="age" value="<?php echo e(old('name')); ?>" required autofocus>

                                                <?php if($errors->has('name')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                            <label for="name" class="col-md-4 control-label">Gender</label>

                                            <div class="col-md-6">
                                                <!-- <input id="name" type="text" class="form-control" name="gender" value="<?php echo e(old('name')); ?>" required autofocus> -->

                                                <?php if($errors->has('name')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                                    </span>
                                                <?php endif; ?>

                                                <div class="radio"> 
                                                    <label> 
                                                        <input type="radio" name="gender" id="optionsRadios1" value="Male" checked> Male
                                                    </label> 
                                                </div> 
                                                <div class="radio"> 
                                                    <label> 
                                                        <input type="radio" name="gender" id="optionsRadios2" value="Female"> Female
                                                    </label> 
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                            <label for="email" class="col-md-4 control-label">E-Mail Address</label>

                                            <div class="col-md-6">
                                                <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>

                                                <?php if($errors->has('email')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                            <label for="password" class="col-md-4 control-label">Password</label>

                                            <div class="col-md-6">
                                                <input id="password" type="password" class="form-control" name="password" required>

                                                <?php if($errors->has('password')): ?>
                                                    <span class="help-block">
                                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label for="password-confirm" class="col-md-4 control-label">Confirm Password</label>

                                            <div class="col-md-6">
                                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <div class="col-md-6 col-md-offset-4">
                                                <a href="<?php echo e(url('/login')); ?>" class="btn btn-primary">Back</a>

                                                <button type="submit" class="btn btn-primary">
                                                    Register
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>

                            <br>
                        </div>

                    </div>
                
            </div>
        </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>