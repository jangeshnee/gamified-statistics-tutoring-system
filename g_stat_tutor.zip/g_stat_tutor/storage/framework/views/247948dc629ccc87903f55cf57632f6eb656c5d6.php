<?php $__env->startSection('content'); ?>


<?php $user_ID = Auth::user()->id;
$problem_id=0;
?>
<div class="row">
	<div class="col-md-8 col-md-offset-2"> 
	<div style="padding:30px;background:#ffd55c;margin:30px;color:#000;">	
		<h1>Lesson Pages List:</h1>
	<br>
	<?php $__currentLoopData = $topics->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topics): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
		<p><a style="text-decoration:none;"href='<?php echo e(url("users/mylessons/{$user_ID}/{$topics->title}/{$problem_id}")); ?>'><?php echo e($topics->title); ?></a></p>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	
	</div>
</div> 
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>