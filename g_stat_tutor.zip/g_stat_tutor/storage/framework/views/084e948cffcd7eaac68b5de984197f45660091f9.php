<?php if(Auth::guard('web')->check()): ?>

	<p class="text-success">
	You are logged IN as a USER 
	</p>
<?php else: ?>
	<p class="text-danger">
	You are logged OUT as a USER 
	</p>
<?php endif; ?>

<?php if(Auth::guard('admin')->check()): ?>

	<p class="text-success">
	You are logged IN as a ADMIN 
	</p>
<?php else: ?>
	<p class="text-danger">
	You are logged OUT as a ADMIN 
	</p>
<?php endif; ?>