<?php $__env->startSection('content'); ?>
<?php $rank_counter = 0; ?>
<div class="container">
    <div class="slide">
    <div class="row">
         <div class="col-md-12">
                <h3>Leaderboard</h3>
                
                <div class="table-responsive">
                <table class="table">
                     <tr>
                      <th>Rank #</th>
                      <th>First Name</th>
                      <th>Last Name</th>
                      <th>Points</th>
                    </tr>
                <?php $__currentLoopData = $leaderboard->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leaderboard): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $rank_counter++; ?>
                <tr>
                  <td> <?php echo e($rank_counter); ?></td>
                  <td><?php echo e($leaderboard->fname); ?></td>
                  <td><?php echo e($leaderboard->lname); ?></td>
                  <td><?php echo e($leaderboard->points_earned); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
                   
            </div>
            </div>
        </div>

</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>