<?php $__env->startSection('content'); ?>
<?php $rank_counter = 1;?>


              <div class="row">
                  <div class="col-md-12"> 
                    <div class="orange-header w3-animate-opacity" style="padding:10px;animation-duration:3s;">
                      <div class="w3-center w3-animate-zoom" style="animation-duration:3s;">Leaderboard</div>
                    </div>
                  </div>
              </div>
              <div class="row">
                <div class="col-md-12">


                    <div>
                       
                           <div class="table-responsive" style="margin-left:30px;margin-right:30px;">
                              <table class="table leaderboard-table">
                                   <tr class="leaderboard-table">
                                    <td class="mytable-header">Rank #</td>
                                    <td class="mytable-header">First Name</td>
                                    <td class="mytable-header">Last Name</td>
                                    <td class="mytable-header">Attempts</td>
                                    <td class="mytable-header">Points</td>
                                  </tr>

                                  <?php $__currentLoopData = $allStudPerfList->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allStudPerfList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                  <tr class='leaderboard-table'>
                                        <td class='mytable-td-rank'><?php echo e($rank_counter); ?></td>
                                        <td class='mytable-td'><?php echo e($allStudPerfList->fname); ?></td>
                                        <td class='mytable-td'><?php echo e($allStudPerfList->lname); ?></td>
                                        <td class='mytable-td'><?php echo e($allStudPerfList->total_attempt); ?></td>
                                        <td class='mytable-td'><?php echo e($allStudPerfList->total_points); ?></td>
                                  </tr>
                                  <?php $rank_counter++; ?>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                  <?php if($rank_counter < 10): ?>

                                  <?php for($i = 0; $i <= $rank_counter; $i++): ?>
                                  <tr class='leaderboard-table'>
                                        <td class='mytable-td-rank'><?php echo e($rank_counter+$i); ?></td>
                                        <td class='mytable-td'></td>
                                        <td class='mytable-td'></td>
                                        <td class='mytable-td'></td>
                                         <td class='mytable-td'></td>
                                  </tr>
                                  <?php endfor; ?>
                                  
                                  
                                  <?php else: ?>
                                  <?php endif; ?>

                              
                              </table>
                          </div>
                    </div>
                          
                       
                </div>
              </div>  
               
              
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>