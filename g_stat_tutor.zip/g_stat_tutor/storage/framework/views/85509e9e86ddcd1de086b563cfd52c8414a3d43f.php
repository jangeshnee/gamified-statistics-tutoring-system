<?php $__env->startSection('content'); ?>

<?php // check the problem pre requisite here before display 
$maximum_score = 0;
?>

<div class="container">
   
   <script src="<?php echo e(url('component/Bubbles.js')); ?>"></script>
   <script src="<?php echo e(url('js/problem_solving.js')); ?>"></script>
   

  <?php $__currentLoopData = $problem_task->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $problem_tasks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <script> getTotalTask('<?php echo e($problem_tasks->id); ?>')</script>
    <?php 
    $maximum_score = $maximum_score + $problem_tasks->task_points;
    ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <?php $current_problem_id; ?>

  <?php $__currentLoopData = $problems->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $problemss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <script> getProblemSummary('<?php echo e($problemss->summary); ?>')</script>
    <?php $current_problem_id = $problemss->id + 1; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                  <?php $__currentLoopData = $problem_step_guide->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $problem_step_guide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <script> 
                  importStepGuide('<?php echo e($problem_step_guide->prob_task_id); ?>',
                    '<?php echo e($problem_step_guide->step_order); ?>',
                    '<?php echo e($problem_step_guide->demo_desc); ?>',
                    '<?php echo e($problem_step_guide->prompt_desc); ?>',
                    '<?php echo e($problem_step_guide->prompt_ans); ?>',
                    '<?php echo e($problem_step_guide->hint); ?>');
                           
                  </script>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="row">
<div class="col-md-12">
<ul class="pager"> 
  <li class="previous"><a href="#">&larr; Previous</a></li> 
  <li class="next"><a href='<?php echo e(url("users/problemsolving/$current_problem_id")); ?>'>Next &rarr;</a></li> 
</ul>
</div>

</div>


<div class="slide">
 	<div class="row">
     <?php $__currentLoopData = $problems->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $problems): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-7">  
              <h3><b><?php echo e($problems->title); ?></b></h3>
              <p><?php echo e($problems->description); ?></p>

              <p><b>Data here</b></p>
             
                <p>
                  <?php echo e($problems->main_question); ?>

                </p>
                
               <h3><b>Task items</b></h3> 
                  <?php $__currentLoopData = $problem_task->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $problem_task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                  <form class="form-horizontal" method="POST" action="<?php echo e(url('/')); ?>">

                    <div class="form-group">
                    <label class="col-lg-3" control-label><?php echo e($problem_task->task_title); ?></label>
                    <div class="col-lg-6">
                      <input type="text" name="answer" class="form-control" id="inputAnswer<?php echo e($problem_task->id); ?>" >
                    </div>
                    <div class="col-lg-3">
                    <!--<a href='<?php echo e(url("problem/check/{$problem_task->id}")); ?>' class="btn btn-primary">Check</a> -->
                    <input type="button" class="btn btn-primary" value="Check it" onclick="checkAnswer('<?php echo e($problem_task->id); ?>','<?php echo e($problem_task->task_answer); ?>','<?php echo e($problem_task->task_ans_feedback); ?>','<?php echo e($problem_task->task_points); ?>')" />

                  </div>
                  </div>
                    
                  </form>  
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

               
              
        	</div>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-5">

                    <h3>TUTORIAL DIALOG</h3>

                      <!-- <div id="tutor" class="convo-panel"> 
                     </div>
                    <input type="text" name="prompt_ans" class="form-control" id="prompt_answer" >
                    <input type="button" class="btn btn-primary" value="Respond" onclick="getUserPromptResponse()" /> -->
                    <div id="chat"></div>

    <!-- import the JavaScript file -->
    
    <script>

    var holder = document.getElementById('display');
    var chatWindow = new Bubbles(document.getElementById("chat"), "chatWindow", {
  // the one that we care about is inputCallbackFn()
  // this function returns an object with some data that we can process from user input
  // and understand the context of it

  // this is an example function that matches the text user typed to one of the answer bubbles
  // this function does no natural language processing
  // this is where you may want to connect this script to NLC backend.
  inputCallbackFn: function(o) {
    // add error conversation block & recall it if no answer matched
    holder.innerHTML = o.input;
    var miss = function() {
      chatWindow.talk(
        {
          "i-dont-get-it": {
            says: [
              "Sorry, I don't get it 😕. Pls repeat? Or you can just click below 👇"
            ],
            reply: o.convo[o.standingAnswer].reply
          }
        },
        "i-dont-get-it"
      )
    }

    // do this if answer found
    var match = function(key) {
      setTimeout(function() {
        chatWindow.talk(convo, key) // restart current convo from point found in the answer
      }, 600)
    }

    // sanitize text for search function
    var strip = function(text) {
      return text.toLowerCase().replace(/[\s.,\/#!$%\^&\*;:{}=\-_'"`~()]/g, "")
    }

    // search function
    var found = false
    o.convo[o.standingAnswer].reply.forEach(function(e, i) {
      strip(e.question).includes(strip(o.input)) && o.input.length > 0
        ? (found = e.answer)
        : found ? null : (found = false)
    })
    found ? match(found) : miss()


  }
})

chatWindow.talk({
    ice: 
    { says: ["Hello there!","I am Stella and I would love to help you."],
      reply: [
      {
        question: "Good morning",
        answer: "greet_1"
      },
      {
        question: "Hi Stella!",
        answer: "greet_2"
      }
      ,
      {
        question: "Hello!",
        answer: "greet_3"
      }
    ]
    },
  greet_1: {
    says: ["Good morning! Would you like me to help you solve the problem?"],
    reply: [
      {
        question: "Yes, please!",
        answer: "instruct_to_read"
      },
      {
        question: "No, thanks!",
        answer: "instruct_to_solve"
      }
    ]
  },
  greet_2: {
    says: ["Great! Would you like me to help you solve the problem?"],
    reply: [
      {
        question: "Yes, please!",
        answer: "instruct_to_read"
      },
      {
        question: "No, thanks!",
        answer: "instruct_to_solve"
      }
    ]
  },
  greet_3: {
    says: ["Hi! Would you like me to help you solve the problem?"],
    reply: [
      {
        question: "Yes, please!",
        answer: "instruct_to_read"
      },
      {
        question: "No, thanks!",
        answer: "instruct_to_solve"
      }
    ]
  },
  instruct_to_read: {
    says: ["It's my pleasure to help you.", "First of all, I want you to read and understand the problem","Just tell me if you're done!"],
    reply: [
      {
        question: "I am done!",
        answer: "general_instruction"
      }
    ]
  },
  general_instruction: {
    says: ["Good! In this problem, you have to solve all the task items","(To be continue)"] // Concept script here 
  },
  instruct_to_solve: {
    says: ["Okay, carefully read the problem and try to input your answer on each of the task items "]
  }
});



    
</script>
                 
               
          </div>        
     </div>
     </div>

     <div class="slide-footer">
              <div class="row">
                  <div class="col-md-2">Task Attempted: <div id="taskAttempted"></div></div> <!-- Task Attempted: -->
                  <div class="col-md-2">Total Attempts: <div id="totalAttempts"></div> /3 </div> <!-- Total Attempts: -->
                  <div class="col-md-2">Current Points:<div id="currentPoints"></div></div> <!-- Current Point: -->
                  <div class="col-md-3">Deduction Points:<div id="deduction"></div></div> <!-- Deduction: -->
                  <div class="col-md-3">Total Points:<div id="totalPointss"></div></div> <!-- Total Points: -->
                  
                 <!--  <div class="col-md-6">
                    Total Points : 
                  <div id="currentscore"></div> / <?php echo $maximum_score ?>
                  </div>
                  <div class="col-md-6">
                  <p>Maximum Score  <?php echo $maximum_score ?></p>
                  </div> -->
                 
              </div>

      </div>
   
 </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>