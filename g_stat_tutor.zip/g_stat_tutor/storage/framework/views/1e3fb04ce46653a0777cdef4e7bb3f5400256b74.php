<!DOCTYPE html>
<html>
<head>
<title>Lesson: Mode</title>

<link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet"> 
<link href="<?php echo e(asset('css/mystyle.css')); ?>" rel="stylesheet">

<style>
body{
	background: #3e4a5a;
}

</style>
</head>

<body>

<div class="row">
	<div class="col-md-6">
	<div style="padding:10px;margin:15px">	
				<h1 class="lesson-title">Mode</h1>
		
		<p class="lesson-def"><b>Definition: </b>The <b>mode</b> is the value that occurs <b>most often</b> in the set.</p>

		<div class="lesson-def">
		<p>To find the mode of a data set, order the values from smallest to largest and find the value that occurs most often.</p>
		<p><i>Example:</i> Find the mode of this data set: <b>{6, 9, 7, 5, 4, 9, 9}</b></p>
		<p class="lesson-step">Steps:</p>
		<p class="lesson-step">Order the values from smallest to largest:</p>
		<p>{4, 5, 6, 7, 9, 9, 9}</p>
		<p class="lesson-step">Determine which value appears most often.</p>
		<p>{4, 5, 6, 7, 9, 9, 9}</p>
		<p><b><i>The value 9 occurs 3 times. 9 is the mode.</b></i></p>
		</div>
		
		<div class="lesson-def">
		<center><p><b>Two or More Modes</b></p></center>
		<p>It is possible to have more than one mode.</p>
		<p class="lesson-step">Steps:</p>
		<p><p><i>Example:</i>  Find the mode of this data set: <b>{6, 7, 5, 6, 4, 9, 9}</b></p>
		<p class="lesson-step">Order the values from smallest to largest:</p>
		<p>{4, 5, 6, 6, 7, 9, 9}</p>

		<p class="lesson-step">Determine which value appears most often</p>
		<p>{4, 5, 6, 6, 7, 9, 9}</p>
		<p><b><i>There are 2 modes: 6 and 9. They both appear twice</i></b></p>
		</div>
		
		<div class="lesson-def">
		<center><p><b>No Mode</b></p></center>
		<p>It is possible to have a data set with no mode.</p>
		<p><i>Example:</i>  Find the mode of this data set: <b>{6, 9, 7, 5, 4, 3, 2}</b></p>
		<p class="lesson-step">Steps:</p>
		<p class="lesson-step">Order the values from smallest to largest:</p>
		<p>{2, 3, 4, 5, 6, 7, 9}</p>
		<p class="lesson-step">Determine which value appears most often.</p>
		<p><b><i>Each value appears only once. There is no mode.</i></b></p>
		</div>
	</div>
	</div>
</div>

</body>
</html>
