<!DOCTYPE html>
<html>
<head>
<title>Lesson: Median</title>

<link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet"> 
<link href="<?php echo e(asset('css/mystyle.css')); ?>" rel="stylesheet">
</head>

<body>

<div class="row">
	<div class="col-md-12">
		
		<h1>Median</h1>

		<p>The median is the middle value in a data set.</p>
		<p>The steps for finding the median depend on whether the number of
values in the data set is odd or even. It is always easier to find the
median if you have an odd number of values.</p>

		<p><b>Odd Number of Values</b></p>
		<p>When the number of values in the data set is odd, the median is the
middle value; it has one-half of the values on either side. To find the
median, order the values from smallest to largest and find the
middle value.</p>

<p>Example: Find the median of the data set: {6, 9, 7, 5, 4, 9, 9}</p>
<p>Steps:</p>
<p>Order the values in the data set from smallest to largest:</p>
<p>{4, 5, 6, 7, 9, 9, 9}</p>

<p>Determine whether the number of values in your data set is odd or
even:</p>

<p>There are 7 values in the data set. 7 is an odd number.</p>
<p>Apply the rule for an odd number of values: Find the middle value</p>

<p>========================================</p>
<p><b>Even Number of Values</b></p>
<p>If the number of values in the data set is even, order the values from
smallest to largest and then take the mean of the two middle
values.</p>
<p>Example: Find the median of the data set: {6, 9, 7, 5, 4, 9, 9, 5}</p>

	</div>
</div>

</body>
</html>
