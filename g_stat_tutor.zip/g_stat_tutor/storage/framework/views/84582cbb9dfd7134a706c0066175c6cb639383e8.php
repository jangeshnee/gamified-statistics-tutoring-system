<!DOCTYPE html>
<html>
<head>
<title>Lesson: Median</title>

<link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet"> 
<link href="<?php echo e(asset('css/mystyle.css')); ?>" rel="stylesheet">

<style>
body{
	background: #3e4a5a;
}

</style>
</head>

<body>

<div class="row">
	<div class="col-md-6">
	<div style="padding:10px;margin:15px">
		<h1 class="lesson-title">Median</h1>
		<div class="lesson-def">
			<p><b>Definition: </b>The <b>median</b> is the <b>middle</b> value in a data set.</p>
		</div>

		<div class="lesson-def">
			<p>The steps for finding the median depend on whether the number of values in the data set is odd or even. It is always easier to find the median if you have an odd number of values.</p>
		</div>

		<div class="lesson-def">

		<center><p><b>Odd Number of Values</b></p></center>
		<p>When the number of values in the data set is <b>odd</b>, the <b>median</b> is the
		   <b>middle value</b>; it has one-half of the values on either side.</p> 
		<p>To find the median, order the values from smallest to largest and find the middle value.</p>

		<p>Example: Find the median of the data set: <b>{6, 9, 7, 5, 4, 9, 9}</b></p>
		<p class="lesson-step">Steps:</p>
		<p class="lesson-step">Order the values in the data set from smallest to largest:</p>
		<p>{4, 5, 6, 7, 9, 9, 9}</p>

		<p class="lesson-step">Determine whether the number of values in your data set is odd or even:</p>
 
		<p>There are 7 values in the data set. 7 is an odd number.</p>
		<p class="lesson-step">Apply the rule for an odd number of values: Find the middle value</p>
		<p>{4, 5, 6, <b style="color:#ff6d3b;">7</b>, 9, 9, 9}</p>
		<p><b><i>The median is 7.</b></i></p>
		</div>

		<div class="lesson-def">
		<center><p><b>Even Number of Values</b></p></center>
		<p>If the number of values in the data set is <b>even</b>, <b>order</b> the values from
			<b>smallest to largest</b> and then take the <b>mean of the two middle values</b>.</p>

		<p>Example: Find the median of the data set: <b>{6, 9, 7, 5, 4, 9, 9, 5}</b></p>
	
		<p class="lesson-step">Steps:</p>
		<p class="lesson-step">Order the values in the data set from smallest to largest:</p>
		<p>{4, 5, 5, 6, 7, 9, 9, 9}</p>

		<p class="lesson-step">Determine whether the number of values in your data set is odd or even:</p>

		<p>There are 8 values in the data set. 8 is an even number.</p>

		<p class="lesson-step">Apply the rule for an even number of values: Find the mean of the two middle values:</p>

		<p>{4, 5, 5, <b style="color:#ff6d3b;">6, 7</b>, 9, 9, 9}</p>
		<p>The two middle values are 6 and 7.</p>

		<p>The mean of 6 and 7 is found by adding the two numbers and then dividing by 2:</p>
		<center>
		<p> 6 + 7 = 13</p>
		<p> 13 / 2 = 6.5 </p>
		</center>
		<p><b><i>The median is 6.5.</b></i></p>
		</div>


	</div>
	</div>
</div>

</body>
</html>
