<?php $__env->startSection('content'); ?>
<!-- Select * from problem where topic is _  -->

<?php $__currentLoopData = $topic_name->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	 <?php 
	 $topicname = $topic_name->title;
	 $topic_id = $topic_name->id; 
	 ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php 
$problem_id = array(); // all the problems
$problem_preq_id = array(); //all the problems pre-requisite;
$totalproblem = 0;
$status = 0; // 0 - unsolved 1-solved
$in_progress_status = 0;
$probIDfinByStud = array();
$user_id = Auth::user()->id;
?>

<!-- List of problem solved by student -->
<?php array_push($probIDfinByStud, 0);?>
<?php $__currentLoopData = $probsolvedbystud->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $probsolvedbystud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php array_push($probIDfinByStud, $probsolvedbystud->problem_id);

?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__currentLoopData = $problemsbytopic->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $problemsbytopic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
 <?php 
	array_push($problem_id, $problemsbytopic->id);
    array_push($problem_preq_id, $problemsbytopic->prereq_problem_id);
	$totalproblem++;
?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="row">
    <div class="col-md-12" style="height:15vh;">

    </div>
</div>

<div class="row">
	<div class="col-md-12">
        <div class="header-light-orange w3-animate-opacity" style="animation-duration:3s;">
            <div class="w3-center w3-animate-zoom" style="animation-duration:3s;"><?php echo e($topicname); ?></div>
        </div>
    </div>
</div>

<?php
$m = 0;
$c = 0;
$probCnt = $totalproblem;
$numrow = ceil($totalproblem/3);
for($i=0;$i<$numrow;$i++){

echo "<div class='row'>";
echo "<div class='col-md-1'></div>";
    if($probCnt<5){
        $c = $probCnt;
    }
    else{
        $c = 5;
        $probCnt = $probCnt - 5;
    }
    for($n=0;$n<$c;$n++){
    	//href="/users/problemtutorial/{topic_id}/{problem_id}"
        $result = count($probIDfinByStud);
        //each problem compare to each of problem id in probsolvedbystud/$probIDfinByStud
        for($i=0;$i<$result;$i++){
            if($problem_id[$m]==$probIDfinByStud[$i]){
                $status = 1; break; //problem at index i is solved
            }else{
                $status = 0;
            }

           
        }

        for($j=0;$j<$result;$j++){
            if($problem_preq_id[$m]==$probIDfinByStud[$j]){
                $in_progress_status = 1; break; // the pre req problem is already solved
            }else{
                $in_progress_status = 0;
            }
        }
         $problemID = $problem_id[$m];
?>
        
        <?php if($status==1 && $in_progress_status==1): ?> 
        <!-- /users/problemtutorial/".$user_id."/".$topic_id."/".$problem_id[$m]." -->

        <div class="col-md-2"> 
            <a href="#" onclick="checkProblemPrerequisite(1,<?php echo e($user_id); ?>,<?php echo e($topic_id); ?>,<?php echo e($problemID); ?>)">
                <div class="problem-light-blue-box w3-animate-zoom" style="animation-duration:3s;">
                    <img src="/icons/icon_solved_problem.png" width="70%" height="70%">
                </div>
            </a>
        </div>
        
        <?php elseif($status==0 && $in_progress_status==1): ?>
            <div class="col-md-2"> 
            <a href="#" onclick="checkProblemPrerequisite(1,<?php echo e($user_id); ?>,<?php echo e($topic_id); ?>,<?php echo e($problemID); ?>)">
                <div class="problem-light-blue-box w3-animate-zoom" style="animation-duration:3s;">
                    <img src="/icons/in_progress.png" width="70%" height="70%">
                </div>
            </a>
        </div>
        <?php else: ?>
           <div class="col-md-2"> 
            <a href="#" onclick="checkProblemPrerequisite(0,<?php echo e($user_id); ?>,<?php echo e($topic_id); ?>,<?php echo e($problemID); ?>)">
                <div class="problem-light-blue-box w3-animate-zoom" style="animation-duration:3s;">
                    <img src="/icons/icon_unsolved_problem.png" width="70%" height="70%">
                </div>
            </a>
        </div>
        
        <?php endif; ?>
<?php     
        $m++;
    }

echo "</div>";
}

?>

<div class="row">
    <div class="col-md-12" style="height:40vh;">

    </div>
</div>
<script>

function checkProblemPrerequisite(status_of_problem,user_id,topic_id,problem_id){

//users/problemtutorial/{user_id}/{topic_id}/{problem_id}'    
if(status_of_problem==1){
window.location = "/users/problemtutorial/"+user_id+"/"+topic_id+"/"+problem_id;
//alert("solved");
}
else{
alert("You cannot proceed to problem unless you solved the previous one");
}
}

function checkIfLocked(num){
    alert("heelo");
}

</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>