<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Stat-Tutor</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet"> 
       <link href="<?php echo e(asset('css/mystyle.css')); ?>" rel="stylesheet">
       <link href="<?php echo e(asset('css/w3.css')); ?>" rel="stylesheet">
       <script src="<?php echo e(asset('js/app.js')); ?>"></script>
       <script src="<?php echo e(asset('myjs/jquery-3.3.1.min.js')); ?>"></script>
        <style>
            html, body {
                background-color: #efefef;
                /*background-image:url("<?php echo e(url ('icons/background.jpg')); ?>");
                background-repeat: no-repeat;    #ffb733==> orange*/
                color: #3e4a5a; /* 636b6f; */
                font-family: 'Raleway', sans-serif;
                font-weight: 100;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
                color: #46bfbd;
                text-shadow: 2px 5px 2px #fdb45c;
                font-family: 'Sigmar One', sans-serif;
            }

            .description{

                font-size: 20px;
                background: #efefef;
                padding: 15px;
                border-radius: 10px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-top: 100px;
                margin-bottom: 30px;
            }

            
        </style>
    </head>
    <body>
   <div id="app">
        <br>
     <div class="container content">
        <div class="row">
            <div class="col-md-12">
                <div class="mybox panel panel-default">
                     <div class="row">
                          <div class="col-md-12">
                            <br><br>
                        <div class="w3-container w3-center w3-animate-zoom" style="animation-duration:5s;">
                          <img src='<?php echo e(url("icons/home.png")); ?>' width="100%" height="90%">
                        </div>
                         </div>
                    </div>
                       <div class="row">
                            <br>
                              <div class="col-md-10 col-md-offset-1">

                                <div class="description w3-center w3-animate-top" style="animation-duration:5s;">
                                   <p>Stat-GamiTutor is a web based gamified intelligent tutoring system that 
                                        teaches student to solve basic statistics word problems.  </p>

                                 <a href="<?php echo e(url('/login')); ?>" class="btn btn-default mybutton1">Start</a>
                                </div>
                                <br><br>
                            </div>
                       

                        </div>

                </div>
            </div>
        </div>
    </div>
        
       


    </div> 
</div>

<script>

 $(document).ready(function () {
   
 
 });


 // function beepSound(){
 //    var snd = new Audio("audio/audio-1.mp3");
 //    snd.play();
 // }

 </script>
    </body>
</html>
