<?php $__env->startSection('content'); ?>

<?php 
$next_problem = $prob_id + 1;
?>

<div class="container">
    <div class="slide">
    <div class="row"> 
        <div class="col-md-12">
        	<h1>Congratulations Problem Completed!</h1>
        	<h2>Total Points: <?php echo e($tpoints); ?></h2>
        	<h2>Badge: <?php echo e($badge); ?></h2>

        	<p> <a href='/users/problemsolving/<?php echo e($user_id); ?>/<?php echo e($next_problem); ?>' class="btn btn-primary">Continue</a></p>
		</div>
	</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>