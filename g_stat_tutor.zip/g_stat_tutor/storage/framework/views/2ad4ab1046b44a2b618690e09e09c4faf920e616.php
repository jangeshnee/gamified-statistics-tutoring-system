<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
             <div class="col-md-10 col-md-offset-1">
                <ol class="breadcrumb"> 
                    <li><a href='<?php echo e(url("/admin")); ?>'>Dashboard</a></li> 
                    <li><a href='<?php echo e(url("/course/list")); ?>'>Course Syllabus</a></li> 
                </ol>
             </div>
        </div>        

        <div class="row">
             <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                    <div class="panel-heading">COURSE SYLLABUS</div>
                    <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                        <a href='/course/create' class="btn btn-primary">MANAGE COURSE</a> <br>
                          <br>  
                        <?php if(count($topic) > 0): ?>
                        <?php $__currentLoopData = $topic->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li> <b><?php echo e($topic->title); ?> </b></li>

                           
                                <?php $__currentLoopData = $subtopic->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subtopic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($subtopic->topic_id == $topic->id): ?>
                                    <a> <?php echo e($subtopic->title); ?> </a> <br>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>   

    </div>
    
    <?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>