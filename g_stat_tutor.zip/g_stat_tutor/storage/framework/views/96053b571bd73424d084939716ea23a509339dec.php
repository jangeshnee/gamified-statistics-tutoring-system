<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Stat-Tutor</title>

    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <!-- Styles -->
   
<!--     <link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/bootstrap-grid.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet"> 
    <link href="<?php echo e(asset('css/bootstrap-grid.min.css')); ?>" rel="stylesheet"> -->
<!--     <link href="<?php echo e(asset('css/united_bootstrap.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/united_bootstrap.min.css')); ?>" rel="stylesheet"> -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet"> 
    <link href="<?php echo e(asset('css/mystyle.css')); ?>" rel="stylesheet">
 
   
   
    <!-- Chat Bubble -->
    
    <link rel="stylesheet" media="all" href="<?php echo e(url('component/styles/setup.css')); ?>">
    <link rel="stylesheet" media="all" href="<?php echo e(url('component/styles/says.css')); ?>">
    <link rel="stylesheet" media="all" href="<?php echo e(url('component/styles/reply.css')); ?>">
    <link rel="stylesheet" media="all" href="<?php echo e(url('component/styles/typing.css')); ?>">
    <link rel="stylesheet" media="all" href="<?php echo e(url('component/styles/input.css')); ?>">
    
    <style>
   
    body {
       /*font-family-sans-serif: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";  */
    background-color: #efefef;  /*ffb733*/
    color:#000000;
   
    }

    a{
        color:#000000
    }

    .img-inlarge{
        
    }
    </style>


</head>
<body>
    <div id="app">
   <div class="container">
    <div class="row">
        <div class="col-md-12">
       <nav class="navbar navbar-default navbar-static-top" style="background-color:#72d5cd;">
            <div class="container">
                <div class="navbar-header">

                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <!-- Branding Image -->
                    <a style="color:#000000;" class="navbar-brand" href="<?php echo e(url('/')); ?>">
                       Stat-GamiTutor
                    </a>
                </div>

                

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">
                        <?php if(Auth::guest()): ?> 
                        &nbsp;
                        <?php else: ?>
                        <?php $user_id = Auth::user()->id; ?>
                            <li>
                                <a style="color:#000000;" href='<?php echo e(url("users/view_profile/{$user_id}")); ?>'>Profile</a>
                            </li>
                            <li>
                                <a style="color:#000000;" href='<?php echo e(url("users/progress_levels/{$user_id}")); ?>'>Progression</a> 
                            </li>
                            <li>
                                <a style="color:#000000;" href='<?php echo e(url("users/leaderboard")); ?>'>Leadeboard</a>
                            </li>

                        <?php endif; ?>

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links -->
                        <?php if(Auth::guest()): ?>
                            <li><a style="color:#000000;" href="<?php echo e(route('login')); ?>">Login</a></li>
                            <li><a style="color:#000000;" href="<?php echo e(route('register')); ?>">Register</a></li>
                        <?php else: ?>
                            <li class="dropdown">
                                <a style="color:#000000;" href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    <?php echo e(Auth::user()->fname); ?> <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu" role="menu">
                                    <li>
                                        <a style="color:#000000;" href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                    </li>
                                    <li>
                                        <a style="color:#000000;" href='<?php echo e(url("users/settings")); ?>'>Account Settings</a>
                                    </li>
                                </ul>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

    </div></div></div>
   
        <?php echo $__env->yieldContent('content'); ?>

<br>
    </div>

    <!-- Scripts -->
  
        <!-- js placed at the end of the document so the pages load faster -->
   

    <!--script for this page-->

  
 
  <script type="application/javascript">
        $(document).ready(function () {
            $("#date-popover").popover({html: true, trigger: "manual"});
            $("#date-popover").hide();
            $("#date-popover").click(function (e) {
                $(this).hide();
            });
        
            $("#my-calendar").zabuto_calendar({
                action: function () {
                    return myDateFunction(this.id, false);
                },
                action_nav: function () {
                    return myNavFunction(this.id);
                },
                ajax: {
                    url: "show_data.php?action=1",
                    modal: true
                },
                legend: [
                    {type: "text", label: "Special event", badge: "00"},
                    {type: "block", label: "Regular event", }
                ]
            });
        });
        
        
        function myNavFunction(id) {
            $("#date-popover").hide();
            var nav = $("#" + id).data("navigation");
            var to = $("#" + id).data("to");
            console.log('nav ' + nav + ' to: ' + to.month + '/' + to.year);
        }
    </script>
</body>
</html>
