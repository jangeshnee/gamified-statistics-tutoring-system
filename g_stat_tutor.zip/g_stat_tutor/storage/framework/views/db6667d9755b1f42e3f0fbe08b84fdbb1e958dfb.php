<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Advanced Chat Flows with chat-bubble</title>

    <!-- for mobile screens -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- stylesheets are conveniently separated into components -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" media="all" href="<?php echo e(url('component/styles/setup.css')); ?>">
    <link rel="stylesheet" media="all" href="<?php echo e(url('component/styles/says.css')); ?>">
    <link rel="stylesheet" media="all" href="<?php echo e(url('component/styles/reply.css')); ?>">
    <link rel="stylesheet" media="all" href="<?php echo e(url('component/styles/typing.css')); ?>">
    <link rel="stylesheet" media="all" href="<?php echo e(url('component/styles/input.css')); ?>">
    <style>
        body {
            background: #f5f8fa;
        }

        .bubble-container {
            height: 100vh;
        }

        .bubble-container .input-wrap textarea {
            margin: 0;
            width: calc(100% - 30px);
        }
    </style>
</head>

<body>

  <nav class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">

                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <!-- Branding Image -->
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                       Stat-Tutor
                    </a>
                </div>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">
                        &nbsp;
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links -->
                        <?php if(Auth::guest()): ?>
                            <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                            <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
                        <?php else: ?>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    <?php echo e(Auth::user()->fname); ?> <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu" role="menu">
                                    <li>
                                        <a href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                    </li>
                                </ul>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav> 
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <div class="panel panel-primary">
                <div class="panel-heading">DISPLAY IMAGE</div>

                <div class="panel-body">
                   <svg id="svgelem" height="200" xmlns="http://www.w3.org/2000/svg"> <circle id="redcircle" cx="50" cy="50" r="50" fill="red" /> </svg>
                    <p>Lorem ep sum lorem ep sum lorem ep sumlorem ep sumlorem ep 
                        sumlorem ep sumlorem ep sumlorem ep sum sumlorem ep sumlorem ep sumlorem ep sum
                    sumlorem ep sumlorem ep sumlorem ep sumsumlorem ep sumlorem ep sumlorem ep sumsumlorem ep sumlorem ep sumlorem ep sum</p>
                </div>
            </div>

            <div class="panel panel-primary">
                <div class="panel-heading">PROBLEM</div>

                <div class="panel-body">
                   
                    <p>Lorem ep sum lorem ep sum lorem ep sumlorem ep sumlorem ep 
                        sumlorem ep sumlorem ep sumlorem ep sum sumlorem ep sumlorem ep sumlorem ep sum
                    sumlorem ep sumlorem ep sumlorem ep sumsumlorem ep sumlorem ep sumlorem ep sumsumlorem ep sumlorem ep sumlorem ep sum</p>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="panel panel-primary">
                <div class="panel-heading">DIALOG HISTORY</div>

                <div class="panel-body">
                 

                 <!--insert chat-bubble-->

                 <!-- container element for chat window -->
    <div id="chat"></div>

    <!-- import the JavaScript file -->
    <script src="<?php echo e(url('component/Bubbles.js')); ?>"></script>
    <script>
// initialize by constructing a named function...
// ...and add text processing plugin:
var chatWindow = new Bubbles(document.getElementById("chat"), "chatWindow", {
  // the one that we care about is inputCallbackFn()
  // this function returns an object with some data that we can process from user input
  // and understand the context of it

  // this is an example function that matches the text user typed to one of the answer bubbles
  // this function does no natural language processing
  // this is where you may want to connect this script to NLC backend.
  inputCallbackFn: function(o) {
    // add error conversation block & recall it if no answer matched
    var miss = function() {
      chatWindow.talk(
        {
          "i-dont-get-it": {
            says: [
              "Sorry, I don't get it 😕. Pls repeat? Or you can just click below 👇"
            ],
            reply: o.convo[o.standingAnswer].reply
          }
        },
        "i-dont-get-it"
      )
    }

    // do this if answer found
    var match = function(key) {
      setTimeout(function() {
        chatWindow.talk(convo, key) // restart current convo from point found in the answer
      }, 600)
    }

    // sanitize text for search function
    var strip = function(text) {
      return text.toLowerCase().replace(/[\s.,\/#!$%\^&\*;:{}=\-_'"`~()]/g, "")
    }

    // search function
    var found = false
    o.convo[o.standingAnswer].reply.forEach(function(e, i) {
      strip(e.question).includes(strip(o.input)) && o.input.length > 0
        ? (found = e.answer)
        : found ? null : (found = false)
    })
    found ? match(found) : miss()
  }
}) // done setting up chat-bubble

// conversation object defined separately, but just the same as in the
// "Basic chat-bubble Example" (1-basics.html)
var convo = {
  ice: {
    says: ["Hi", "Would you like banana or ice cream?"],
    reply: [
      {
        question: "Banana",
        answer: "banana"
      },
      {
        question: "Ice Cream",
        answer: "ice-cream"
      }
    ]
  },
  banana: {
    says: ["🍌"],
    reply: [
      {
        question: "Start Over",
        answer: "ice"
      }
    ]
  },
  "ice-cream": {
    says: ["🍦"],
    reply: [
      {
        question: "Start Over",
        answer: "ice"
      }
    ]
  }
}

// pass JSON to your function and you're done!
chatWindow.talk(convo)
</script>



   
</body>

</html>
