<!DOCTYPE html>
<html>
<head>
<title>Lesson Page</title>

<link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet"> 
<link href="<?php echo e(asset('css/mystyle.css')); ?>" rel="stylesheet">
</head>

<body>

<div class="row">
	<div class="col-md-12">
		<?php $__currentLoopData = $singletopic->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singletopic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
	
			<h2><?php echo e($singletopic->title); ?></h2>
			<p><?php echo e($singletopic->description); ?></p>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</div>
</div>

</body>
</html>

