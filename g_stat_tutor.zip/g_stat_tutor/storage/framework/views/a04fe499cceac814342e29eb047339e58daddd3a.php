<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <div class="panel panel-primary">
                <div class="panel-heading">DISPLAY IMAGE</div>

                <div class="panel-body">
                   
                    <p>Lorem ep sum lorem ep sum lorem ep sumlorem ep sumlorem ep 
                        sumlorem ep sumlorem ep sumlorem ep sum sumlorem ep sumlorem ep sumlorem ep sum
                    sumlorem ep sumlorem ep sumlorem ep sumsumlorem ep sumlorem ep sumlorem ep sumsumlorem ep sumlorem ep sumlorem ep sum</p>
                </div>
            </div>

            <div class="panel panel-primary">
                <div class="panel-heading">PROBLEM</div>

                <div class="panel-body">
                   
                    <p>Lorem ep sum lorem ep sum lorem ep sumlorem ep sumlorem ep 
                        sumlorem ep sumlorem ep sumlorem ep sum sumlorem ep sumlorem ep sumlorem ep sum
                    sumlorem ep sumlorem ep sumlorem ep sumsumlorem ep sumlorem ep sumlorem ep sumsumlorem ep sumlorem ep sumlorem ep sum</p>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="panel panel-primary">
                <div class="panel-heading">DIALOG HISTORY</div>

                <div class="panel-body">
                  Tutor:<img src="<?php echo e(url ('icons/004-man.png')); ?>" width="10%" height="10%">
                  <div class="card bg-success">
                        <div class="card-body text-center">
                         <p class="card-text">Some text inside the third card</p>
                        </div>
                 </div> 

                 You:<img src="<?php echo e(url ('icons/005-girl.png')); ?>" width="10%" height="10%">
                  <div class="card bg-danger">
                        <div class="card-body text-center">
                         <p class="card-text">Some text inside the third card</p>
                        </div>
                 </div>  
                

                 <!--insert chat-bubble-->

                 <div id="chat"></div>

                </div> <!--Panel for Dialog History -->


            </div>

            <div class="panel panel-warning">
                <div class="panel-heading">RESPONSE</div>

                <div class="panel-body">                  
                 <input type="text" name="name" class="form-control" id="inputEmail" placeholder="Text Here">
                </div>
            </div>
            


        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>