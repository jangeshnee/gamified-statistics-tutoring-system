<?php $__env->startSection('content'); ?>

<?php $user_id = Auth::user()->id; ?>
<?php $__currentLoopData = $topic->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $topicId = $topic->topic_id;?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if($skillBadge==1): ?>
<div class="row">
        <div class="col-md-6 col-md-offset-3">
            <div class="alert alert-success alert-dismissable"> <button type="button" class="close" data-dismiss="alert" aria-hidden="true"> &times; </button> Congratulations! You earned yourself a <b><a href="/users/view_profile/1#badges">skill badge.</a></b> </div>
        </div>
</div>
<?php else: ?>

<?php endif; ?>

    

    <div class="row">
        <div class="col-md-6 col-md-offset-3">
           <div class="completion-box" id="completion-box">
            <center>
            <p style="color:#8bd6a0">Great Job!</p>
            <div class="w3-container w3-center w3-animate-zoom" style="animation-duration:3s;">
                                <p> <img src='<?php echo e(url("icons/$sbadge")); ?>' width="60%" height="60%"></p>
                            </div>
            
            <p class="w3-animate-zoom" style="animation-duration:3s;font-size:4em;margin:0px;"><?php echo e($total_points); ?></p>
            <p class="">TOTAL POINTS</p>
            </center>
            <p class="completion-p w3-animate-opacity" style="animation-duration:4s;">MAXIMUM POINTS: <?php echo e($max_points); ?></p>
            <!-- <p class="completion-p">BONUS POINTS:</p> -->
            <p class="completion-p w3-animate-opacity" style="animation-duration:4s;">TOTAL FAULT:<?php echo e($totalFault); ?></p>
            <p class="completion-p w3-animate-opacity" style="animation-duration:4s;">TOTAL POINTS DEDUCTION: <?php echo e($max_points-$total_points); ?></p>
            <br>

            <center> 
                <!-- users/problemtutorial/{user_id}/{topic_id}/{problem_id}' -->
                <?php 
                echo "<a href='/users/problemtutorial/".$user_id."/".$topicId."/".$problem_id."' class='btn btn-default completion-btn'>Retry</a>";
                echo "&nbsp; &nbsp;";
                if($topicComplete==1){

                    //topicproblemlist/{user_id}/{topic_id}
                echo "<a href='/users/topicproblemlist/".$user_id."/".($topicId+1)."' class='btn btn-default completion-btn'>Continue</a>";
                }else{
                   echo "<a href='/users/problemtutorial/".$user_id."/".$topicId."/".($problem_id+1)."' class='btn btn-default completion-btn'>Continue</a>"; 
                }
                
                ?>
               
            </center>    
          
          </div> 

        
        </div>
    </div>

    <br><br>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>