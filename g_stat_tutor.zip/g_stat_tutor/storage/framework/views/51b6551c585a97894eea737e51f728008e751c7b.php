<?php $__env->startSection('content'); ?>

<?php
$users_solved_problems_badge = array();
$problem_list = array();
$cnt = 1;
$status = 0; // 0 - unsolved 1-solved
$in_progress_status = 0;
?>


<?php $users_solved_problems_badge[0] = 0; ?>
<?php $__currentLoopData = $stud_problem_solved->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stud_problem_solved): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php 
$users_solved_problems_badge[$cnt] = $stud_problem_solved->problem_id;
$cnt++;
?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="container">

	<div class="row">
		<div class="col-lg-12"> <!--Level: Topic -->
   				<?php if(count($subtopic) > 0): ?>
                        <?php $__currentLoopData = $subtopic->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subtopic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <h2> <b><?php echo e($subtopic->title); ?> </b></h2>

          						<div class="row" style="background: #43b1a9;padding:15px;">
          						<div class="col-lg-1"></div>
                                <?php $__currentLoopData = $problems->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $problems): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <?php if($subtopic->id == $problems->subtopic_id): ?>

                                   <!--Check if the Problem is Solved by the Student-->
                                      <?php for($i=0;$i<$cnt;$i++): ?>
                                        <?php if($problems->id==$users_solved_problems_badge[$i]): ?>
                                          <?php $status = 1; break;//solved?> 
                                          
                                        <?php else: ?>
                                          <?php $status = 0; //unsolved?>

                                        <?php endif; ?>
                                      <?php endfor; ?>
                                     <!--End Check if the Problem is Solved by the Student-->

                                     <!--Check if the Problem Pre-requisite is solved or not-->
                                      <?php for($j=0;$j<$cnt;$j++): ?>
                                        <?php if($users_solved_problems_badge[$j]==$problems->prereq_problem_id): ?>
                                          <?php $in_progress_status = 1; break;//solved?> 
                                          
                                        <?php else: ?>
                                          <?php $in_progress_status = 0; //unsolved?>

                                        <?php endif; ?>
                                      <?php endfor; ?>
                                     <!--END Check if the Problem Pre-requisite is solved or not-->
                                    
                                     <!--Display the appropriate icons-->
                                    <?php if($status==1 && $in_progress_status==1): ?>
                                        <div class="col-lg-2"> 
                                          <a href="#" onclick="checkProblemPrerequisite('1','<?php echo $problems->id; ?>','<?php echo $user_id?>')"> 
                                          <img src='<?php echo e(url("icons/icon_solved_problem.png")); ?>' width="70%" height="70%">
                                         </a>
                                       </div>
                                    <?php elseif($status==0 && $in_progress_status==1): ?>
                                        <div class="col-lg-2"> 
                                          <a href="#" onclick="checkProblemPrerequisite('2','<?php echo $problems->id; ?>','<?php echo $user_id?>')"> 
                                            <img src='<?php echo e(url("icons/in_progress.png")); ?>' width="70%" height="70%">
                                          </a>
                                        </div>
                                    <?php else: ?>

                                       <div class="col-lg-2"> 
                                        <a href="#" onclick="checkProblemPrerequisite('0','<?php echo $problems->id; ?>','<?php echo $user_id?>')" > 
                                          <img src='<?php echo e(url("icons/icon_unsolved_problem.png")); ?>' width="70%" height="70%">
                                        </a>
                                      </div>
                                    <?php endif; ?>
                                    <!--END Display the appropriate icons-->
                                   
                                    
                                     
                                   <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 				</div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?> 

<script>

function checkProblemPrerequisite(status_of_problem,problem_id,user_id){
if(status_of_problem==1 || status_of_problem==2){
window.location = "/users/problemsolving/"+user_id+"/"+problem_id;
}
else{
  alert ("You cannot proceed to problem unless you solved the previous one");
}
}

</script>

		
		</div>
	</div>

	
</div> <!--container-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>