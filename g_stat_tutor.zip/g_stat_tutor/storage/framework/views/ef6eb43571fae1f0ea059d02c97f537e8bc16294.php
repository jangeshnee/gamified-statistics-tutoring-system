<?php $__env->startSection('content'); ?>

<?php
//Variable Declarations
$question_desc = array();
$question_method = array();
$question_points = array();
$question_instruct = array();
$stepCounter = 0;
$totalPoints = 0;
$problemAttempt = 0;
$user_ID = Auth::user()->id;
$topic_title ="";
?>

<?php $__currentLoopData = $topics->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topics): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
	<?php  
	$topic_title = $topics->title; 
	$topic_ID = $topics->id; 

	?>
	
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__currentLoopData = $steps->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
	<!-- Counter here -->
	<?php $stepCounter++; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__currentLoopData = $questions->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
 <?php 
  array_push($question_points,$question->points);
 ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php 
for($i=0;$i<$stepCounter;$i++){
	$totalPoints = $totalPoints + $question_points[$i];
}
?>

<?php $__currentLoopData = $problem->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $problem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <?php 
$problem_id = $problem->id; 
$problem_title = $problem->title;
$problem_desc = $problem->description;
$problem_num_data = $problem->data_list;
$problem_min_data = $problem->min_data;
$problem_max_data = $problem->max_data;
$problem_bonus_points = $problem->bonus_points;
 ?>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<script src="<?php echo e(url('myjs/computations.js')); ?>"></script>
<script src="<?php echo e(url('myjs/tutorial.js')); ?>"></script>

<div class="row">
	<div class="col-md-8">
		<div class="row"> <!--Title and Description-->
			<div class="col-md-12">
				<div class="problem-header"><?php echo e($problem_title); ?></div>
				<div class="problem-description"><p class="problem-desc"><?php echo e($problem_desc); ?></p></div>

			</div>
		</div>
		<div class="row"> <!--Data List or Table-->
			<div class="col-md-12">
			<div class="data-list"> 
				<br>
			<center>
			
				  <?php   
				   $problem_data_list="";           
                  for($i=0,$m=0;$i<$problem_num_data;$i++,$m++){
                   $data = 	rand($problem_min_data,$problem_max_data);
                   //echo "<span class='data-box'>".$data."</span>";
                    $dataId = "data".($i+1);
                   // echo "<input type='button' id='".$dataId."'class='data-box' onclick='fillNum()' value='".$data."'>";
                   ?>
                   <input type="button" id="<?php echo e($dataId); ?>" class="data-box w3-animate-zoom" style="animation-duration:3s;" onclick="fillNum('<?php echo e($dataId); ?>','<?php echo e($data); ?>')" value="<?php echo e($data); ?>">
				<?php
                   if($m>10){
                   	//echo "<br>";
                   	$m=0;
                   }
                   $problem_data_list = $problem_data_list." ".$data;
                  // get the string at index 1 to last
                  }
                  // $count = strlen($problem_data_list);
                  // $problem_data_list = $problem_data_list.substr(1,$count);
                  // echo $problem_data_list;
                  ?> 
                 
			</center>
				<script> getDataList('<?php echo e($problem_data_list); ?>')</script>
			</div>	
			</div>
		</div>
		<div class="row"><!--Question and Answering-->
			<div class="col-md-12">
				<div class="row">
					<div class="col-md-3"><div class="conversation-header">Task: <span id='questionCounter'>1</span>/<?php echo e($stepCounter); ?></div></div>
					<div class="col-md-3"></div>
					<div class="col-md-3"><div class="points-header">Score: <span id='points'>0</span></div></div>
					<div class="col-md-3"><div class="attempts-header">Faults: <span id='faults'>0</span></div></div>
				</div>

				 
				<div class="row">
					<div class="col-md-12">
						<div class="question-description">
							<center>
								
							<p id="question-description"></p>
							<p id="question-instruction" class="question-instruction"></p>
							
							<p>
								<input type="text" name="answer" id="inputAnswer" placeholder="Answer Here" class="question-input" required>
								&nbsp;<a style="text-decoration:none;" href='<?php echo e(url("users/mylessons/$user_ID/$topic_title/$problem_id")); ?>' target="_blank"> <img src='<?php echo e(url("icons/006-books.png")); ?>' width="7%" height="7%" alt="Display Topic"></a>
								&nbsp;<a href='<?php echo e(url("users/calculator")); ?>' target="_blank"><img src='<?php echo e(url("icons/calc.png")); ?>' width="7%" height="7%"></a>
								 
							</p>
							
							
							<input id="btnSubmit" type="button" class="btn btn-default question-button" value="Submit" onclick="submitAnswer()">
							<input id="btnReset" type="button" class="btn btn-default question-button" value="Reset" onclick="reset('<?php echo e($problem_num_data); ?>')">
							
							
							
							
							</center>
						</div>
					</div>
				</div>
				
				
			</div>
		</div>
	
	</div>

	<div class="col-md-4"><!--Tutorial Logs-->
		
			<div class="row">
				<div class="col-md-12"><div class="conversation-header">Guide and Feedback Log</div></div>
			</div>
			
			<div class="row">
				<div class="col-md-12">
					<div id="chatdiv" class="conversation-body">	
						
					 <ul id="chatlist">
					 	<li class="tutor-say"><b>GENERAL INSTRUCTION: </b>Hi! In this problem there are a series of tasks you need to answer correctly. 
					 		Your main goal is to find the <b><?php echo e($topic_title); ?></b> of the problem.</li>
					 	<li></li>	
					</ul>

					</div>
				</div>
			</div>

			<!-- <div class="row">
				<div class="col-md-12">
					<div class="help-header">
						
						<input type="button" id='btnShowExplain' onclick='showExplain()' class='btn btn-default btnForHelp' value='Exp'>  
						<input type="button" id='btnShowExample'onclick='showExample()' class='btn btn-default btnForHelp'value='Exa'>
						<input type="button" id='btnShowDemo' onclick='showDemonstration()' class='btn btn-default btnForHelp'value='Dem'>
						<button class="btn btn-primary" data-toggle="modal" data-target="#myModal" id="btnComplete" onclick="openModal()"> Complete </button>
				  </div>
			</div>
			</div> -->

		
	</div>
</div>
<!-- <button class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal"> Launch demo modal </button> -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog">
        <div class="modal-content completion-box">
             <div class="modal-body ">
                        <center>
						<p style="color:#8bd6a0" id="p-feedback">Great Job!</p>
						<p>
							<div class="w3-container w3-center w3-animate-zoom" style="animation-duration:3s;">
								<img src='' id="starBadge" width="60%" height="60%">
							</div>
						</p>
						<div class="w3-container w3-center w3-animate-zoom" style="animation-duration:3s;">
							<p style="font-size:4em;margin:0px;">
								<span id='tpoints'>0</span>
							</p>
						</div>
						<p class="">TOTAL POINTS</p>
						</center>
						<p class="completion-p">MAXIMUM POINTS:<?php echo e($totalPoints); ?></p>
						<p class="completion-p">BONUS POINTS:<?php echo e($problem_bonus_points); ?></p>
						<p class="completion-p">TOTAL FAULT:<span id='tfaults'>0</span></p>
						<p class="completion-p">TOTAL POINTS DEDUCTION: </p>
						
						<br>
              </div>
              <div class="modal-footer">
                
                 <center>
							<input type="button" id='btnRetry' onclick='' class='btn btn-default completion-btn' value='Retry'>
							<input type="button" id='btnContinue' onclick='' class='btn btn-default completion-btn' value='Continue'>   
						</center>
                  </div>
              </div>
                                    <!-- /.modal-content -->
   </div>
                                <!-- /.modal-dialog -->
</div>


<?php $__currentLoopData = $prob_perf_log->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prob_perf_log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
	<!-- Counter here -->
	<?php $problemAttempt++; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<script>getProblemInfo('<?php echo e($problemAttempt); ?>','<?php echo e($problem_id); ?>','<?php echo e($user_ID); ?>','<?php echo e($totalPoints); ?>','<?php echo e($problem_bonus_points); ?>')</script>

<?php $__currentLoopData = $steps->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $steps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
	<!-- Counter here -->
<script> getAllStepdetails('<?php echo e($steps->id); ?>','<?php echo e($steps->step_order); ?>','<?php echo e($steps->description); ?>','<?php echo e($steps->method); ?>','<?php echo e($steps->instruction); ?>') </script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__currentLoopData = $questions->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $questions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
<!-- Push the data into an array -->
<?php 
array_push($question_desc,$questions->description);
array_push($question_method,$questions->method);
array_push($question_instruct,$questions->instruction);
?>

<script> getAllQuestiondetails('<?php echo e($questions->id); ?>','<?php echo e($questions->step_order); ?>','<?php echo e($questions->code); ?>','<?php echo e($questions->description); ?>','<?php echo e($questions->explaination); ?>','<?php echo e($questions->example); ?>','<?php echo e($questions->demonstration); ?>','<?php echo e($questions->method); ?>','<?php echo e($questions->instruction); ?>','<?php echo e($questions->points); ?>') </script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<script>
//jQuery
//$('#completion-box').hide();
//$('#starBadgeNum').hide();


 $(document).ready(function () {
 	displayQuestion('<?php echo e($question_desc[0]); ?>','<?php echo e($question_method[0]); ?>','<?php echo e($question_instruct[0]); ?>');

 	// var btnComplete = document.getElementById('btnComplete');
 	// btnComplete.disabled = true;
 
 });

function scrollChat(){
	var objDiv = document.getElementById('chatdiv');
	objDiv.scrollTop = objDiv.scrollHeight;
}

function fillNum(dataID,dataValue){
	var AnswerInputBox = document.getElementById('inputAnswer');
	var DataBox = document.getElementById(dataID);
	DataBox.disabled=true;
	DataBox.style.color = "#fff";
	AnswerInputBox.value+=dataValue+",";

}

function reset(numData){
	var AnswerInputBox = document.getElementById('inputAnswer');
	AnswerInputBox.value="";

	for(var i=0;i<numData;i++){
		var dataID = "data"+(i+1);
		var DataBox = document.getElementById(dataID);
		DataBox.disabled=false;
		DataBox.style.color = "#000";
	}
}


function openModal(){
// $('#myModal').modal('show');
var p_feedback = document.getElementById('p-feedback');
p_feedback.innerHTML = "Hello! Congratulations";

var starBadgeNumb = document.getElementById('starBadgeNum').innerHTML;

if(starBadgeNumb==1){
var starBadges = document.getElementById('starBadge').src="/icons/p-star-1.png";
}else if(starBadgeNumb==2){
var starBadges = document.getElementById('starBadge').src="/icons/p-star-2.png";
}else if(starBadgeNumb==3){
var starBadges = document.getElementById('starBadge').src="/icons/p-star-3.png";
}else{

}



}





</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>