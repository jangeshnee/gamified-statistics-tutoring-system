<?php $__env->startSection('content'); ?>
<div class="container">
    
    <div class="row"> <!--Cover-->
    <div class="slide">
        <div class="col-md-7">
          <div style="padding: 50px">
          <br><br><br><br><br>
          <div style="font-size: 4em; font-weight:bolder;">Stat-GamiTutor</div>
          <h4>Stat-Tutor is a web based gamified intelligent tutoring system that teaches student to solve basic statistics word problems.  </h4> 
          <input type="button" class="btn btn-primary" value="GO!">
         </div>
        </div>
        <div class="col-md-5">
            <img src='<?php echo e(url("icons/teacher1.png")); ?>' width="90%" height="90%">
        </div>
    </div>
    </div>
    <br><br>

    
    <div class="row"> <!--Welcome-->
    <div class="slide">
        <div class="col-md-12">
          <br><br>
          <center><div style="font-size: 4em; font-weight:bolder;">Hi!</div></center>
          <center>
            <div style="font-size: 2em; ">
              Welcome to Stat-GamiTutor! <br>
              This is a problem solving journey

            </div>
          </center>
        </div>
        </div>
    </div>
    <br><br>

    <div class="slide">
    <div class="row"> <!--Instruction 1 POINTS-->
        <div class="col-md-12">
          <br><br>
         
          <center>
            <div style="font-size: 2em; ">
              Each set of items in a problem is worth a specific amount of points.  <br>
              Answer correctly to gain the maximum number of points.

            </div>
          </center>
        </div>
        </div>
    </div>
    <br><br>

     <div class="slide">
    <div class="row"> <!--Instruction 2 BADGES-->
        
        <div class="col-md-4">
          <center>
          <p><h2>86-100%</h2>
          <img src="<?php echo e(url ('icons/threestar.png')); ?>" width="30%" height="30%"></p>

           <p><h2>45-85%</h2>
          <img src="<?php echo e(url ('icons/twostar.png')); ?>" width="30%" height="30%"></p>

           <p><h2>0-44%</h2>
          <img src="<?php echo e(url ('icons/onestar.png')); ?>" width="30%" height="30%"></p>
        </center>
        </div>

        <div class="col-md-8">
          <br><br>
         
          
            <div style="font-size: 2em; ">
              The more items you answer correctly, the better your badge will be. <br>
              The best part is everybody gets a badge!

            </div>
          
        </div>
        </div>
    </div>
    <br><br>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>