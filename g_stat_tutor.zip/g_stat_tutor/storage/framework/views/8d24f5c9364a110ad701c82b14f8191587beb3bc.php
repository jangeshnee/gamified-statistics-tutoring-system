<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
             <div class="col-md-10 col-md-offset-1">
                <ol class="breadcrumb"> 
                    <li><a href='<?php echo e(url("/admin")); ?>'>Dashboard</a></li> 
                    <li><a href='<?php echo e(url("/course/list")); ?>'>Course Management</a></li> 
                </ol>
             </div>
        </div>        

        <div class="row">
             <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                    <div class="panel-heading">COURSE MANAGEMENT</div>
                    <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                        <a href='/course/create' class="btn btn-primary">NEW COURSE</a> <br>
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr> 
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Description</th>
                                        <th>Actions</th>
                                       
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(count($course) > 0): ?>
                                        <?php $__currentLoopData = $course->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <tr> 
                                                
                                                <td><?php echo e($course->id); ?></td>
                                                <td><?php echo e($course->name); ?></td>
                                                <td><?php echo e($course->description); ?></td>
                                                <td>
                                                    <a href='<?php echo e(url("topic/list/{$course->id}")); ?>' class="btn btn-success">Manage Topics</a>
                                                    <a href='<?php echo e(url("course/edit/{$course->id}")); ?>' class="btn btn-warning">Update</a>
                                                    <a href='<?php echo e(url("course/delete/{$course->id}")); ?>' class="btn btn-danger">Delete</a>
                                                </td>
                                            </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>


                    </div>
                </div>
            </div>
        </div>   

    </div>
    
    <?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>