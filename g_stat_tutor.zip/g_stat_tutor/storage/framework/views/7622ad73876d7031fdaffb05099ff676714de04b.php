<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <legend>Topic List Page</legend>
            <?php if(session('info')): ?>
                <?php echo e(session('info')); ?>

            <?php endif; ?>
            <a href='/create_topic' class="btn btn-primary">NEW TOPIC</a> <br>
            <table class="table table-striped table-hover">
                <thead>
                    <tr> 
                    	<th>ID</th>
                        <th>Course</th>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Actions</th>
                       
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($topic) > 0): ?>
                        <?php $__currentLoopData = $topic->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr> 
                            	
                                <td><?php echo e($topic->id); ?></td>
                                 <td><?php echo e($topic->course_id); ?></td>
                                <td><?php echo e($topic->title); ?></td>
                                <td><?php echo e($topic->description); ?></td>
                                <td>
                                    <a href='<?php echo e(url("/view_topic/{$topic->id}")); ?>' class="label label-primary">View</a>
                                    <a href='<?php echo e(url("/edit_topic/{$topic->id}")); ?>' class="label label-success">Update</a>
                                    <a href='<?php echo e(url("/delete_topic/{$topic->id}")); ?>' class="label label-danger">Delete</a>
                                </td>
                            </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>

        </div>
    </div>
    <?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>