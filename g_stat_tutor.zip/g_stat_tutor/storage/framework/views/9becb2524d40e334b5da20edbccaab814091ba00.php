<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <legend>Sub Topic List Page</legend>
            <?php if(session('info')): ?>
                <?php echo e(session('info')); ?>

            <?php endif; ?>
            <a href='/create_subtopic' class="btn btn-primary">NEW SUB TOPIC</a> <br>
            <table class="table table-striped table-hover">
                <thead>
                    <tr> 
                    	<th>ID</th>
                        <th>Topic</th>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Actions</th>
                       
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($subtopic) > 0): ?>
                        <?php $__currentLoopData = $subtopic->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subtopic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr> 
                            	
                                <td><?php echo e($subtopic->id); ?></td>
                                 <td><?php echo e($subtopic->topic_id); ?></td>
                                <td><?php echo e($subtopic->title); ?></td>
                                <td><?php echo e($subtopic->description); ?></td>
                                <td>
                                    <a href='<?php echo e(url("/view_subtopic/{$subtopic->id}")); ?>' class="label label-primary">View</a>
                                    <a href='<?php echo e(url("/edit_subtopic/{$subtopic->id}")); ?>' class="label label-success">Update</a>
                                    <a href='<?php echo e(url("/delete_subtopic/{$subtopic->id}")); ?>' class="label label-danger">Delete</a>
                                </td>
                            </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>

        </div>
    </div>
    <?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>